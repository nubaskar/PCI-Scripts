<#
.SYNOPSIS
    Collects evidence from a Windows desktop for PCI compliance.

.DESCRIPTION
    This script gathers various pieces of evidence required for PCI compliance. It collects:
      - System information
      - Installed software details
      - Running processes
      - Event logs (from a specified log and number of days back)
      - Firewall configuration
      - Network configuration
      - Local users information

    Each evidence type is gathered by a dedicated function, making the script modular,
    maintainable, and easy to extend. Evidence is saved as text or CSV files in a user-specified folder.
    
.PARAMETER OutputFolder
    The folder path where all evidence files will be saved. The folder is created if it does not exist.

.PARAMETER EventLogName
    The Windows event log name to retrieve. The default is "Security".

.PARAMETER Days
    The number of days back from the current date to retrieve event log data. The default is 7 days.

.EXAMPLE
    .\PCI-Windows-Script-v2_1.ps1
    .\PCI-Windows-Script-v2_1.ps1 -OutputFolder "C:\PCIComplianceEvidence"

.NOTES
    Author: Uday Nachimuthu
    email: uday.nachimuthu@aprio.com
    Version: 2.2
    Updated: March 1, 2025
    Updates: 
      - Created functions for each PCI Evidence Collection and stored them in lib/PCI-Collector-Functions.psm1 module
      - Replaced wmic with Get-CimInstance or Get-WmiObject cmdlets appropriately
      - Added Error Handling 
      - Added Get-WindowsFeature function (Import-module ServerManager)
      - Added Event Logs collection
      - Added Conditions to identify whether the underlying OS is Server and "Import-module ActiveDirectory".
        * The following functions dependent on ActiveDirectory Module, These functions will output error if AD module is not loaded.
            + Get-DomainControllers(): (Get-ADForest).Domains
            + Get-GlobalCatalogServers(): Get-ADDomainController -Filter {IsGlobalCatalog -eq $true}
            + Get-ADGroupMembers(): Get-ADGroup -Filter "Name -eq '$GroupName'" | Get-ADGroupMember | Select-Object Name
            + Get-ADSecurityGroupsData(): $ADGroups = Get-ADGroup -Filter GroupCategory -eq "Security"
            + Get-ReplicationSummary(): Get-ADAccountAuthorizationGroup -Identity 'Windows Authorization Access Group'
            + Get-AllOUsInDomain(): Get-ADOrganizationalUnit -Filter 'Name -like "*"' | Format-Table Name, DistinguishedName -A

    Author: Scott Ritchie
    email: scott.ritchie@aprio.com
    Version: 2.1
    Updated: November 15, 2022
#>

# Enable advanced function features, making this function behave like a cmdlet.
# This allows support for common parameters such as -Verbose, -ErrorAction, and -Debug,
# as well as enhanced parameter validation and help system integration.
[CmdletBinding()]

# Parameters
param(
    # The default value for the output folder will be a subfolder named after the computer's 
    # name inside the current working directory.
    [Parameter(HelpMessage="Specify the output folder for evidence files.")]
    [string]$OutputFolder = "$(Get-Location)\$env:COMPUTERNAME"
)

#-----------------------------------------------------------------------------------------------
# Valiables
#-----------------------------------------------------------------------------------------------
# Ensure the output folder exists; if not, create it.
if (-not (Test-Path -Path $OutputFolder)) {
    Write-Verbose "Creating output folder: $OutputFolder"
    New-Item -Path $OutputFolder -ItemType Directory -Force | Out-Null
}

# Define output file paths for each evidence category
$combinedOutputFile = Join-Path $OutputFolder "00_AllOutputs.txt"
$systemInfoFile = Join-Path $OutputFolder "01_systeminfo.txt"
$ipaddressInfoFile = Join-Path $OutputFolder "02_IPinfo.txt"
$localUsersInfoFile = Join-Path $OutputFolder "03_LocalUsers.txt"
$SNMPStringsFile = Join-Path $OutputFolder "04_SNMPStrings.txt"
$SecurityPoliciesLocalFile = Join-Path $OutputFolder "05_SecurityPolicies-local.txt"
$SecurityPoliciesDomainFile = Join-Path $OutputFolder "05_SecurityPolicies-Domain.txt"
$GroupPolicyResultFile = Join-Path $OutputFolder "05_GroupPolicy.txt"
$AuditPolicyFile = Join-Path $OutputFolder "05b_AuditPolicy.txt"
$WindowsComponentsFile = Join-Path $OutputFolder "06_WindowsComponents.txt"
$WindowsComponents32bitFile = Join-Path $OutputFolder "06_WindowsComponents32bit.txt"
$InstalledPrograms_wmiFile = Join-Path $OutputFolder "07_InstalledPrograms_wmioutput.txt"
$InstalledPrograms_regFile = Join-Path $OutputFolder "07_InstalledPrograms_regoutput.txt"
$InstalledProgramsWmicFile = Join-Path $OutputFolder "07_InstalledPrograms_wmic.txt"
$RunningProcessFile = Join-Path $OutputFolder "08_RunningProcess_Overview.txt"
$ServicesFile = Join-Path $OutputFolder "09_Services_Overview.txt"

$ListeningPortsFile = Join-Path $OutputFolder "10_ListeningPorts.txt"
$InstalledPatchesFile = Join-Path $OutputFolder "11_InstalledPatches.txt"
$LocalAdminsFile = Join-Path $OutputFolder "12_LocalAdmins.txt"
$LanmanHashFile = Join-Path $OutputFolder "13_LanmanHash.txt"
$RDPSettingsLocalFile = Join-Path $OutputFolder "14_RDPSettings_Local.txt"
$RDPSettingsDomainFile = Join-Path $OutputFolder "14_RDPSettings_Domain.txt"
$RDPMasterSettingsFile = Join-Path $OutputFolder "14_RDPSettings_Master.txt"
$ScreensaverFile = Join-Path $OutputFolder "15_ScreenTimeout.txt"
$TimeSettingsFile = Join-Path $OutputFolder "16_TimeSettings.txt"
$timeStateStatusFile = Join-Path $OutputFolder "17_TimeState_Status.txt"
$SnareSettingsFile = Join-Path $OutputFolder "18_SnareSettings.txt"
$LocalRDPUsersFile = Join-Path $OutputFolder "19_LocalRDPUsers.txt"

$LocalPowerUsersFile = Join-Path $OutputFolder "20_LocalPowerUsers.txt"
$LocalServerOperatorsFile = Join-Path $OutputFolder "20_LocalServerOperators.txt"
$ListeningPortsFile = Join-Path $OutputFolder "21_StartupPrograms.txt"
$UserLogonHistoryFile = Join-Path $OutputFolder "22_UserLogonHistory.txt"
$KnownRoutesFile = Join-Path $OutputFolder "23_Routes.txt"
$FirewallRulesFile = Join-Path $OutputFolder "24_FirewallRules.txt"
$PasswordPoliciesFile = Join-Path $OutputFolder "25_PasswordPolicies.txt"
$FileSharesFile = Join-Path $OutputFolder "26_FileShares.txt"
$DomainControllersFile = Join-Path $OutputFolder "27_DomainControllers.txt"
$FSMOServersFile = Join-Path $OutputFolder "28_FSMOservers.txt"
$GlobalCatalogServersFile = Join-Path $OutputFolder "29_GlobalCatalogServers.txt"

$ADSecurityGroupsAndMembersCSVFile = Join-Path $OutputFolder "30_ADSecurityGroupsAndMembers.csv"
$WindowsFeaturesFile = Join-Path $OutputFolder "31_WindowsFeatures.txt"
$EventLogsFile = Join-Path $OutputFolder "32_EventLogs.txt"

#-----------------------------------------------------------------------------------------------
# Import PCI Collector Module
#-----------------------------------------------------------------------------------------------
$scriptPath = (Get-Location).Path  # Get the current working directory using Get-Location
$modulePath = Join-Path -Path $scriptPath -ChildPath "lib\PCI-Collector-Functions.psm1"  # Build path to the module in the 'lib' folder

Import-Module $modulePath  # Import the module

#-----------------------------------------------------------------------------------------------
# Functions
#-----------------------------------------------------------------------------------------------
function Show-Banner {
    $banner = @"
===============================================
           PCI DSS v3.2.1 Windows Audit Script
                Version 2.0, November 15, 2022

Questions? Bugs? Contact: Scott Ritchie, Aprio
(scott.ritchie@aprio.com)

Ensure that this Powershell is running as Administrator!!!
===============================================
"@
    Write-Output $banner
}

function Test-IsAdmin {
    # Check for Administrator privileges in a backward-compatible way

    # Try checking if the script is running with elevated privileges
    $isAdmin = $false

    # Some Windows versions may throw errors and break, so use try-catch block
    try {
        # Get the current Windows identity
        $windowsIdentity = [System.Security.Principal.WindowsIdentity]::GetCurrent()
        $windowsPrincipal = New-Object System.Security.Principal.WindowsPrincipal($windowsIdentity)

        # Check if the current user is in the Administrator role
        $isAdmin = $windowsPrincipal.IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator)
    }
    catch {
        # If the above fails, fall back to checking if the script is running with elevated privileges via User Account Control
        if ($env:USERNAME -eq 'Administrator') {
            $isAdmin = $true
        }
    }

    return $isAdmin
}

#-----------------------------------------------------------------------------------------------
# Main Logic
#-----------------------------------------------------------------------------------------------
# Start a stopwatch to measure the execution time of the script
$Stopwatch = [System.Diagnostics.Stopwatch]::StartNew()

try {
    # Show the banner
    Show-Banner

    # Check whether the Powershell is running as Administrator
    if ( -NOT (Test-IsAdmin)) {
        Write-Host "This script is NOT running with administrator privileges."
        throw "NOT running with administrator privileges."
    }

    # Import Active Directory Module
    if (Import-ADModule) {
        # Now you can use Active Directory cmdlets like Get-ADUser, Get-ADGroup, etc.
        Write-Output "Active Directory cmdlets can now be used."

        # Set an environment variable
        $env:IsImportADModule = "True"
    } else {
        Write-Error "Failed to load Active Directory module."
        
        # Set an environment variable
        $env:IsImportADModule = "False"
    }

    # 00_AllOutputs.txt
    # Initialize document that contains the outputs of every command
    # All commands will output to this file as well as an individual file per requirement.  
    InitializeCombinedOutputFile -CombinedOutputFile $CombinedOutputFile

    # 01_systeminfo.txt 
    # Output of systeminfo command
    Get-SystemInfo -outputFile $systemInfoFile -CombinedOutputFile $combinedOutputFile

    # 02_IPinfo.txt
    # Output IP address information
    Get-IPAddressInfo -outputFile $ipaddressInfoFile -CombinedOutputFile $combinedOutputFile

    # 03_LocalUsers.txt
    # Output IP address information
    Get-LocalUserInfo -outputFile $localUsersInfoFile -CombinedOutputFile $combinedOutputFile

    # 04_SNMPStrings.txt
    # Output SNMP community strings (if exists)
    Get-SNMPCommunityString -outputFile $SNMPStringsFile -CombinedOutputFile $combinedOutputFile

    # 05_SecurityPolicies-local.txt
    # Output security policies (local)
    Get-SecurityPolicies-Local -outputFile $SecurityPoliciesLocalFile -CombinedOutputFile $combinedOutputFile

    # 05_SecurityPolicies-domain.txt
    # Output security policies (domain)
    Get-SecurityPolicies-Domain -outputFile $SecurityPoliciesDomainFile -CombinedOutputFile $combinedOutputFile

    # 05_GroupPolicy.txt
    # Output Group Policy Result
    Get-GroupPolicyResult -outputFile $GroupPolicyResultFile -CombinedOutputFile $combinedOutputFile

    # 05b_AuditPolicy.txt
    # Output Audit Policy
    Get-AuditPolicy -outputFile $AuditPolicyFile -CombinedOutputFile $combinedOutputFile

    # OS Version Handling
    $winver = Get-WindowsVersion
    switch ($winver) {
        '5.1' { 
            WindowsXP
        }
        
        # 06_WindowsComponents32bit.txt, 17_TimeState_Status.txt, 00_AllOutputs.txt
        '5.2' {
            Windows2003 -outputFile $WindowsComponents32bitFile `
                        -timeStateStatusFile $timeStateStatusFile `
                        -CombinedOutputFile $combinedOutputFile
        }
    
        '6.0' { 
            # 07_InstalledPrograms_wmic.txt, 17_TimeState_Status.txt, 00_AllOutputs.txt
            WindowsVistaOr2008 -outputFile $InstalledProgramsWmicFile `
                        -timeStateStatusFile $timeStateStatusFile `
                        -CombinedOutputFile $combinedOutputFile
        }
    
        '6.1' { 
            # 06_WindowsComponents.txt, 17_TimeState_Status.txt, 00_AllOutputs.txt
            Windows7Or2008R2 -outputFile $WindowsComponentsFile `
                        -timeStateStatusFile $timeStateStatusFile `
                        -CombinedOutputFile $combinedOutputFile
        }

        '6.2' { 
            Windows8Or2012
        }
    
        '6.3' { 
            Windows8Or2012R2
        }
    
        '10.0' { 
            Windows10Or2016
        }
    
        default { 
            Write-Output "Unsupported Windows version: $winver"
        }    
    }

    # 07_InstalledPrograms_wmioutput.txt
    # Output Installed Programs with WMI
    Get-InstalledProgramsWithWMI -outputFile $InstalledPrograms_wmiFile -CombinedOutputFile $combinedOutputFile

    # 07_InstalledPrograms_regoutput.txt
    # Output Installed Programs from Registry
    Get-InstalledProgramsFromRegistry -outputFile $InstalledPrograms_regFile -CombinedOutputFile $combinedOutputFile
    
    # 08_RunningProcess_Overview.txt
    # Output running processes
    Get-RunningProcesses -outputFile $RunningProcessFile -CombinedOutputFile $combinedOutputFile

    # 09_Services_Overview.txt
    # Output All Services
    Get-AllServices -outputFile $ServicesFile -CombinedOutputFile $combinedOutputFile

    # 10_ListeningPorts.txt
    # Output Open Ports
    Get-OpenPorts -outputFile $ListeningPortsFile -CombinedOutputFile $combinedOutputFile

    # 11_InstalledPatches.txt
    # Get Installed Patches
    Get-Patches -outputFile $InstalledPatchesFile -CombinedOutputFile $combinedOutputFile

    # 12_LocalAdmins.txt
    # Get Local Admin Group Membership
    Get-LocalAdminGroupMembership -outputFile $LocalAdminsFile -CombinedOutputFile $combinedOutputFile

    # 13_LanmanHash.txt
    # Check LanMan Hash Status
    CheckLanManHashStatus -outputFile $LanmanHashFile -CombinedOutputFile $combinedOutputFile

    # 14_RDPSettings_Local.txt
    # Get Local RDP Settings
    Get-LocalRDPSettings -outputFile $RDPSettingsLocalFile -CombinedOutputFile $combinedOutputFile

    # 14_RDPSettings_Domain.txt
    # Get Domain Enforced RDP Settings
    Get-DomainEnforcedRDPSettings -outputFile $RDPSettingsDomainFile -CombinedOutputFile $combinedOutputFile

    # 14_RDPSettings_Master.txt
    # Get RDP Master Settings
    Get-RDPMasterSettings -outputFile $RDPMasterSettingsFile -CombinedOutputFile $combinedOutputFile

    # 15_ScreenTimeout.txt
    # Get Screensaver Settings
    Get-ScreensaverSettings -outputFile $ScreensaverFile -CombinedOutputFile $combinedOutputFile

    # 16_TimeSettings.txt
    # Get Time Settings
    Get-TimeSettings -outputFile $TimeSettingsFile -CombinedOutputFile $combinedOutputFile

    # 18_SnareSettings.txt
    # Get Snare Settings
    Get-SnareSettings -outputFile $SnareSettingsFile -CombinedOutputFile $combinedOutputFile

    # 19_LocalRDPUsers.txt
    # Get Local RDP Group Membership
    Get-LocalRDPGroupMembership -outputFile $LocalRDPUsersFile -CombinedOutputFile $combinedOutputFile

    # 20_LocalPowerUsers.txt
    # Get Local Power Users Group Membership
    Get-LocalPowerUsersGroupMembership -outputFile $LocalPowerUsersFile -CombinedOutputFile $combinedOutputFile

    # 20_LocalServerOperators.txt
    # Get Server Operators Group Membership
    Get-ServerOperatorsGroupMembership -outputFile $LocalServerOperatorsFile -CombinedOutputFile $combinedOutputFile

    # 21_StartupPrograms.txt
    # Output startup programs
    Get-StartupPrograms -outputFile $ListeningPortsFile -CombinedOutputFile $combinedOutputFile

    # 22_UserLogonHistory.txt
    # Output user logon history
    Get-UserLogonHistory -outputFile $UserLogonHistoryFile -CombinedOutputFile $combinedOutputFile

    # 23_Routes.txt
    # Output known routes
    Get-KnownRoutes -outputFile $KnownRoutesFile -CombinedOutputFile $combinedOutputFile

    # 24_FirewallRules.txt
    # Output firewall rules
    Get-FirewallRules -outputFile $FirewallRulesFile -CombinedOutputFile $combinedOutputFile

    # 25_PasswordPolicies.txt
    # Output password policies
    Get-PasswordPolicies -outputFile $PasswordPoliciesFile -CombinedOutputFile $combinedOutputFile

    # 26_FileShares.txt
    # Output all file shares for the server
    Get-FileShares -outputFile $FileSharesFile -CombinedOutputFile $combinedOutputFile

    # 27_DomainControllers.txt
    # Output all domain controllers
    Get-DomainControllers -outputFile $DomainControllersFile -CombinedOutputFile $combinedOutputFile

    # 28_FSMOservers.txt
    # Output all FSMO Servers
    Get-FSMOServers -outputFile $FSMOServersFile -CombinedOutputFile $combinedOutputFile

    # 29_GlobalCatalogServers.txt
    # Output Global Catalog Servers
    Get-GlobalCatalogServers -outputFile $GlobalCatalogServersFile -CombinedOutputFile $combinedOutputFile

    # 30_ADSecurityGroupsAndMembers.csv
    # Export AD Security Groups and their Members to a CSV file
    # Fetches data on security groups and their members, sorts by group name, and exports to $ADSecurityGroupsAndMembersCSVFile
    Get-ADSecurityGroupsData | Sort-Object Name | Export-Csv $ADSecurityGroupsAndMembersCSVFile -NoTypeInformation

    # 31_WindowsFeatures.txt
    # Get Windows Features
    Get-WindowsFeature -outputFile $WindowsFeaturesFile -CombinedOutputFile $combinedOutputFile

    # 32_EventLogs.txt
    # Get Event Logs
    Get-EventLogs -outputFile $EventLogsFile -CombinedOutputFile $combinedOutputFile

    # 00_AllOutputs.txt
    # Diagnosing Domain Controller for Health Issues
    DiagnosingDomainControllerHealthIssues -CombinedOutputFile $combinedOutputFile

    # 00_AllOutputs.txt
    # Getting Replication Summary
    Get-ReplicationSummary -CombinedOutputFile $combinedOutputFile

    # 00_AllOutputs.txt
    # Getting all OUs in Domain
    Get-AllOUsInDomain -CombinedOutputFile $combinedOutputFile

    # Analyze output files for security issues
    AnalyzeOutputFiles -openPortsFile $ListeningPortsFile -CombinedOutputFile $combinedOutputFile

    # Call the function to compress the evidence files, passing necessary parameters
    Compress-EvidenceFiles -EvidenceFilesFolder $OutputFolder -DestDirectory (Get-Location)

} catch {
    # If any errors occur, log the error message
    Write-Error "An error occurred: $_"
} finally {
    # Stop the stopwatch and calculate elapsed time
    $Stopwatch.Stop()

    # Output the elapsed time in seconds
    $finalTime = $Stopwatch.Elapsed.TotalSeconds
    Write-Output "Script execution completed in '$finalTime' seconds."
}

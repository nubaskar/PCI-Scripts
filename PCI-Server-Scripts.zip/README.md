# 🛡️ PCI Evidence Collection Scripts

## 📌 Overview
This package provides scripts to collect **PCI compliance evidence** from both **Linux** and **Windows** platforms. These scripts automate the process of gathering the necessary data to demonstrate compliance with PCI standards.

---

## ✅ Features
- **Cross-Platform Support**: Separate scripts for **Linux** and **Windows**.
- **Custom Output Directory**: Specify where the evidence is saved.
- **Verbose Mode**: Option for more detailed logs.
- **Simple Execution**: Easy-to-use command-line interface.

---

## 🔧 Prerequisites

- **For Linux**: A Unix-like system (e.g., Ubuntu, CentOS, etc.)
- **For Windows**: PowerShell (Windows 7 or later)

---

## 🐧 Linux: `PCI-Collector-v1.sh` Script

### Usage
To run the Linux version of the PCI collector script, use the following command:

```sh
./PCI-Collector-v1.sh [-d <output_dir>] [-v] [-h]
```

### Example
You can run the script as follows:

```sh
./PCI-Collector-v1.sh # The default output directory will be the hostname under current working directory

./PCI-Collector-v1.sh -d ./output_dir 

./PCI-Collector-v1.sh -d ./output_dir -v # -v enables verbose mode

./PCI-Collector-v1.sh -h # Displays help

```


## 🖥️ Windows: `PCI-Windows-Script-v2_1.ps1` Script

### Usage
To run the Windows version of the PCI collector script, use the following command:

```powershell
.\PCI-Windows-Script-v2_1.ps1 [-OutputFolder <output_dir>] [-v] [-h]
```

### Example
You can run the script as follows:

```powershell
.\PCI-Windows-Script-v2_1.ps1 # The default output directory will be the hostname under current working directory

.\PCI-Windows-Script-v2_1.ps1 -OutputFolder .\output_dir 

.\PCI-Windows-Script-v2_1.ps1 -OutputFolder .\output_dir -v # -v enables verbose mode

.\PCI-Windows-Script-v2_1.ps1 -h # Displays help

```


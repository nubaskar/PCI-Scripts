#!/bin/bash
#
# Copyright (c) 2025. All rights reserved.
# 
# This script is intended for collecting system information for PCI audits on Debian, RedHat, and CentOS Linux distributions.
# 
# Author: Uday Nachimuthu
# email: uday.nachimuthu@aprio.com
# Version: 1.0
# 
# This script is provided "as-is" without any warranties, express or implied, including
# but not limited to the warranties of merchantability or fitness for a particular purpose.
#
# Usage is subject to the terms and conditions set forth by Aprio.
#
# UPDATES:
# ~~~~~~~~
# 1) Added the following functions that are important for requirements 10 and 11:
#        - collect_system_logs
#        - collect_audit_logs
#        - collect_iptables_rules
# 2) Added distribution detection for Debian, RedHat, and CentOS.
# 3) Added log functionality to output messages to $output_dir/00_Console_Output.txt with timestamps.
# 4) Merged RH-PCI-Collector.sh logic for all Linux versions
#

#-----------------------------------------------------------------------------------------------
# Default values
#-----------------------------------------------------------------------------------------------
verbose=false
output_dir="./$(hostname)"

#-----------------------------------------------------------------------------------------------
# Valiables
#-----------------------------------------------------------------------------------------------
consolOutputFile="00_Console_Output.txt"

ipTablesRulesFile="1.1.iptables_rules.txt"
bootLoaderFile="1.1.2.a.bootloader.txt"
googleTraceFile="1.2.1.a.google_trace.txt"
ifconfigFile="1.2.1.a.ifconfig.txt"
systemConfigFile="1.2.1.a.systemconfig.txt"
yahooTraceFile="1.2.1.a.yahoo_trace.txt"
ipForwardFile="1.3.1.ip_forward.txt"
ipV6RouterFile="1.3.7.ipv6_router.txt"

cronEnabledFile="2.2.1.cron_enabled.txt"
cronTabsFile="2.2.1.crontabs.txt"
runningProcsFile="2.2.1.running_processes.txt"
userCronTabsFile="2.2.1.user_cron.txt"
consoleTimeOutFile="2.2.2.console_timeout.txt"
netstatFile="2.2.2.netstat.txt"
runningServicesFile="2.2.2.running_services.txt"
sshSettingsFile="2.2.2.ssh_settings.txt"
snmpStringsFile="2.2.2.snmp_strings.txt"
startupCmdsListFile="2.2.2.startup_list.txt"
unconfinedDaemonsFile="2.2.2.b.unconfined_daemons.txt"

gpgFile="3.6.5.gpg.txt"

xWindowFile="6.1.x_window.txt"
installedPkgsFile="6.1.a.installed_packages.txt"
patchesFile="6.1.a.patches.txt"
pkgReposFile="6.1.a.repositories.txt"
systemInforFile="6.1.a.systeminfo.txt"
selinuxFile="6.5.selinux.txt"

coreDumpFile="7.1.core_dump.txt"
localUsersFile="7.1.localusers.txt"
rcConfigFile="7.1.rc_config.txt"
localAdminsFile="7.2.2.local_admins.txt"

identityStatusFile="8.1.1.identity_status.txt"
identityLimitsFile="8.1.2.identity_limits.txt"
identityIntegrityFile="8.1.2.identity_integrity.txt"
accountsNoLoginFile="8.1.2.accounts_nologin.txt"
loginInactiveFile="8.1.8.login_inactive.txt"
rootDefaultsFile="8.2.root_defaults.txt"
userSecurityFile="8.5.9.user_sec.txt"

umaskBashrcFile="9.2.umask_bashrc.txt"

auditdSettingsFile="10.2.1.auditd_settings.txt"
authLogFile="10.2.1.auth_log.txt"
logPermissionsFile="10.2.1.logs_permission.txt"
syslogSettingsFile="10.2.1.syslog_settings.txt"
syslogFile="10.2.2.syslog.txt"
dmesgLogFile="10.2.3.dmesg_log.txt"
auditAvcFile="10.2.4.audit_avc.txt"
auditLogFile="10.2.4.audit_log.txt"
auditUserCmdFile="10.2.5.audit_user_cmd.txt"
ntpSettingsFile="10.4.1.a.ntp_settings.txt"

coreDumpsA3File="A3.2.5.core_dumps.txt"

#-----------------------------------------------------------------------------------------------
# Usage
#-----------------------------------------------------------------------------------------------
# Function to display usage
usage() {
    echo "Usage: $0 [-d <output_dir>] [-v] [-h]"
    echo "  -d <output_dir>    Specify the output directory (default: $output_dir)"
    echo "  -v                 Enable verbose mode"
    echo "  -h                 Show this help message"
    exit 1
}

#-----------------------------------------------------------------------------------------------
# Arguments Processing
#-----------------------------------------------------------------------------------------------
# Check if no arguments are passed
if [ $# -eq 0 ]; then
    usage
fi

# Parse command line arguments
while getopts ":d:vh" opt; do
    case $opt in
        d)
            output_dir=$OPTARG
            ;;
        v)
            verbose=true
            ;;
        h)
            usage
            ;;
        \?)
            echo "Invalid option: -$OPTARG" >&2
            usage
            ;;
        :)
            echo "Option -$OPTARG requires an argument." >&2
            usage
            ;;
    esac
done

# Check if the script is being run as root
if [ "$(id -u)" -ne 0 ]; then
    echo 'ERROR: You need to be root to run this script. (exiting)'
    exit 1
fi

# Create the output directory, remove it if it already exists
if [ -d "$output_dir" ]; then
    echo "Directory $output_dir already exists. Removing it."
    rm -rf "$output_dir"
fi

echo "Creating Directory $output_dir ..."
mkdir -p "$output_dir"

#-----------------------------------------------------------------------------------------------
# Functions
#-----------------------------------------------------------------------------------------------
# Log function for verbosity with timestamp
log() {
    timestamp=$(date "+%Y-%m-%d %H:%M:%S")
    echo "$timestamp - $1" >> "$output_dir/$consolOutputFile"
    if [ "$verbose" = true ]; then
        echo "$timestamp - $1"
    fi
}

# Function to check if a command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Detect the Linux distribution
detect_distribution() {
    if [ -f /etc/os-release ]; then
        . /etc/os-release
        DISTRO=$ID
    elif [ -f /etc/redhat-release ]; then
        DISTRO="redhat"
    else
        DISTRO="unknown"
    fi

    log "Detected Linux Distribution: $DISTRO"
}

# Perform internet connection tests (network connectivity)
perform_network_connectivity() {
    log '1/23: Performing Internet Connection Tests'

    # traceroute
    if command_exists "traceroute"; then
        traceroute www.google.com >> "$output_dir/$googleTraceFile" &
        p1=$!
        traceroute www.yahoo.com >> "$output_dir/$yahooTraceFile" &
        p2=$!

        wait $p1 $p2
    else
        log "    *** ERROR: traceroute command not found. Skipping Internet Connection Tests."
    fi

    # Check whether the host is set to act as router
    if command_exists "sysctl"; then
        sysctl net.ipv4.ip_forward >> "$output_dir/$ipForwardFile"
    else
        log "    *** ERROR: sysctl command not found. Skipping Internet Connection Tests."
    fi
}

# Collect system information
collect_system_info() {
    log '2/23: Getting System Info'

    # Gather information for 6.1.a System Info
    {
        # /etc/issue
        f="/etc/issue"
        echo -e "#####\n##### $f\n#####"
        cat $f

        # /etc/*-release
        for f in /etc/*-release; do
            echo -e "\n#####\n##### $f\n#####"
            cat $f
        done

        # /etc/fstab
        f="/etc/fstab"
        echo -e "\n#####\n##### $f\n#####"
        cat $f

        # Host and OS information
        echo -e "\n#####\n##### Host and OS information\n#####"
        echo "Host Name: $(hostname)"
        echo "Date Executed: $(date)"
        echo "OS Version: $(uname -a)"
        
    } >> "$output_dir/$systemInfoFile"

    # lspci: Gather all PCI devices (6.1.a)
    echo -e "\n#####\n##### lspci: Gather all PCI devices\n#####" >> "$output_dir/$systemInfoFile"
    if command_exists "lspci"; then
        lspci >> "$output_dir/$systemInfoFile"
    else
        log "    *** ERROR: lspci command not found. Skipping PCI devices list."
    fi

    # Gather information for 6.5 selinux
    echo -e "\n#####\n##### Gather selinux information\n#####" >> "$output_dir/$selinuxFile"
    if command_exists "getenforce" || command_exists "sestatus"; then
        {
            # /sbin/getenforce
            f="/sbin/getenforce"
            echo -e "\n#####\n##### Output of $f\n#####"
            $f

            # /etc/selinux/config
            f="/etc/selinux/config"
            echo -e "\n#####\n##### $f\n#####"
            cat $f

            # /boot/grub2/grub.cfg
            f="/boot/grub2/grub.cfg"
            echo -e "\n#####\n##### selinux information in $f\n#####"
            grep "^\s*linux" $f

            # /sbin/sestatus
            f="/sbin/sestatus"
            echo -e "\n#####\n##### Output of $f\n#####"
            $f
        } >> "$output_dir/$selinuxFile"
    else
        log "    *** ERROR: getenforce or sestatus commands are not found. Skipping selinux information."
    fi

    # Check whether setroubleshoot is installed
    detect_distribution

    echo -e "\n#####\n##### Checking whether setroubleshoot is installed\n#####" >> "$output_dir/$selinuxFile"
    if [ "$DISTRO" == "debian" ] || [ "$DISTRO" == "ubuntu" ]; then
        if command_exists "dpkg"; then
            dpkg --list | grep setroubleshoot >> "$output_dir/$selinuxFile"
        else
            log "    *** ERROR: dpkg command not found. Skipping Installed Packages Info."
        fi
    elif [ "$DISTRO" == "redhat" ] || [ "$DISTRO" == "centos" ]; then
        if command_exists "yum"; then
            yum list installed | grep setroubleshoot >> "$output_dir/$selinuxFile"
        else
            log "    *** ERROR: yum command not found. Skipping Installed Packages Info."
        fi
    elif [ "$DISTRO" = "fedora" ]; then
        if command_exists dnf; then
            dnf list --installed | grep setroubleshoot >> "$output_dir/$selinuxFile"
        else
            log "    *** ERROR: dnf command not found. Skipping Installed Packages Info."
        fi
    else
        log "    *** ERROR: Unsupported distribution. Skipping Package Info."
    fi

    # Capture unconfined daemons (2.2.2.b)
    echo -e "\n#####\n##### unconfined daemons list\n#####" >> "$output_dir/$unconfinedDaemonsFile"
    ps -eZ | egrep -vw "tr|ps|egrep|bash|awk|CMD" | tr ':' ' ' | awk '{ print $NF }' >> "$output_dir/$unconfinedDaemonsFile"
}

# Collect network adapter information
collect_network_info() {
    log '3/23: Getting Network information'

    # Collect ifconfig output (1.2.1.a)
    if command_exists "ifconfig"; then
        ifconfig -a >> "$output_dir/$ifconfigFile"
    else
        log "    *** ERROR: ifconfig command not found. Skipping Network Adapter Info."
    fi

    # Collect ipv6 information (1.3.7)
    if command_exists "sysctl"; then
        sysctl net.ipv6.conf.all.accept_ra \
               net.ipv6.conf.default.accept_ra \
               net.ipv6.conf.all.accept_redirects \
               net.ipv6.conf.default.accept_redirects >> "$output_dir/$ipV6RouterFile"
    else
        log "    *** ERROR: sysctl command not found. Skipping Internet Connection Tests."
    fi

    # Collect iptables information (1.1)
    if command_exists "iptables"; then
        iptables -L -v -n >> "$output_dir/$ipTablesRulesFile"  # Collect firewall rules for review and compliance
    else
        log "    *** ERROR: iptables command not found. Skipping iptables rules."
    fi
}

# Collect local user information
collect_local_users() {
    log '4/23: Querying Local User Information'

    # Collect user information
    {
        for f in /etc/passwd /etc/shadow; do
            echo -e "#####\n##### $f\n#####"
            cat $f
            echo -e "\n"
        done
    } >> "$output_dir/$localUsersFile"

    # Collect identity status
    {
        echo -e "#####\n##### stat /etc/passwd\n#####"
        stat /etc/passwd
    
        echo -e "\n#####\n##### stat /etc/shadow\n#####"
        stat /etc/shadow

        echo -e "\n#####\n##### Output of 'who' command\n#####"
        who

        echo -e "\n#####\n##### Output of 'lastlog' command\n#####"
        lastlog

        echo -e "\n#####\n##### /etc/group\n#####"
        cat /etc/group
    } >> "$output_dir/$identityStatusFile"

    # Collect identity limits
    {
        echo -e "#####\n##### /etc/login.defs parameters\n#####"
        cat /etc/login.defs | egrep -v "^#|^$" | egrep "PASS_MAX_DAYS|PASS_MIN_DAYS|PASS_WARN_AGE"
    } >> "$output_dir/$identityLimitsFile"

    # Collect identity integrity
    {
        for f in /etc/passwd /etc/shadow; do
            echo -e "#####\n##### pwck -r $f\n#####"
            pwck -r $f
            echo "\n"
        done
    } >> "$output_dir/$identityIntegrityFile"

    # Collect privileged user ids with valid shell
    {
        echo -e "#####\n##### Privileged user IDs with valid shell in /etc/passwd\n#####"
        egrep -v "^\+" /etc/passwd | awk -F: '($1!="root" && $1!="sync" && $1!="shutdown" && $1!="halt" && $3<1000 && $7!~"nologin" && $7!~"false") {print}'
    } >> "$output_dir/$accountsNoLoginFile"

    # Collect grace period for disabling users after max age exceeded
    {
        echo -e "#####\n##### Grace period for disabling users after max age exceeded\n#####"
        useradd -D | grep INACTIVE
    } >> "$output_dir/$loginInactiveFile"

    # Collect root defauts
    {
        echo -e "#####\n##### default group of root user\n#####"
        grep "^root:" /etc/passwd | cut -f4 -d:

        echo -e "\n#####\n##### default umask in /etc/profile\n#####"
        grep "umask" /etc/profile

        echo -e "\n#####\n##### cat /etc/securetty\n#####"
        cat /etc/securetty

        echo -e "\n#####\n##### su access: grep pam_wheel.so /etc/pam.d/su\n#####"
        grep pam_wheel.so /etc/pam.d/su

        echo -e "\n#####\n##### su access: grep wheel /etc/group\n#####"
        grep wheel /etc/group
    } >> "$output_dir/$rootDefaultsFile" 2>&1

    # Collect umask in /etc/bashrc or /etc/bash.bashrc
    detect_distribution

    {
        case "$DISTRO" in
            "redhat"|"centos"|"fedora")
                grep "umask" /etc/bashrc
                ;;
            "ubuntu"|"debian")
                grep "umask" /etc/bash.bashrc
                ;;
            *)
                echo "Unsupported distribution: $DISTRO"
                ;;
        esac
    } >> "$output_dir/$umaskBashrcFile"
}

# Collect SNMP configuration
collect_snmp_config() {
    log '5/23: Querying SNMP Config'

    egrep -v -e '#|^$' /etc/cups/snmpd.conf >> "$output_dir/$snmpStringsFile"
    ulimit -c >> "$output_dir/$coreDumpFile"
}

# Collect kernel configuration
collect_kernel_config() {
    {
        log '6/23: Getting Kernel Configuration'

        # Kernel configuration
        sysctl -A | tee "$output_dir/$systemConfigFile"

        # Kernel Limits
        echo -e "#####\n##### grep 'hard core' /etc/security/limits.conf\n#####"
        grep "hard core" /etc/security/limits.conf

        echo -e "\n#####\n##### grep 'hard core' /etc/security/limits.d/*\n#####"
        grep "hard core" /etc/security/limits.d/*

        echo -e "\n#####\n##### sysctl fs.suid_dumpable\n#####"
        sysctl fs.suid_dumpable
    } >> "$output_dir/$coreDumpsA3File" 2>&1
}

# Collect package information (using appropriate package manager based on distro)
collect_package_info() {
    detect_distribution
    log '7/23: Getting Package Information'


    if [ "$DISTRO" == "debian" ] || [ "$DISTRO" == "ubuntu" ]; then
        if command_exists "dpkg"; then
            # Get installed packages
            dpkg --list >> "$output_dir/$installedPkgsFile"

            # Get gpg info
            echo -e "#####\n##### grep '^gpgcheck' /etc/apt/sources.list\n#####" >> "$output_dir/$gpgFile"
            grep "^gpgcheck" /etc/apt/sources.list >> "$output_dir/$gpgFile"

            echo -e "\n#####\n##### grep '^gpgcheck' /etc/apt/sources.list.d/*\n#####" >> "$output_dir/$gpgFile"
            grep "^gpgcheck" /etc/apt/sources.list.d/* >> "$output_dir/$gpgFile"

            echo -e "\n#####\n##### dpkg -l | grep keyring\n#####" >> "$output_dir/$gpgFile"
            dpkg -l | grep keyring >> "$output_dir/$gpgFile"

            # Get x_window package info
            dpkg -l | grep 'xorg-x11*' >> "$output_dir/$xWindowFile"
        else
            log "    *** ERROR: dpkg command not found. Skipping Installed Packages Info."
        fi
    elif [ "$DISTRO" == "redhat" ] || [ "$DISTRO" == "centos" ]; then
        if command_exists "yum"; then
            # Get installed packages
            yum list installed >> "$output_dir/$installedPkgsFile"

            # Get gpg info
            echo -e "#####\n##### grep '^gpgcheck' /etc/yum.conf\n#####" >> "$output_dir/$gpgFile"
            grep "^gpgcheck" /etc/yum.conf >> "$output_dir/$gpgFile"

            echo -e "\n#####\n##### grep '^gpgcheck' /etc/yum.repos.d/*\n#####" >> "$output_dir/$gpgFile"
            grep "^gpgcheck" /etc/yum.repos.d/* >> "$output_dir/$gpgFile"

            echo -e "\n#####\n##### yum list gpg-pubkey\n#####" >> "$output_dir/$gpgFile"
            yum list gpg-pubkey >> "$output_dir/$gpgFile"

            # Get x_window package info
            yum list installed xorg-x11* >> "$output_dir/$xWindowFile"
        else
            log "    *** ERROR: yum command not found. Skipping Installed Packages Info."
        fi





        elif [ "$DISTRO" = "fedora" ]; then
        if command_exists dnf; then
            dnf list --installed >> "$output_dir/$installedPkgsFile"
            
            # Get gpg info
            echo -e "\n#####\n##### rpm -qa 'gpg-pubkey*'\n#####" >> "$output_dir/$gpgFile"
            rpm -qa 'gpg-pubkey*' >> "$output_dir/$gpgFile"

            echo -e "\n#####\n##### grep '^gpgcheck' /etc/yum.repos.d/*\n#####" >> "$output_dir/$gpgFile"
            grep "^gpgcheck" /etc/yum.repos.d/* >> "$output_dir/$gpgFile"

            # Get x_window package info
            dnf list installed xorg-x11* >> "$output_dir/$xWindowFile"
        else
            log "    *** ERROR: dnf command not found. Skipping Installed Packages Info."
        fi

    else
        log "    *** ERROR: Unsupported distribution. Skipping Package Info."
    fi
}

# Collect running processes
collect_running_processes() {
    log '8/23: Listing Running Processes'

    # Running processes
    echo -e "#####\n##### ps -ef\n#####" >> "$output_dir/$runningProcsFile"
    ps -ef >> "$output_dir/$runningProcsFile"

    echo -e "#####\n##### ps -aux\n#####" >> "$output_dir/$runningProcsFile"
    ps -ef >> "$output_dir/$runningProcsFile"

    # bootloader
    detect_distribution
    f=""
    case "$DISTRO" in
        "ubuntu"|"debian")
            f="/boot/grub/grub.cfg"
            ;;

        "redhat"|"centos"|"fedora")
            f="/boot/grub2/grub.cfg"
            ;;

        *)
            log "    *** WARNING: Unsupported distribution $DISTRO, skipping log collection."
            ;;
    esac

    if [ -z $f]; then
        echo -e "\n#####\n##### stat $f\n#####" >> "$output_dir/$bootLoaderFile"
        stat $f >> "$output_dir/$bootLoaderFile"

        echo -e "\n#####\n##### grep '^set superusers' $f\n#####" >> "$output_dir/$bootLoaderFile"
        grep "^set superusers" $f >> "$output_dir/$bootLoaderFile"

        echo -e "\n#####\n##### grep '^sepassword' $f\n#####" >> "$output_dir/$bootLoaderFile"
        grep "^password" $f >> "$output_dir/$bootLoaderFile"
    fi
}

# Collect running services
collect_running_services() {
    log '9/23: Listing Running Services'

    if command_exists "systemctl"; then
        # For systemd-based systems (Debian 8+, CentOS 7+, RHEL 7+)
        systemctl list-units --type=service --state=running | awk '{print $1}' | sort >> "$output_dir/$runningServicesFile"
    elif command_exists "service"; then
        # For SysVinit systems (older Debian/Ubuntu, CentOS 6, RHEL 6)
        service --status-all | grep + | awk '{print $4}' | sort >> "$output_dir/$runningServicesFile"
    else
        log "    *** ERROR: Neither systemctl nor service command found. Skipping Running Services."
    fi
}


# Collect startup commands
collect_startup_commands() {
    log '10/23: Listing Startup Commands'

    if command_exists "systemctl"; then
        # For systemd-based systems (Debian 8+, CentOS 7+, RHEL 7+)
        systemctl list-units --type=service --state=enabled >  "$output_dir/$startupCmdsListFile"
    elif command_exists "service"; then
        # For SysVinit systems (older Debian/Ubuntu, CentOS 6, RHEL 6)
        chkconfig --list | grep 'on' >  "$output_dir/$startupCmdsListFile"
    else
        log "    *** ERROR: Neither systemctl nor service command found. Skipping Running Services."
    fi
}

# Collect remote connection configuration
collect_remote_connection_config() {
    log '11/23: Listing Remote Connection Configuration'

    egrep -v -e '^#|^$' /etc/rc.local >> "$output_dir/$rcConfigFile"
}

# Collect user crontab info
collect_user_crontabs() {
    log '12/23: Listing User Crontabs'

    # Check crond is enabled
    echo -e "#####\n##### systemctl is-enabled crond\n#####" >> "$output_dir/$cronEnabledFile"
    systemctl is-enabled crond >> "$output_dir/$cronEnabledFile"

    # Collect stat of crontab files
    {
        for f in /etc/crontab /etc/cron.hourly /etc/cron.daily /etc/cron.weekly /etc/cron.monthly /etc/cron.d; do
            echo -e "#####\n##### stat $f\n#####"
            stat $f
            echo -e "\n"
        done
    } >> "$output_dir/$cronTabsFile"

    # Collect user cron information
    if command_exists "crontab"; then
        {
            for user in $(cut -f 1 -d ':' /etc/passwd); do
                echo -e "#####\n##### crontab -u '$user' -l\n#####"
                crontab -u "$user" -l
                echo -e "\n"
            done
         } >> "$output_dir/$userCronTabsFile"
    else
        log "    *** ERROR: crontab command not found. Skipping User Crontabs."
    fi
}

# Collect active ports
collect_active_ports() {
    log '13/23: Listing Active Ports'

    if command_exists "netstat"; then
        netstat -a | egrep -e 'LISTEN' >> "$output_dir/$netstatFile"
    else
        log "    *** ERROR: netstat command not found. Skipping Active Ports."
    fi
}

# Collect installed patches
collect_installed_patches() {
    log '14/23: Listing Installed Patches'

    tail /var/log/dpkg.log -n 2000 >> "$output_dir/$patchesFile"
}

# Collect package repositories
collect_package_repositories() {
    log '15/23: Listing Package Repositories'
        
    # Detect the distribution first
    detect_distribution

    case "$DISTRO" in
        "debian" | "ubuntu")
            echo "Listing package repositories for Debian-based distribution..."

            # List the repositories from /etc/apt/sources.list and /etc/apt/sources.list.d/
            if [ -f /etc/apt/sources.list ]; then
                echo -e "#####\n##### cat /etc/apt/sources.list\n#####" >> "$output_dir/$pkgReposFile"
                cat /etc/apt/sources.list >> "$output_dir/$pkgReposFile"
            fi

            if [ -d /etc/apt/sources.list.d ]; then
                for f in /etc/apt/sources.list.d/*; do
                    echo -e "#####\n##### cat $f | grep -v '^#'\n#####" >> "$output_dir/$pkgReposFile"
                    cat $f | grep -v "^#" >> "$output_dir/$pkgReposFile" 2>&1
                    echo -e "\n" >> "$output_dir/$pkgReposFile"
                done
            fi
            ;;

        "redhat" | "centos" | "fedora")
            echo "Listing package repositories for RedHat-based distribution..."

            # Check for `yum` or `dnf` repository files
            if [ -d /etc/yum.repos.d ]; then
                for f in /etc/yum.repos.d/*.repo; do
                    echo -e "#####\n##### cat $f\n#####" >> "$output_dir/$pkgReposFile"
                    cat $f >> "$output_dir/$pkgReposFile" 2>&1
                    echo -e "\n" >> "$output_dir/$pkgReposFile"
                done
            fi

            # For newer versions of Fedora (which use dnf)
            if [ -d /etc/dnf ]; then
                cat /etc/dnf/dnf.conf >> "$output_dir/$pkgReposFile"
            fi
            ;;

        *)
            # If the distribution is unknown or unsupported
            echo "Unknown or unsupported distribution. Unable to collect package repositories."
            ;;
    esac
}

# Collect sudoers information
collect_sudoers() {
    log '16/23: Listing Sudoers'

    echo -e "#####\n##### sudoers from /etc/sudoers\n#####" >> "$output_dir/$localAdminsFile"
    egrep -v -e '#|^$' /etc/sudoers >> "$output_dir/$localAdminsFile"

    # Check if @includedir /etc/sudoers.d exists in /etc/sudoers
    if grep -q "@includedir /etc/sudoers.d" /etc/sudoers; then
        log "    Found @includedir /etc/sudoers.d, collecting sudoers.d files."

        # Loop through all files in /etc/sudoers.d/
        for sudoers_file in /etc/sudoers.d/*; do
            echo -e "\n#####\n##### sudoers from $sudoers_file\n#####" >> "$output_dir/$localAdminsFile"

            if [ -f "$sudoers_file" ]; then
                # Collect uncommented lines from each sudoers file in /etc/sudoers.d
                egrep -v -e '#|^$' "$sudoers_file" >> "$output_dir/$localAdminsFile" 2>&1
            fi
        done
    else
        log "    No @includedir /etc/sudoers.d found, skipping."
    fi

    # Find root users in /etc/passwd
    echo -e "\n#####\n##### Users with root is '0' in /etc/passwd\n#####" >> "$output_dir/$localAdminsFile"
    awk -F':' '($3 == "0") {print}' /etc/passwd >> "$output_dir/$localAdminsFile"

    # Find users with no password set in /etc/shadow
    echo -e "\n#####\n##### Users with no password set in /etc/shadow\n#####" >> "$output_dir/$localAdminsFile"
    awk -F':' '($2 == "") {print}' /etc/shadow >> "$output_dir/$localAdminsFile"

    # sulogin for rescue mode
    echo -e "\n#####\n##### sulogin for rescue mode: grep sulogin /usr/lib/systemd/system/rescue.service\n#####" >> "$output_dir/$localAdminsFile"
    grep sulogin /usr/lib/systemd/system/rescue.service >> "$output_dir/$localAdminsFile"

    # sulogin for emergency mode
    echo -e "\n#####\n##### sulogin for emergency mode: grep sulogin /usr/lib/systemd/system/emergency.service\n#####" >> "$output_dir/$localAdminsFile"
    grep sulogin /usr/lib/systemd/system/emergency.service >> "$output_dir/$localAdminsFile"
}

# Collect SSH settings
collect_ssh_settings() {
    log '17/23: Getting SSH Configuration'

    egrep -v -e '#|^$' /etc/ssh/sshd_config >> "$output_dir/$sshSettingsFile"
}

# Collect user security settings
collect_user_security() {
    log '18/23: Getting User Security Settings'

    egrep -v -e '#|^$' /etc/pam.d/common-password >> "$output_dir/$userSecurityFile"
}

# Collect console timeout setting
collect_console_timeout() {
    log '19/23: Querying Console Timeout'

    echo "$TMOUT" >> "$output_dir/$consoleTimeOutFile"
}

# Collect NTP settings
collect_ntp_settings() {
    log '20/23: Querying NTP Settings'

    {
        echo -e "#####\n##### All uncommened lines from /etc/ntp.conf\n#####"
        egrep -v -e '#|^$' /etc/ntp.conf

        echo -e "\n#####\n##### ntpq -p localhost\n#####"
        ntpq -p localhost

        if command_exists "systemctl"; then
            # For systemd-based systems (Debian 8+, CentOS 7+, RHEL 7+)
            echo -e "\n#####\n##### systemctl status ntpd\n#####"
            systemctl status ntpd
        elif command_exists "service"; then
            # For SysVinit systems (older Debian/Ubuntu, CentOS 6, RHEL 6)
            echo -e "\n#####\n##### service ntpd status\n#####"
            service ntpd status 2>&1
        else
            log "    *** ERROR: Neither systemctl nor service command found. Skipping Running Services."
        fi

        echo -e "\n#####\n##### Uncommented lines from /etc/cron.daily/ntp\n#####"
        egrep -v -e '^#|^$' /etc/cron.daily/ntp
    } >> "$output_dir/$ntpSettingsFile"
}

# Collect system log settings
collect_syslog_settings() {
    log '21/23: Getting System Log Settings'

    RSYSLOG=false
    SYSLOGNG=false
    AUDITD=false

    # Detect the distribution first
    detect_distribution

    # Check whether rsyslog or syslog-ng is installed
    case "$DISTRO" in
        "debian" | "ubuntu")
            # Check for rsyslog
            if dpkg -l | grep -q rsyslog; then
                RSYSLOG=true

                echo -e "\n#####\n##### rsyslog package is installed: dpkg -l | grep -q rsyslog\n#####" >> "$output_dir/$syslogSettingsFile"
                dpkg -l | grep -q rsyslog >> "$output_dir/$syslogSettingsFile"   
            fi
            
            if dpkg -l | grep -q syslog-ng; then
                SYSLOGNG=true        

                echo -e "\n#####\n##### syslog-ng package is installed: dpkg -l | grep -q syslog-ng\n#####" >> "$output_dir/$syslogSettingsFile"
                dpkg -l | grep -q syslog-ng >> "$output_dir/$syslogSettingsFile"
            fi

            if dpkg -l | grep -q auditd; then
                AUDITD=true        

                echo -e "\n#####\n##### auditd package is installed: dpkg -l | grep -q auditd\n#####" >> "$output_dir/$auditdSettingsFile"
                dpkg -l | grep -q auditd >> "$output_dir/$auditdSettingsFile"
            fi
            ;;
        
        "redhat" | "centos" | "fedora")
            # Check for rsyslog
            if rpm -qa | grep -q rsyslog; then
                RSYSLOG=true

                echo -e "\n#####\n##### rsyslog package is installed: rpm -qa | grep -q rsyslog\n#####" >> "$output_dir/$syslogSettingsFile"
                rpm -qa | grep -q rsyslog >> "$output_dir/$syslogSettingsFile"   
            fi

            if rpm -qa | grep -q syslog-ng; then
                SYSLOGNG=true

                echo -e "\n#####\n##### syslog-ng package is installed: rpm -qa | grep -q syslog-ng\n#####" >> "$output_dir/$syslogSettingsFile"
                rpm -qa | grep -q syslog-ng >> "$output_dir/$syslogSettingsFile"   
            fi

            if rpm -qa | grep -q audit; then
                AUDITD=true

                echo -e "\n#####\n##### audit package is installed: rpm -qa | grep -q audit\n#####" >> "$output_dir/$auditdSettingsFile"
                rpm -qa | grep -q audit >> "$output_dir/$auditdSettingsFile"   
            fi
            ;;
        
        *)
            log "Unknown or unsupported distribution. Unable to check syslog configuration."
            ;;
    esac

    # Collect PCI evidences
    if $RSYSLOG; then
        # Validate rsyslog configurations
        if [ -f /etc/rsyslog.conf ]; then
            echo -e "\n#####\n##### Uncommented lines from /etc/rsyslog.conf\n#####" >> "$output_dir/$syslogSettingsFile"
            egrep -v -e '#|^$' /etc/rsyslog.conf >> "$output_dir/$syslogSettingsFile"

            if command_exists "systemctl"; then
                # For systemd-based systems (Debian 8+, CentOS 7+, RHEL 7+)
                echo -e "\n#####\n##### systemctl is-enabled rsyslog\n#####" >> "$output_dir/$syslogSettingsFile"
                systemctl is-enabled rsyslog >> "$output_dir/$syslogSettingsFile"
            elif command_exists "chkconfig"; then
                # For SysVinit systems (older Debian/Ubuntu, CentOS 6, RHEL 6)
                echo -e "\n#####\n##### chkconfig --list rsyslog| grep -i 'on'\n#####" >> "$output_dir/$syslogSettingsFile"
                chkconfig --list rsyslog| grep -i "on" >> "$output_dir/$syslogSettingsFile"
            else
                log "    *** ERROR: Neither systemctl nor service command found. Skipping Running Services."
            fi
        else
            log "rsyslog configuration file /etc/rsyslog.conf not found!"
        fi
    fi

    if $SYSLOGNG; then
        # Validate syslog-ng configurations
        if [ -f /etc/syslog-ng/syslog-ng.conf ]; then
            echo -e "\n#####\n##### Uncommented lines from /etc/syslog-ng/syslog-ng.conf\n#####" >> "$output_dir/$syslogSettingsFile"
            egrep -v -e '#|^$' /etc/syslog-ng/syslog-ng.conf >> "$output_dir/$syslogSettingsFile"

            if command_exists "systemctl"; then
                # For systemd-based systems (Debian 8+, CentOS 7+, RHEL 7+)
                echo -e "\n#####\n##### systemctl is-enabled syslog-ng\n#####" >> "$output_dir/$syslogSettingsFile"
                systemctl is-enabled syslog-ng >> "$output_dir/$syslogSettingsFile"
            elif command_exists "chkconfig"; then
                # For SysVinit systems (older Debian/Ubuntu, CentOS 6, RHEL 6)
                echo -e "\n#####\n##### chkconfig --list syslog-ng| grep -i 'on'\n#####" >> "$output_dir/$syslogSettingsFile"
                chkconfig --list syslog-ng| grep -i "on" >> "$output_dir/$syslogSettingsFile"
            else
                log "    *** ERROR: Neither systemctl nor service command found. Skipping Running Services."
            fi
        else
            log "syslog-ng configuration file /etc/syslog-ng/syslog-ng.conf not found!"
        fi
    fi

    if $AUDITD; then
        if [ -f /etc/audit/auditd.conf ]; then
            echo -e "\n#####\n##### Uncommented lines from /etc/audit/auditd.conf\n#####" >> "$output_dir/$auditdSettingsFile"
            egrep -v -e '#|^$' /etc/audit/auditd.conf >> "$output_dir/$auditdSettingsFile"
        else
            log "auditd configuration file /etc/audit/auditd.conf not found!"
        fi
    fi

    # Check rsyslog and syslog-ng are not installed
    if ! $RSYSLOG && ! $SYSLOGNG; then
        log "Neither rsyslog nor syslog-ng is installed."
    fi

    # Check auditd is not installed
    if ! $AUDITD; then
        log "auditd is installed."
    fi

    # Finally list permissions of all files under /var/log
    echo -e "\n#####\n##### Files under /var/log\n#####" >> "$output_dir/$logPermissionsFile"
    find /var/log -type f -ls >> "$output_dir/$logPermissionsFile"
}

# NEW: Collect system logs
collect_system_logs() {
    log '22/23: Collecting System Logs'

    case "$DISTRO" in
        "ubuntu"|"debian")
            # Ubuntu/Debian-based systems
            if [ -f /var/log/auth.log ]; then
                cp /var/log/auth.log "$output_dir/$authLogFile"  # Authentication logs
            else
                log "    *** WARNING: /var/log/auth.log not found, skipping."
            fi

            if [ -f /var/log/syslog ]; then
                cp /var/log/syslog "$output_dir/$syslogFile"  # General system logs
            else
                log "    *** WARNING: /var/log/syslog not found, skipping."
            fi
            ;;

        "redhat"|"centos"|"fedora")
            # RedHat/CentOS/Fedora-based systems
            if [ -f /var/log/messages ]; then
                cp /var/log/messages "$output_dir/$syslogFile"  # General system logs
            else
                log "    *** WARNING: /var/log/messages not found, skipping."
            fi

            if [ -f /var/log/secure ]; then
                cp /var/log/secure "$output_dir/$authLogFile"  # Authentication logs
            else
                log "    *** WARNING: /var/log/secure not found, skipping."
            fi
            ;;

        *)
            log "    *** WARNING: Unsupported distribution $DISTRO, skipping log collection."
            ;;
    esac

    # Collect kernel logs
    dmesg >> "$output_dir/$dmesgLogFile"  # Kernel logs for hardware and system initialization
}

# NEW: Collect audit logs
collect_audit_logs() {
    log '23/23: Collecting Audit Logs'

    if command_exists "ausearch"; then
        # Collect audit logs related to file access control and user commands
        ausearch -m avc -ts recent >> "$output_dir/$auditAvcFile"
        ausearch -m user_cmd -ts recent >> "$output_dir/$auditUserCmdFile"
    else
        log "Audit logs not available. (auditd not installed)" >> "$output_dir/$auditLogFile"
    fi
}

#-----------------------------------------------------------------------------------------------
# Main logic
#-----------------------------------------------------------------------------------------------
{
    detect_distribution
    perform_traceroutes
    collect_system_info
    collect_network_info
    collect_local_users
    collect_snmp_config
    collect_kernel_config
    collect_package_info
    collect_running_processes
    collect_running_services
    collect_startup_commands
    collect_remote_connection_config
    collect_user_crontabs
    collect_active_ports
    collect_installed_patches
    collect_package_repositories
    collect_sudoers
    collect_ssh_settings
    collect_user_security
    collect_console_timeout
    collect_ntp_settings
    collect_syslog_settings
    collect_system_logs
    collect_audit_logs
} 2>/dev/null

echo -e "\nPlease wait a moment for all commands to finish.\n"

wait

echo ""
echo "Collection Complete. Output files located in $output_dir"
echo ""

# Delete the older tarred and zipped file
if [ -f *.tar.gz ]; then
    echo "Removing older compressed files ..."
    rm -rf "*.tar.gz"
fi

# Tar up output into nice, neat file for collection
dir="${output_dir%/}"                 
base="$(basename "$dir")"             
parent="$(dirname "$dir")"            

archive="$parent/${base}.tar.gz"

echo "Create compressed tar.gz of '$dir' -> '$archive' ..."
tar -C "$parent" -cvpzf "$archive" "$base"

echo ""
echo "Compressed tar.gz of '$dir' is Complete."
echo ""

exit 0

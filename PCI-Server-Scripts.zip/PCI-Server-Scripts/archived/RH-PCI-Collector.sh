#!/bin/bash

#############
# References:
# https://access.redhat.com/documentation/en-US/Red_Hat_Enterprise_Linux/7/pdf/Security_Guide/Red_Hat_Enterprise_Linux-7-Security_Guide-en-US.pdf
# https://benchmarks.cisecurity.org/tools2/linux/CIS_CentOS_Linux_7_Benchmark_v2.1.0.pdf
# https://benchmarks.cisecurity.org/tools2/linux/CIS_Red_Hat_Enterprise_Linux_7_Benchmark_v2.1.0.pdf
#############

/bin/echo "Use with RedHat 7 or higher"
/bin/echo "PCI DSS 3.2 Data Collection Script"
/bin/echo "Version 1.1"
/bin/echo " "

# Variable settings
LOG_DIR=/root
ROOT_UID=0     # Only users with $UID 0 have root privileges.
# LINES=50     # Default number of lines saved.
# E_XCD=86     # Can't change directory?
E_NOTROOT=87   # Non-root exit error.

# Determine the default path for many commonly used COMMANDS
/bin/echo "Setting the default paths for commonly used commands..."
AWK="$(which awk)"
echo "${AWK}"
CAT="$(which cat)"
echo "${CAT}"
DF="$(which df)"
echo "${DF}"
ECHO="$(which echo)"
echo "${ECHO}"
EGREP="$(which egrep)"
echo "${EGREP}"
GREP="$(which grep)"
echo "${GREP}"
IFC="$(which ifconfig)"
echo "${IFC}"
IPT="$(which iptables)"
echo "${IPT}"
LAST="$(which last)"
echo "${LAST}"
LS="$(which ls)"
echo "${LS}"
MD="$(which mkdir)"
echo "${MD}"
MT="$(which mount)"
echo "${MT}"
NS="$(which netstat)"
echo "${NS}"
PS="$(which ps)"
echo "${PS}"
RM="$(which rm)"
echo "${RM}"
RPM="$(which rpm)"
echo "${RPM}"
RT="$(which route)"
echo "${RT}"
SC="$(which sysctl)"
echo "${SC}"
STC="$(which systemctl)"
echo "${STC}"
STAT="$(which stat)"
echo "${STAT}"
TAIL="$(which tail)"
echo "${TAIL}"
TAR="$(which tar)"
echo "${TAR}"
TR="$(which traceroute)"
echo "${TR}"
USERADD="$(which useradd)"
echo "${USERADD}"
WC="$(which wc)"
echo "${WC}"
YUM="$(which yum)"
echo "${YUM}"
# end custom paths

# Run as root
if [ "$UID" -ne "$ROOT_UID" ]
then
  echo "Must be root to run this script."
  exit $E_NOTROOT
fi  

# Define the hostname of the server
outdir=$(hostname)

# Remove the older output directory, and create anew.
if [ -d $outdir ]; then
    echo "Removing older $outdir directory. A new directory will be created."
    /bin/rm -rf $outdir
fi

/bin/echo " "

# Create the new output directory.
/bin/mkdir $outdir

p1=''
p2=''

{

## Network Connectivity ##
$ECHO '1/21 Performing Internet Connection Tests'
$NS -rn                 >                       $outdir/1.0.default_route.txt
$TR www.google.com      >                       $outdir/1.2.1.a.google_trace.txt &
p1=$!
$TR www.yahoo.com       >                       $outdir/1.2.1.a.yahoo_trace.txt &
p2=$!
$SC net.ipv4.ip_forward >                       $outdir/1.3.1.ip_forward.txt
##----##

## System Information  ##
$ECHO '2/21 Collecting System Information'
$CAT /etc/*-release               >             $outdir/6.1.a.system_info.txt
$CAT /etc/fstab                   >             $outdir/6.1.a.system_fstab.txt
$ECHO "Host Name: $(hostname)"    >             $outdir/6.1.a.system_hostname.txt
$ECHO "Date Executed: $(date)"    >             $outdir/6.1.a.system_date.txt
$ECHO "System Uptime: $(uptime)"  >             $outdir/6.1.a.system_uptime.txt
$ECHO "OS Version: $(uname -a)"   >             $outdir/6.1.a.system_uname.txt
/sbin/lspci                       >             $outdir/6.1.a.system_lspci.txt
/sbin/getenforce                  >             $outdir/6.5.selinux_settings.txt
$CAT /etc/selinux/config          >>            $outdir/6.5.selinux_settings.txt
$GREP "^\s*linux" /boot/grub2/grub.cfg >        $outdir/6.5.selinux_bootloader.txt
$GREP SELINUXTYPE=targeted \
  /etc/selinux/config             >             $outdir/6.5.selinux_policy.txt
/sbin/sestatus                    >>            $outdir/6.5.selinux_policy.txt
$RPM -q setroubleshoot            >             $outdir/6.5.setroubleshoot.txt
$PS -eZ | egrep "initrc" | egrep -vw \
  "tr|ps|egrep|bash|awk" | tr ':' ' ' \
  | awk '{ print $NF }'           >             $outdir/2.2.2.b.unconfined_daemons.txt
##----##

## Network Adapter Information ##
$ECHO '3/21 Gathering Network Configurations'
/sbin/ifconfig -a       >                       $outdir/1.2.1.a.ifconfig.txt
$RPM -q iptables        >                       $outdir/1.1.iptables_output.txt
/sbin/iptables -L       >>                      $outdir/1.1.iptables_output.txt
$SC net.ipv6.conf.all.accept_ra   >             $outdir/1.3.7.ipv6_router.txt
$SC \
  net.ipv6.conf.default.accept_ra >>            $outdir/1.3.7.ipv6_router.txt
$SC \
  net.ipv6.conf.all.accept_redirects      >     $outdir/1.3.7.ipv6_redirects.txt
$SC \
  net.ipv6.conf.default.accept_redirects  >>    $outdir/1.3.7.ipv6_redirects.txt
##----##

## Local User Information ##
$ECHO '4/21 Querying Local User Information'
$CAT /etc/passwd >                              $outdir/7.1.local_passwd.txt
$CAT /etc/shadow >                              $outdir/7.1.local_shadow.txt
$STAT /etc/passwd >                             $outdir/8.1.1.stat_passwd.txt
$STAT /etc/shadow >                             $outdir/8.1.1.stat_shadow.txt
/bin/who >                                      $outdir/8.1.1.localuser_currentlogin.txt
/bin/lastlog >                                  $outdir/8.1.1.localuser_lastlogin.txt
$CAT /etc/group >                               $outdir/8.1.1.localgroups.txt
$GREP PASS_MAX_DAYS /etc/login.defs >           $outdir/8.1.2.login_maxdays.txt
$GREP PASS_MIN_DAYS /etc/login.defs >           $outdir/8.1.2.login_mindays.txt
$GREP PASS_WARN_AGE /etc/login.defs >           $outdir/8.1.2.login_warnage.txt
/sbin/useradd -D | grep INACTIVE >              $outdir/8.1.8.login_inactive.txt
/sbin/pwck -r /etc/passwd >                     $outdir/8.1.2.passwd_integrity.txt
/sbin/pwck -r /etc/shadow >>                    $outdir/8.1.2.shadow_integrity.txt
$EGREP -v "^\+" /etc/passwd | \
  awk -F: '($1!="root" && $1!="sync" && \
  $1!="shutdown" && $1!="halt" && $3<1000 \
  && $7!="/sbin/nologin" \
  && $7!="/bin/false") {print}' >               $outdir/8.1.2.accounts_nologin.txt
$GREP "^root:" /etc/passwd | cut -f4 -d: >      $outdir/8.2.root_default.txt
$GREP "umask" /etc/bashrc   >                   $outdir/9.2.umask_bashrc.txt
$GREP "umask" /etc/profile  >>                  $outdir/8.2.umask_profile.txt
$CAT /etc/securetty >                           $outdir/8.2.root_console.txt
$GREP pam_wheel.so /etc/pam.d/su  >             $outdir/8.2.su_access.txt
$GREP wheel /etc/group            >>            $outdir/8.2.su_access.txt
##----##

## SNMP ##
$ECHO '5/21 Querying SNMP Config'
$EGREP -v -e '#|^$' /etc/snmp/snmpd.conf >      $outdir/2.1.snmp_strings.txt
ulimit -c >                                     $outdir/7.1.core_dump.txt
##----##

## Kernel Configuration ##
$ECHO '6/21 Collecting Kernel Configuration'
$SC -A                            >             $outdir/1.2.1.a.systemconfig.txt
$GREP "hard core" \
  /etc/security/limits.conf \
  /etc/security/limits.d/*        >             $outdir/A3.2.5.core_dumps.txt
$SC fs.suid_dumpable              >>            $outdir/A3.2.5.core_dumps.txt
##----##

## RPM Packages ##
$ECHO '7/21 Gathering RPM Package Information'
$RPM -qa --info                     >           $outdir/6.2.installed_packages.txt
$RPM -qa | grep audit               >           $outdir/6.2.auditd_package.txt
$GREP ^gpgcheck /etc/yum.conf       >           $outdir/3.6.5.gpgcheck_active.txt
$GREP ^gpgcheck /etc/yum.repos.d/*  >>          $outdir/3.6.5.gpgcheck_active.txt
$RPM -q gpg-pubkey --qf \
  '%{name}-%{version}-%{release} \
  --> %{summary}\n'                 >           $outdir/3.6.5.gpg_keys.txt
$RPM -qa xorg-x11*                  >           $outdir/6.1.x_window.txt
##----##

## Running Processes ##
$ECHO '8/21 Listing Running Processes'
$PS -ef >                                       $outdir/6.1.a.running_processes.txt
$PS aux >                                       $outdir/6.1.a.alt_running_processes.txt
$STAT /boot/grub2/grub.cfg >                    $outdir/1.1.2.a.secure_boot.txt
$GREP "^set superusers" \
  /boot/grub2/grub.cfg  >                       $outdir/1.1.2.a.bootloader_pass.txt
$GREP "^password" \
  /boot/grub2/grub.cfg  >>                      $outdir/1.1.2.a.bootloader_pass.txt
##----##

## Running Services ##
$ECHO '9/21 Listing Running Services'
$STC \
    list-unit-files --type service  >           $outdir/1.1.2.a.running_services.txt
$STC list-units --type service      >           $outdir/1.1.2.a.enabled_services.txt
##----##

## Unnecessary Services ##
$ECHO '10/21 Listing Startup Commands'
$ECHO 'systemctl is-enabled cups'         >     $outdir/2.2.d.unneeded_services.txt
$STC is-enabled cups                      >>    $outdir/2.2.d.unneeded_services.txt
$ECHO 'systemctl is-enabled avahi-daemon' >>    $outdir/2.2.d.unneeded_services.txt
$STC is-enabled avahi-daemon              >>    $outdir/2.2.d.unneeded_services.txt
$ECHO 'systemctl is-enabled dhcpd'        >>    $outdir/2.2.d.unneeded_services.txt
$STC is-enabled dhcpd                     >>    $outdir/2.2.d.unneeded_services.txt
$ECHO 'systemctl is-enabled slapd'        >>    $outdir/2.2.d.unneeded_services.txt
$STC is-enabled slapd                     >>    $outdir/2.2.d.unneeded_services.txt
$ECHO 'systemctl is-enabled nfs'          >>    $outdir/2.2.d.unneeded_services.txt
$STC is-enabled nfs                       >>    $outdir/2.2.d.unneeded_services.txt
$ECHO 'systemctl is-enabled rpcbind'      >>    $outdir/2.2.d.unneeded_services.txt
$STC is-enabled rpcbind                   >>    $outdir/2.2.d.unneeded_services.txt
$ECHO 'systemctl is-enabled named'        >>    $outdir/2.2.d.unneeded_services.txt
$STC is-enabled named                     >>    $outdir/2.2.d.unneeded_services.txt
$ECHO 'systemctl is-enabled vsftpd'       >>    $outdir/2.2.d.unneeded_services.txt
$STC is-enabled vsftpd                    >>    $outdir/2.2.d.unneeded_services.txt
$ECHO 'systemctl is-enabled httpd'        >>    $outdir/2.2.d.unneeded_services.txt
$STC is-enabled httpd                     >>    $outdir/2.2.d.unneeded_services.txt
$ECHO 'systemctl is-enabled dovecot'      >>    $outdir/2.2.d.unneeded_services.txt
$STC is-enabled dovecot                   >>    $outdir/2.2.d.unneeded_services.txt
$ECHO 'systemctl is-enabled smb'          >>    $outdir/2.2.d.unneeded_services.txt
$STC is-enabled smb                       >>    $outdir/2.2.d.unneeded_services.txt
$ECHO 'systemctl is-enabled snmpd'        >>    $outdir/2.2.d.unneeded_services.txt
$STC is-enabled snmpd                     >>    $outdir/2.2.d.unneeded_services.txt
$ECHO 'smtp is local-host only'           >>    $outdir/2.2.d.unneeded_services.txt
$NS -an | $GREP LIST | $GREP \
  ":25[[:space:]]"                        >>    $outdir/2.2.d.unneeded_services.txt
$ECHO 'systemctl is-enabled telnet'       >>    $outdir/2.2.d.unneeded_services.txt
$STC is-enabled telnet.socket             >>    $outdir/2.2.d.unneeded_services.txt
$ECHO 'systemctl is-enabled tftp'         >>    $outdir/2.2.d.unneeded_services.txt
$STC is-enabled tftp.socket               >>    $outdir/2.2.d.unneeded_services.txt
$ECHO 'systemctl is-enabled rsync'        >>    $outdir/2.2.d.unneeded_services.txt
$STC is-enabled rsyncd                    >>    $outdir/2.2.d.unneeded_services.txt
$ECHO 'systemctl is-enabled xinetd'       >>    $outdir/2.2.d.unneeded_services.txt
$STC is-enabled xinetd                    >>    $outdir/2.2.d.unneeded_services.txt
$STC is-enabled auditd                    >     $outdir/2.2.d.needed_services.txt
##----##

## Remote Connection Configs ##
$ECHO '11/21 Listing Remote Connection Configs'
$EGREP -v -e '#|^$' \
    /etc/rc.d/rc.local >                        $outdir/4.1.rclocal_config.txt
##----##

## User Crontabs ##
$ECHO '12/21 Listing Crontabs'
$STC is-enabled crond   >                       $outdir/2.2.1.cron_enabled.txt
$STAT /etc/crontab      >>                      $outdir/2.2.1.crontabs.txt
$STAT /etc/cron.hourly  >>                      $outdir/2.2.1.crontabs.txt
$STAT /etc/cron.daily   >>                      $outdir/2.2.1.crontabs.txt
$STAT /etc/cron.weekly  >>                      $outdir/2.2.1.crontabs.txt
$STAT /etc/cron.monthly >>                      $outdir/2.2.1.crontabs.txt
$STAT /etc/cron.d       >>                      $outdir/2.2.1.crontabs.txt
for user in $(cut -f 1 -d ':' /etc/passwd); \
    do crontab -u $user -l; done >              $outdir/2.2.1.user_cron.txt
##----##

## Active Listening Ports ##
$ECHO '13/21 Active Listening Ports'
$NS -a | $EGREP -e 'LISTEN' >                   $outdir/2.2.2.netstat.txt
##----##

## Installed Patches ##
$ECHO '14/21 Listing Installed Patches'
$TAIL /var/log/yum.log -n 2000 >                $outdir/6.1.a.patches.txt
##----##

# Yum Repositories
$ECHO '15/21 Listing Package Repositories'
$YUM -v repolist >                              $outdir/6.1.a.repositories.txt
##----##

## Sudoers ##
$ECHO '16/21 Identifying Sudoers'
$EGREP -v -e '#|^$' /etc/sudoers  >             $outdir/7.2.2.local_admins.txt
$AWK -F: '($3 == "0") {print}' \
    /etc/passwd                   >             $outdir/7.2.2.passwd_permissions.txt
$AWK -F: '($2 == "") {print}' \
    /etc/shadow                   >>            $outdir/7.2.2.shadow_permissions.txt
OUTPUT1="$(grep /sbin/sulogin /usr/lib/systemd/system/rescue.service)"
$ECHO "${OUTPUT1}"                >             $outdir/7.2.2.auth_singlemode.txt
OUTPUT2="$(grep /sbin/sulogin /usr/lib/systemd/system/emergency.service)"
$ECHO "$(OUTPUT2)"                >>            $outdir/7.2.2.auth_singlemode.txt
##----##

## SSH Daemon Settings ##
$ECHO '17/21 SSH Configuration Settings'
$EGREP -v -e '#|^$' \
  /etc/ssh/sshd_config                  >       $outdir/2.2.2.sshd_config.txt
$GREP "^Protocol" /etc/ssh/sshd_config  >       $outdir/2.2.2.ssh_protocol.txt
$GREP "^LogLevel" /etc/ssh/sshd_config  >       $outdir/2.2.2.ssh_logging.txt
$GREP "^X11Forwarding" \
  /etc/ssh/sshd_config                  >       $outdir/2.2.2.ssh_x11.txt
$GREP "^MaxAuthTries" \
  /etc/ssh/sshd_config                  >       $outdir/2.2.2.ssh_tries.txt
$GREP "^IgnoreRhosts" \
  /etc/ssh/sshd_config                  >       $outdir/2.2.2.ssh_rhosts.txt
$GREP "^HostbasedAuthentication" \
  /etc/ssh/sshd_config                  >       $outdir/2.2.2.ssh_auth.txt
$GREP "^PermitRootLogin" \
  /etc/ssh/sshd_config                  >       $outdir/2.2.2.ssh_root.txt
$GREP "^PermitEmptyPasswords" \
  /etc/ssh/sshd_config                  >       $outdir/2.2.2.ssh_empty.txt
$GREP PermitUserEnvironment \
    /etc/ssh/sshd_config                >       $outdir/2.2.2.ssh_environ.txt
$GREP "Ciphers" /etc/ssh/sshd_config    >       $outdir/4.1.ssh_ciphers.txt
$GREP "MACs" /etc/ssh/sshd_config       >       $outdir/4.1.ssh_macs.txt
$GREP "^ClientAliveInterval" \
  /etc/ssh/sshd_config                  >       $outdir/4.1.ssh_clientstay.txt
$GREP "^ClientAliveCountMax" \
  /etc/ssh/sshd_config                  >>      $outdir/4.1.ssh_clientstay.txt
$GREP "^LoginGraceTime" \
  /etc/ssh/sshd_config                  >       $outdir/2.2.2.ssh_grace.txt
$GREP "^Banner" /etc/ssh/sshd_config    >       $outdir/2.2.2.ssh_banner.txt
##----##

## User Security ##
$ECHO '18/21 Collecting User Security Settings'
$CAT /etc/pam.d/system-auth       >             $outdir/8.2.3.user_sec.txt
$CAT /etc/pam.d/password-auth     >             $outdir/8.2.3.pam_passwords.txt
$GREP pam_pwquality.so \
  /etc/pam.d/password-auth        >             $outdir/8.2.3.pam_passwords.txt 
$GREP pam_pwquality.so \
  /etc/pam.d/system-auth          >>            $outdir/8.2.3.pam_passwords.txt
$GREP ^minlen \
  /etc/security/pwquality.conf    >>            $outdir/8.2.3.pam_passwords.txt
$GREP ^dcredit \
  /etc/security/pwquality.conf    >>            $outdir/8.2.3.pam_passwords.txt
$GREP ^lcredit \
  /etc/security/pwquality.conf    >>            $outdir/8.2.3.pam_passwords.txt
$GREP ^ocredit \
  /etc/security/pwquality.conf    >>            $outdir/8.2.3.pam_passwords.txt
$GREP ^ucredit \
  /etc/security/pwquality.conf    >>            $outdir/8.2.3.pam_passwords.txt
$EGREP \
  '^password\s+sufficient\s+pam_unix.so' \
  /etc/pam.d/password-auth        >             $outdir/8.2.3.password_reuse.txt
$EGREP \
  '^password\s+sufficient\s+pam_unix.so' \
  /etc/pam.d/system-auth          >>            $outdir/8.2.3.password_reuse.txt
$EGREP \
  '^password\s+sufficient\s+pam_unix.so' \
  /etc/pam.d/password-auth        >             $outdir/8.2.3.password_hash.txt
$EGREP \
  '^password\s+sufficient\s+pam_unix.so' \
  /etc/pam.d/system-auth          >>            $outdir/8.2.3.password_hash.txt
##----##

## Console Timeout ##
$ECHO '19/21 Querying Console Timeout'
$ECHO $TMOUT >                                  $outdir/2.2.2.console_timeout.txt
##----##

## Network Time Protocol ##
$ECHO '20/21 Querying NTP Settings'
$RPM -q ntp         >                           $outdir/10.4.ntp_status.txt
$RPM -q chrony      >>                          $outdir/10.4.ntp_status.txt
$STC status ntpd    >>                          $outdir/10.4.ntp_status.txt
$GREP "^restrict" \
  /etc/ntp.conf/sbin/ntpd -q >                  $outdir/10.4.1.ntp_configs.txt
$GREP "^server" /etc/ntp.conf >>                $outdir/10.4.1.ntp_configs.txt
$GREP "^OPTIONS" /etc/sysconfig/ntpd >>         $outdir/10.4.1.ntp_configs.txt
$GREP "^ExecStart" \
  /usr/lib/systemd/system/ntpd.service >>       $outdir/10.4.1.ntp_configs.txt
##----##

## System Log Settings ##
$ECHO '21/21 Getting System Log Settings'
$STC is-enabled syslog-ng       >               $outdir/10.2.1.syslog_settings.txt
$EGREP -v -e '#|^$' \
  /etc/syslog.conf              >>              $outdir/10.2.1.syslog_settings.txt
$RPM -q rsyslog                 >               $outdir/10.2.1.rsyslog_settings.txt
$RPM -q syslog-ng               >>              $outdir/10.2.1.rsyslog_settings.txt
$GREP ^options \
  /etc/syslog-ng/syslog-ng.conf >               $outdir/10.2.1.syslog_conf.txt
$STC is-enabled rsyslog >                       $outdir/10.2.1.rsyslog_enabled.txt
$EGREP -v -e '#|^$' \
  /etc/rsyslog.conf             >>              $outdir/10.2.1.rsyslog_enabled.txt
$GREP ^\$FileCreateMode \
  /etc/rsyslog.conf             >>              $outdir/10.2.1.rsyslog_enabled.txt
$GREP "^*.*[^I][^I]*@" \
  /etc/rsyslog.conf             >               $outdir/10.2.1.rsyslog_remote.txt
$GREP max_log_file_action \
  /etc/audit/auditd.conf        >>              $outdir/10.2.1.rsyslog_remote.txt
/bin/find /var/log -type f -ls  >               $outdir/10.2.1.logs_permissions.txt
##----##

# Pipe output to /dev/null
} 2>/dev/null

$ECHO " "
$ECHO "Please wait a moment for all commands to finish."
$ECHO " "

/bin/wait

$ECHO "Collection Complete. Output files located in $outdir."

/bin/wait
$ECHO " "

# Delete the older tarred and zipped file
if [ -f *.tar.gz ]; then
    $ECHO "Removing older compressed file..."
    rm -rf *.tar.gz
fi

$ECHO " "

# Tar up output into nice, neat file for collection
/bin/tar -cvpzf RH-PCI-Collector.tar.gz $outdir

exit

# EOF

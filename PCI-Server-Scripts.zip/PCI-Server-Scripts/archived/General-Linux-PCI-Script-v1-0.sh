#!/bin/bash

echo 'Ensure that you are running this script with root privileges!'

if [ "$(id -u)" -ne 0 ]; then
	echo 'ERROR: You need to be root to run this script. (exiting)'
	exit
fi

outdir=$(hostname)

if [ -d $outdir ]; then
	rm -rf $outdir
fi

mkdir $outdir

p1=''
p2=''

{

echo 'Outputs from every command appear below in this file.'$'\n' > $outdir/00_AllOutputs.txt

echo '1/21 Performing Internet Connection Tests (Google & Yahoo)'
echo '1/21 Internet Connection Tests' >> $outdir/00_AllOutputs.txt
echo 'Internet Connection Tests' > $outdir/01_ConnectionTests.txt
echo 'Output of commands "traceroute www.google.com" and "traceroute www.yahoo.com"'$'\n' >> $outdir/00_AllOutputs.txt
echo 'Output of commands "traceroute www.google.com" and "traceroute www.yahoo.com"'$'\n' >> $outdir/01_ConnectionTests.txt
echo "Host Name: $(hostname)" >> $outdir/01_ConnectionTests.txt
echo "Host Name: $(hostname)" >> $outdir/00_AllOutputs.txt
echo "Date Executed: $(date)"$'\n' >> $outdir/01_ConnectionTests.txt
echo "Date Executed: $(date)"$'\n' >> $outdir/00_AllOutputs.txt
traceroute www.google.com  >>	$outdir/01_ConnectionTests.txt &
p1=$!
echo $'\n' >> $outdir/01_ConnectionTests.txt
traceroute www.google.com  >>	$outdir/00_AllOutputs.txt
echo $'\n' >> $outdir/00_AllOutputs.txt
traceroute www.yahoo.com >>	$outdir/01_ConnectionTests.txt &
p2=$!
traceroute www.yahoo.com >>	$outdir/00_AllOutputs.txt	
echo $'\n' >> $outdir/00_AllOutputs.txt

echo '2/21 Getting System Info'
echo '*** Applicable PCI DSS Requirements: Executive Summary ***'
echo '2/21 System Information'$'\n' >> $outdir/00_AllOutputs.txt
echo 'System information' > $outdir/02_Systeminfo.txt
echo '*** Applicable PCI DSS Requirements: Executive Summary ***'$'\n' >> $outdir/00_AllOutputs.txt
echo '*** Applicable PCI DSS Requirements: Executive Summary ***'$'\n' >> $outdir/02_Systeminfo.txt
echo "Host Name: $(hostname)" >> $outdir/02_Systeminfo.txt
echo "Host Name: $(hostname)" >> $outdir/00_AllOutputs.txt
echo "Date Executed: $(date)"$'\n' >> $outdir/02_Systeminfo.txt
echo "Date Executed: $(date)"$'\n' >> $outdir/00_AllOutputs.txt 
echo 'Output of the command "cat /etc/issue"' >> $outdir/00_AllOutputs.txt
echo 'Output of the command "cat /etc/issue"' >> $outdir/02_Systeminfo.txt
cat /etc/issue	>>	$outdir/02_Systeminfo.txt
echo $'\n' >> $outdir/02_Systeminfo.txt
cat /etc/issue >> 	$outdir/00_AllOutputs.txt
echo $'\n' >> $outdir/00_AllOutputs.txt
echo 'Output of the command "uname -a"' >> $outdir/00_AllOutputs.txt
echo 'Output of the command "uname -a"' >> $outdir/02_Systeminfo.txt
echo "OS Version: $(uname -a)"	>>	$outdir/02_Systeminfo.txt
echo $'\n' >> $outdir/00_AllOutputs.txt
echo "OS Version: $(uname -a)"	>>	$outdir/00_AllOutputs.txt
echo $'\n' >> $outdir/02_Systeminfo.txt
echo 'Output of the command "lspci"' >> $outdir/00_AllOutputs.txt
echo 'Output of the command "lspci"' >> $outdir/02_Systeminfo.txt
lspci	>>	$outdir/00_AllOutputs.txt
echo $'\n' >> $outdir/00_AllOutputs.txt
lspci	>>	$outdir/02_Systeminfo.txt

echo '3/21 Getting Network Adapter Config'
echo 'Network Adapter Configurations' > $outdir/03_Ifconfig.txt
echo '3/21 Network Adapter Configurations' >> $outdir/00_AllOutputs.txt
echo "Host Name: $(hostname)" >> $outdir/03_Ifconfig.txt
echo "Host Name: $(hostname)" >> $outdir/00_AllOutputs.txt
echo "Date Executed: $(date)"$'\n' >> $outdir/03_Ifconfig.txt
echo "Date Executed: $(date)"$'\n' >> $outdir/00_AllOutputs.txt
echo 'Output of the command "ifconfig -a"' >> $outdir/00_AllOutputs.txt
echo 'Output of the command "ifconfig -a"' >> $outdir/03_Ifconfig.txt
ifconfig -a	>>	$outdir/03_Ifconfig.txt
ifconfig -a	>>	$outdir/00_AllOutputs.txt
echo $'\n' >> $outdir/00_AllOutputs.txt

echo '4/21 Querying Local User Information'
echo '*** Applicable PCI DSS Requirements: 2.2.3, 7.2.2, 7.2.3, 8.1, 10.4.2.a ***' 
echo 'Local user information' > $outdir/04_LocalUsers.txt
echo '4/21 Local user information' >> $outdir/00_AllOutputs.txt
echo '*** Applicable PCI DSS Requirements: 2.2.3, 7.2.2, 7.2.3, 8.1, 10.4.2.a  ***'$'\n' >> $outdir/00_AllOutputs.txt
echo '*** Applicable PCI DSS Requirements: 2.2.3, 7.2.2, 7.2.3, 8.1, 10.4.2.a  ***'$'\n' >> $outdir/04_LocalUsers.txt
echo "Host Name: $(hostname)" >> $outdir/04_LocalUsers.txt
echo "Host Name: $(hostname)" >> $outdir/00_AllOutputs.txt
echo "Date Executed: $(date)"$'\n' >> $outdir/04_LocalUsers.txt
echo "Date Executed: $(date)"$'\n' >> $outdir/00_AllOutputs.txt
echo 'Output of the command "cat /etc/passwd", "cat /etc/shadow" and "lastlog"' >> $outdir/00_AllOutputs.txt
echo 'Output of the command "cat /etc/passwd", "cat /etc/shadow" and "lastlog"' >> $outdir/04_LocalUsers.txt
cat /etc/passwd	>>	$outdir/00_AllOutputs.txt
echo $'\n' >> 		$outdir/00_AllOutputs.txt
cat /etc/passwd	>>	$outdir/04_LocalUsers.txt
echo $'\n' >> 		$outdir/04_LocalUsers.txt
cat /etc/shadow	>>	$outdir/00_AllOutputs.txt
echo $'\n' >> 		$outdir/00_AllOutputs.txt
cat /etc/shadow	>>	$outdir/04_LocalUsers.txt
echo $'\n' >> 		$outdir/04_LocalUsers.txt
lastlog	>>	$outdir/00_AllOutputs.txt
echo $'\n' >> 		$outdir/00_AllOutputs.txt
lastlog	>>	$outdir/04_LocalUsers.txt
echo $'\n' >> 		$outdir/04_LocalUsers.txt

echo '5/21 Querying SNMP Config'
echo '*** Applicable PCI DSS Requirements: 2.1 ***'
echo 'SNMP Configuration' > $outdir/05_SNMP-Configuration.txt
echo '5/21 SNMP Configuration' >> $outdir/00_AllOutputs.txt
echo '*** Applicable PCI DSS Requirements: 2.1 ***'$'\n' >> $outdir/00_AllOutputs.txt
echo '*** Applicable PCI DSS Requirements: 2.1 ***'$'\n' >> $outdir/05_SNMP-Configuration.txt
echo "Host Name: $(hostname)" >> $outdir/05_SNMP-Configuration.txt
echo "Host Name: $(hostname)" >> $outdir/00_AllOutputs.txt
echo "Date Executed: $(date)"$'\n' >> $outdir/05_SNMP-Configuration.txt
echo "Date Executed: $(date)"$'\n' >> $outdir/00_AllOutputs.txt
echo "Output of the command 'egrep -v -e '#|^$' /etc/cups/snmpd.conf' and 'ulimit -c'" >> $outdir/05_SNMP-Configuration.txt
echo "Output of the command 'egrep -v -e '#|^$' /etc/cups/snmpd.conf' and 'ulimit -c'" >> $outdir/00_AllOutputs.txt
egrep -v -e '#|^$' /etc/cups/snmpd.conf	>>	$outdir/05_SNMP-Configuration.txt
echo $'\n' >> $outdir/05_SNMP-Configuration.txt
egrep -v -e '#|^$' /etc/cups/snmpd.conf	>>	$outdir/00_AllOutputs.txt
echo $'\n' >> $outdir/00_AllOutputs.txt
ulimit -c	>	$outdir/05_SNMP-Configuration.txt
ulimit -c	>>	$outdir/00_AllOutputs.txt
echo $'\n' >> $outdir/00_AllOutputs.txt

echo '6/21 Getting Kernel Configuration'
echo 'Kernel Configurations' > $outdir/06_KernelConfiguration.txt
echo '6/21 Kernel Configurations' >> $outdir/00_AllOutputs.txt
echo "Host Name: $(hostname)" >> $outdir/06_KernelConfiguration.txt
echo "Host Name: $(hostname)" >> $outdir/00_AllOutputs.txt
echo "Date Executed: $(date)"$'\n' >> $outdir/06_KernelConfiguration.txt
echo "Date Executed: $(date)"$'\n' >> $outdir/00_AllOutputs.txt
echo "Output of the command 'sysctl -A'" >> $outdir/06_KernelConfiguration.txt
echo "Output of the command 'sysctl -A'" >> $outdir/00_AllOutputs.txt
sysctl -A	>>	$outdir/06_KernelConfiguration.txt
sysctl -A	>>	$outdir/00_AllOutputs.txt
echo $'\n' >> $outdir/00_AllOutputs.txt

echo '7/21 Getting Package Information'
echo 'Package information' > $outdir/07_PackageInformation.txt
echo '7/21 Package information' >> $outdir/00_AllOutputs.txt
echo "Host Name: $(hostname)" >> $outdir/07_PackageInformation.txt
echo "Host Name: $(hostname)" >> $outdir/00_AllOutputs.txt
echo "Date Executed: $(date)"$'\n' >> $outdir/07_PackageInformation.txt
echo "Date Executed: $(date)"$'\n' >> $outdir/00_AllOutputs.txt
echo "Output of the command 'dpkg --list'" >> $outdir/07_PackageInformation.txt
echo "Output of the command 'dpkg --list'" >> $outdir/00_AllOutputs.txt
dpkg --list	>>	$outdir/07_PackageInformation.txt
dpkg --list	>>	$outdir/00_AllOutputs.txt
echo $'\n'	>> 	$outdir/00_AllOutputs.txt

echo '8/21 Listing Running Processes'
echo '*** Applicable PCI DSS Requirements: 2.2.1, 2.2.2, 2.2.3, 2.2.4, 5.1 ***'
echo 'Running Processes' > $outdir/08_RunningProcesses.txt
echo '8/21 Running Processes' >> $outdir/00_AllOutputs.txt
echo '*** Applicable PCI DSS Requirements: 2.2.1, 2.2.2, 2.2.3, 2.2.4, 5.1 ***'$'\n' >> $outdir/00_AllOutputs.txt
echo '*** Applicable PCI DSS Requirements: 2.2.1, 2.2.2, 2.2.3, 2.2.4, 5.1 ***'$'\n' >> $outdir/08_RunningProcesses.txt
echo "Host Name: $(hostname)" >> $outdir/08_RunningProcesses.txt
echo "Host Name: $(hostname)" >> $outdir/00_AllOutputs.txt
echo "Date Executed: $(date)"$'\n' >> $outdir/08_RunningProcesses.txt
echo "Date Executed: $(date)"$'\n' >> $outdir/00_AllOutputs.txt
echo "Output of the command 'ps -ef'" >> $outdir/08_RunningProcesses.txt
echo "Output of the command 'ps -ef'" >> $outdir/00_AllOutputs.txt
ps -ef	>>	$outdir/08_RunningProcesses.txt
ps -ef	>>	$outdir/00_AllOutputs.txt
echo $'\n'	>> 	$outdir/00_AllOutputs.txt

echo '9/21 Listing Running Services'
echo '*** Applicable PCI DSS Requirements: 2.2.1, 2.2.2, 2.2.3, 2.3.c, 11.5.a ***'
echo 'Running Services' > $outdir/09_RunningServices.txt
echo '9/21 Running Services' >> $outdir/00_AllOutputs.txt
echo '*** Applicable PCI DSS Requirements: 2.2.1, 2.2.2, 2.2.3, 2.3.c, 11.5.a ***'$'\n' >> $outdir/00_AllOutputs.txt
echo '*** Applicable PCI DSS Requirements: 2.2.1, 2.2.2, 2.2.3, 2.3.c, 11.5.a ***'$'\n' >> $outdir/09_RunningServices.txt
echo "Host Name: $(hostname)" >> $outdir/09_RunningServices.txt
echo "Host Name: $(hostname)" >> $outdir/00_AllOutputs.txt
echo "Date Executed: $(date)"$'\n' >> $outdir/09_RunningServices.txt
echo "Date Executed: $(date)"$'\n' >> $outdir/00_AllOutputs.txt
echo "Output of the command 'initctl list | egrep running | awk -F" " '{print $1}' | sort'" >> $outdir/09_RunningServices.txt
echo "Output of the command 'initctl list | egrep running | awk -F" " '{print $1}' | sort'" >> $outdir/00_AllOutputs.txt
initctl list | egrep running | awk -F" " '{print $1}' | sort >> $outdir/09_RunningServices.txt
initctl list | egrep running | awk -F" " '{print $1}' | sort	>>  $outdir/00_AllOutputs.txt
echo $'\n'	>> 	$outdir/00_AllOutputs.txt

echo '10/21 Listing Startup Commands'
echo 'Startup Commands' > $outdir/10_StartupCommands.txt
echo '10/21 Startup Commands' >> $outdir/00_AllOutputs.txt
echo "Host Name: $(hostname)" >> $outdir/10_StartupCommands.txt
echo "Host Name: $(hostname)" >> $outdir/00_AllOutputs.txt
echo "Date Executed: $(date)"$'\n' >> $outdir/10_StartupCommands.txt
echo "Date Executed: $(date)"$'\n' >> $outdir/00_AllOutputs.txt
echo "Output of the command 'for f in /etc/rc$CURRUNLEVEL.d/*; do echo $f; done | egrep -v "README" | cut -b 11- | sort'" >> $outdir/10_StartupCommands.txt
echo "Output of the command 'for f in /etc/rc$CURRUNLEVEL.d/*; do echo $f; done | egrep -v "README" | cut -b 11- | sort'" >> $outdir/00_AllOutputs.txt
for f in /etc/rc$CURRUNLEVEL.d/*; do echo $f; done | egrep -v "README" | cut -b 11- | sort >> $outdir/10_StartupCommands.txt
for f in /etc/rc$CURRUNLEVEL.d/*; do echo $f; done | egrep -v "README" | cut -b 11- | sort >> $outdir/00_AllOutputs.txt
echo $'\n'	>> 	$outdir/00_AllOutputs.txt

echo '11/21 Listing Remote Connection Configuration'
echo '*** Applicable PCI DSS Requirements: 2.2.3, 2.3.b, 8.4 ***'
echo 'Remote Connection Configuration' > $outdir/11_RemoteConnectionConfig.txt
echo '11/21 Remote Connection Configuration' >> $outdir/00_AllOutputs.txt
echo '*** Applicable PCI DSS Requirements: 2.2.3, 2.3.b, 8.4 ***'$'\n' >> $outdir/00_AllOutputs.txt
echo '*** Applicable PCI DSS Requirements: 2.2.3, 2.3.b, 8.4 ***'$'\n' >> $outdir/11_RemoteConnectionConfig.txt
echo "Host Name: $(hostname)" >> $outdir/11_RemoteConnectionConfig.txt
echo "Host Name: $(hostname)" >> $outdir/00_AllOutputs.txt
echo "Date Executed: $(date)"$'\n' >> $outdir/11_RemoteConnectionConfig.txt
echo "Date Executed: $(date)"$'\n' >> $outdir/00_AllOutputs.txt
echo "Output of the command 'egrep -v -e '#' -e '^$' /etc/rc.local'" >> $outdir/11_RemoteConnectionConfig.txt
echo "Output of the command 'egrep -v -e '#' -e '^$' /etc/rc.local'" >> $outdir/00_AllOutputs.txt
egrep -v -e '#' -e '^$' /etc/rc.local	>	$outdir/11_RemoteConnectionConfig.txt
egrep -v -e '#' -e '^$' /etc/rc.local	>>	$outdir/00_AllOutputs.txt
echo $'\n'	>> 	$outdir/00_AllOutputs.txt

echo '12/21 Listing User Crontabs'
echo 'User Crontabs' > $outdir/12_UserCrontabs.txt
echo '12/21 User Crontabs' >> $outdir/00_AllOutputs.txt
echo "Host Name: $(hostname)" >> $outdir/12_UserCrontabs.txt
echo "Host Name: $(hostname)" >> $outdir/00_AllOutputs.txt
echo "Date Executed: $(date)"$'\n' >> $outdir/12_UserCrontabs.txt
echo "Date Executed: $(date)"$'\n' >> $outdir/00_AllOutputs.txt
echo "Output of the command 'for user in $(cut -f 1 -d ':' /etc/passwd); do crontab -u $user -l; done'" >> $outdir/12_UserCrontabs.txt
echo "Output of the command 'for user in $(cut -f 1 -d ':' /etc/passwd); do crontab -u $user -l; done'" >> $outdir/00_AllOutputs.txt
for user in $(cut -f 1 -d ':' /etc/passwd); do crontab -u $user -l; done >> $outdir/12_UserCrontabs.txt
for user in $(cut -f 1 -d ':' /etc/passwd); do crontab -u $user -l; done >> $outdir/00_AllOutputs.txt
echo $'\n'	>> 	$outdir/00_AllOutputs.txt

echo '13/21 Listing Active Ports'
echo '*** Applicable PCI DSS Requirements: 2.2.3 ***'
echo 'Active Ports' > $outdir/13_ActivePorts.txt
echo '13/21 Active Ports' >> $outdir/00_AllOutputs.txt
echo '*** Applicable PCI DSS Requirements: 2.2.3 ***'$'\n' >> $outdir/00_AllOutputs.txt
echo '*** Applicable PCI DSS Requirements: 2.2.3 ***'$'\n' >> $outdir/13_ActivePorts.txt
echo "Host Name: $(hostname)" >> $outdir/13_ActivePorts.txt
echo "Host Name: $(hostname)" >> $outdir/00_AllOutputs.txt
echo "Date Executed: $(date)"$'\n' >> $outdir/13_ActivePorts.txt
echo "Date Executed: $(date)"$'\n' >> $outdir/00_AllOutputs.txt
echo "Output of the command 'netstat -a | egrep -e 'LISTEN''" >> $outdir/13_ActivePorts.txt
echo "Output of the command 'netstat -a | egrep -e 'LISTEN''" >> $outdir/00_AllOutputs.txt
netstat -a | egrep -e 'LISTEN'	>>	$outdir/13_ActivePorts.txt
netstat -a | egrep -e 'LISTEN'	>>	$outdir/00_AllOutputs.txt
echo $'\n'	>> 	$outdir/00_AllOutputs.txt

echo '14/21 Listing Installed Patches'
echo '*** Applicable PCI DSS Requirements: 2.2.3, 6.2 ***'
echo 'Installed Patches' > $outdir/14_InstalledPatches.txt
echo '14/21 Installed Patches' >> $outdir/00_AllOutputs.txt
echo '*** Applicable PCI DSS Requirements: 2.2.3, 6.2 ***'$'\n' >> $outdir/00_AllOutputs.txt
echo '*** Applicable PCI DSS Requirements: 2.2.3, 6.2 ***'$'\n' >> $outdir/14_InstalledPatches.txt
echo "Host Name: $(hostname)" >> $outdir/14_InstalledPatches.txt
echo "Host Name: $(hostname)" >> $outdir/00_AllOutputs.txt
echo "Date Executed: $(date)"$'\n' >> $outdir/14_InstalledPatches.txt
echo "Date Executed: $(date)"$'\n' >> $outdir/00_AllOutputs.txt
echo "Output of the command 'tail /var/log/dpkg.log -n 2000'" >> $outdir/14_InstalledPatches.txt
echo "Output of the command 'tail /var/log/dpkg.log -n 2000'" >> $outdir/00_AllOutputs.txt

# For Debian/Ubuntu systems
tail /var/log/dpkg.log -n 2000	>>	$outdir/14_InstalledPatches.txt
tail /var/log/dpkg.log -n 2000	>>	$outdir/00_AllOutputs.txt
# For RH systems
tail /var/log/yum.log -n 2000 >>	$outdir/14_InstalledPatches.txt
tail /var/log/yum.log -n 2000 >>  $outdir/00_AllOutputs.txt

echo $'\n'	>> 	$outdir/00_AllOutputs.txt

echo '15/21 Listing Package Repositories'
echo 'Package Repositories' > $outdir/15_PackageRepo.txt
echo '15/21 Package Repositories' >> $outdir/00_AllOutputs.txt
echo "Host Name: $(hostname)" >> $outdir/15_PackageRepo.txt
echo "Host Name: $(hostname)" >> $outdir/00_AllOutputs.txt
echo "Date Executed: $(date)"$'\n' >> $outdir/15_PackageRepo.txt
echo "Date Executed: $(date)"$'\n' >> $outdir/00_AllOutputs.txt
echo "Output of the command 'egrep -v -e '#|^$' /etc/apt/sources.list'" >> $outdir/15_PackageRepo.txt
echo "Output of the command 'egrep -v -e '#|^$' /etc/apt/sources.list'" >> $outdir/00_AllOutputs.txt

# For Debian/Ubuntu systems
egrep -v -e '#|^$' /etc/apt/sources.list	>>	$outdir/15_PackageRepo.txt
egrep -v -e '#|^$' /etc/apt/sources.list	>>	$outdir/00_AllOutputs.txt
# For RH systems
yum -v repolist     >>	$outdir/15_PackageRepo.txt
yum -v repolist 	>>	$outdir/00_AllOutputs.txt

echo $'\n'	>> 	$outdir/00_AllOutputs.txt

echo '16/21 Listing Sudoers'
echo '*** Applicable PCI DSS Requirements: 2.2.3, 7.2.2, 7.2.3, 8.1, 10.4.2.a ***'
echo 'Sudoers' > $outdir/16_Sudoers.txt
echo '16/21 Sudoers' >> $outdir/00_AllOutputs.txt
echo '*** Applicable PCI DSS Requirements: 2.2.3, 7.2.2, 7.2.3, 8.1, 10.4.2.a ***'$'\n' >> $outdir/00_AllOutputs.txt
echo '*** Applicable PCI DSS Requirements: 2.2.3, 7.2.2, 7.2.3, 8.1, 10.4.2.a ***'$'\n' >> $outdir/16_Sudoers.txt
echo "Host Name: $(hostname)" >> $outdir/16_Sudoers.txt
echo "Host Name: $(hostname)" >> $outdir/00_AllOutputs.txt
echo "Date Executed: $(date)"$'\n' >> $outdir/16_Sudoers.txt
echo "Date Executed: $(date)"$'\n' >> $outdir/00_AllOutputs.txt
echo "Output of the command 'egrep -v -e '#|^$' /etc/sudoers'" >> $outdir/16_Sudoers.txt
echo "Output of the command 'egrep -v -e '#|^$' /etc/sudoers'" >> $outdir/00_AllOutputs.txt
egrep -v -e '#|^$' /etc/sudoers	>> $outdir/16_Sudoers.txt
egrep -v -e '#|^$' /etc/sudoers	>> $outdir/00_AllOutputs.txt
echo $'\n'	>> 	$outdir/00_AllOutputs.txt

echo '17/21 Getting SSH Configuration'
echo 'SSH Configuration' > $outdir/17_SSHconfig.txt
echo '17/21 SSH Configuration' >> $outdir/00_AllOutputs.txt
echo "Host Name: $(hostname)" >> $outdir/17_SSHconfig.txt
echo "Host Name: $(hostname)" >> $outdir/00_AllOutputs.txt
echo "Date Executed: $(date)"$'\n' >> $outdir/17_SSHconfig.txt
echo "Date Executed: $(date)"$'\n' >> $outdir/00_AllOutputs.txt
echo "Output of the command 'egrep -v -e '#|^$' /etc/ssh/sshd_config'" >> $outdir/17_SSHconfig.txt
echo "Output of the command 'egrep -v -e '#|^$' /etc/ssh/sshd_config'" >> $outdir/00_AllOutputs.txt
egrep -v -e '#|^$' /etc/ssh/sshd_config	>>	$outdir/17_SSHconfig.txt
egrep -v -e '#|^$' /etc/ssh/sshd_config	>>	$outdir/00_AllOutputs.txt
echo $'\n'	>> 	$outdir/00_AllOutputs.txt

echo '18/21 Getting User Security Settings'
echo '*** Applicable PCI DSS Requirements: 8.1.4, 8.1.6, 8.1.7, 8.2.3, 8.2.4, 8.2.5 ***'
echo 'User Security Settings' > $outdir/18_UserSecuritySettings.txt
echo '18/21 User Security Settings' >> $outdir/00_AllOutputs.txt
echo '*** Applicable PCI DSS Requirements: 8.1.4, 8.1.6, 8.1.7, 8.2.3, 8.2.4, 8.2.5 ***'$'\n' >> $outdir/00_AllOutputs.txt
echo '*** Applicable PCI DSS Requirements: 8.1.4, 8.1.6, 8.1.7, 8.2.3, 8.2.4, 8.2.5 ***'$'\n' >> $outdir/19_ConsoleTimeout.txt
echo "Host Name: $(hostname)" >> $outdir/18_UserSecuritySettings.txt
echo "Host Name: $(hostname)" >> $outdir/00_AllOutputs.txt
echo "Date Executed: $(date)"$'\n' >> $outdir/18_UserSecuritySettings.txt
echo "Date Executed: $(date)"$'\n' >> $outdir/00_AllOutputs.txt
echo "Output of the command 'egrep -v -e '#|^$' /etc/pam.d/common-password'" >> $outdir/18_UserSecuritySettings.txt
echo "Output of the command 'egrep -v -e '#|^$' /etc/pam.d/common-password'" >> $outdir/00_AllOutputs.txt
egrep -v -e '#|^$' /etc/pam.d/common-password	>>	$outdir/18_UserSecuritySettings.txt
egrep -v -e '#|^$' /etc/pam.d/common-password	>>	$outdir/00_AllOutputs.txt
echo $'\n'	>> 	$outdir/00_AllOutputs.txt

echo '19/21 Querying Console Timeout'
echo '*** Applicable PCI DSS Requirements: 2.2.3, 8.1.8 ***'
echo 'Console Timeout' > $outdir/19_ConsoleTimeout.txt
echo '19/21 Console Timeout' >> $outdir/00_AllOutputs.txt
echo '*** Applicable PCI DSS Requirements: 2.2.3, 8.1.8 ***'$'\n' >> $outdir/00_AllOutputs.txt
echo '*** Applicable PCI DSS Requirements: 2.2.3, 8.1.8 ***'$'\n' >> $outdir/19_ConsoleTimeout.txt
echo "Host Name: $(hostname)" >> $outdir/19_ConsoleTimeout.txt
echo "Host Name: $(hostname)" >> $outdir/00_AllOutputs.txt
echo "Date Executed: $(date)"$'\n' >> $outdir/19_ConsoleTimeout.txt
echo "Date Executed: $(date)"$'\n' >> $outdir/00_AllOutputs.txt
echo "Output of the command 'echo $TMOUT'" >> $outdir/19_ConsoleTimeout.txt
echo "Output of the command 'echo $TMOUT'" >> $outdir/00_AllOutputs.txt
echo $TMOUT	>>	$outdir/19_ConsoleTimeout.txt
echo $TMOUT	>>	$outdir/00_AllOutputs.txt
echo $'\n'	>> 	$outdir/00_AllOutputs.txt

echo '20/21 Querying NTP Settings'
echo '*** Applicable PCI DSS Requirements: 2.2.3, 10.4, 10.4.1.a ***'
echo 'NTP Settings' > $outdir/20_NTPsettings.txt
echo '20/21 NTP Settings' >> $outdir/00_AllOutputs.txt
echo '*** Applicable PCI DSS Requirements: 2.2.3, 10.4, 10.4.1.a ***'$'\n' >> $outdir/00_AllOutputs.txt
echo '*** Applicable PCI DSS Requirements: 2.2.3, 10.4, 10.4.1.a ***'$'\n' >> $outdir/20_NTPsettings.txt
echo "Host Name: $(hostname)" >> $outdir/20_NTPsettings.txt
echo "Host Name: $(hostname)" >> $outdir/00_AllOutputs.txt
echo "Date Executed: $(date)"$'\n' >> $outdir/20_NTPsettings.txt
echo "Date Executed: $(date)"$'\n' >> $outdir/00_AllOutputs.txt
echo "Output of the commands 'egrep -v -e '#|^$' /etc/ntp.conf', 'ntpq -p localhost', 'service ntpd status', and 'egrep -v -e '#' -e '^$' /etc/cron.daily/ntp'" >> $outdir/20_NTPsettings.txt
echo "Output of the commands 'egrep -v -e '#|^$' /etc/ntp.conf', 'ntpq -p localhost', 'service ntpd status', and 'egrep -v -e '#' -e '^$' /etc/cron.daily/ntp'" >> $outdir/00_AllOutputs.txt
egrep -v -e '#|^$' /etc/ntp.conf	>>	$outdir/20_NTPsettings.txt
echo $'\n'	>> 	$outdir/20_NTPSettings.txt
ntpq -p localhost	>>	$outdir/20_NTPsettings.txt
echo $'\n'	>> 	$outdir/20_NTPSettings.txt
service ntpd status	>>	$outdir/20_NTPsettings.txt
echo $'\n'	>> 	$outdir/20_NTPSettings.txt
egrep -v -e '#' -e '^$' /etc/cron.daily/ntp	>>	$outdir/20_NTPsettings.txt
egrep -v -e '#|^$' /etc/ntp.conf	>>	$outdir/00_AllOutputs.txt
echo $'\n'	>> 	$outdir/20_NTPSettings.txt
ntpq -p localhost	>>	$outdir/00_AllOutputs.txt
echo $'\n'	>> 	$outdir/20_NTPSettings.txt
service ntpd status	>>	$outdir/00_AllOutputs.txt
echo $'\n'	>> 	$outdir/00_AllOutputs.txt
egrep -v -e '#' -e '^$' /etc/cron.daily/ntp	>>	$outdir/00_AllOutputs.txt
echo $'\n'	>> 	$outdir/00_AllOutputs.txt

echo '21/21 Getting System Log Settings'
echo 'System Log Settings' > $outdir/21_LogSettings.txt
echo '21/21 System Log Settings' >> $outdir/00_AllOutputs.txt
echo "Host Name: $(hostname)" >> $outdir/21_LogSettings.txt
echo "Host Name: $(hostname)" >> $outdir/00_AllOutputs.txt
echo "Date Executed: $(date)"$'\n' >> $outdir/21_LogSettings.txt
echo "Date Executed: $(date)"$'\n' >> $outdir/00_AllOutputs.txt
echo "Output of the command 'egrep -v -e '#|^$' /etc/rsyslog.conf'" >> $outdir/21_LogSettings.txt
echo "Output of the command 'egrep -v -e '#|^$' /etc/rsyslog.conf'" >> $outdir/00_AllOutputs.txt
egrep -v -e '#|^$' /etc/rsyslog.conf	>>	$outdir/21_LogSettings.txt
egrep -v -e '#|^$' /etc/rsyslog.conf	>>	$outdir/00_AllOutputs.txt
echo $'\n'	>> 	$outdir/00_AllOutputs.txt

} 2>/dev/null

echo 'Please wait a moment for all commands to finish.'

wait

echo "Collection Complete. Output files located in $outdir"
exit

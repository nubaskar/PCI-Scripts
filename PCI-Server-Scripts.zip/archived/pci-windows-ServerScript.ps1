<# Title: PCI Discovery Script for Windows Servers

 Author: Scott Ritchie

 email: scott.ritchie@aprio.com

 Version: 2.0

 Updated: October 6, 2020

 
 NOTE: If you are having issues executing this script, then try the following commands.  First, attempt to unblock the file and, if that doesn't work,

 try setting the execution policy to unrestricted.
 
      unblock -path scriptname.ps1

      set-executionpolicy unrestricted

 Version 2.0 Updates

 - The version removed the check for administrative privileges as it was breaking the script on some versions of Windows.  This check is commented out in lines 34-45. If you wish to re-enabled this function, please un-commented those lines and re-run the script.
#>  


$Stopwatch = [System.Diagnostics.Stopwatch]::StartNew()
$date = Get-Date
Write-Output "PCI DSS v3.2.1 Windows Audit Script" 
Write-Output "Version 2.0, August 20, 2020"
Write-Output "The version removed the check for administrative privileges as it was breaking the script on some versions of Windows.  This check is commented out in lines 29-35.  If you wish to re-enabled this function, please un-commented those lines and re-run the script.  Thank you!"
Write-Output "Questions? Bugs? Contact: Scott Ritchie, Aprio (scott.ritchie@aprio.com)"
Write-Output "Ensure that this Powershell is running as Administrator!!!"

# Check to ensure the user is running Powershell as an administrator.
# If (-NOT ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole(

 #   [Security.Principal.WindowsBuiltInRole] Administrator�))

#{

  #  Write-Warning: You do not have Administrator rights to run this script! Please re-run this script as an Administrator!�

   # Break

#}



# Create directory "computername" for outputs.  

Write-Output "Removing old folder (if exists)..."
if ($env:COMPUTERNAME){Remove-Item $env:COMPUTERNAME -Recurse -ErrorAction Ignore}
Write-Output "Making directory for files..."
mkdir $env:COMPUTERNAME
cd $env:COMPUTERNAME

# Items form Original Aprio script
import-module servermanager
# add-windowsfeature rsat-ad-powershell
import-module activedirectory

gpresult /f /h "domain policy.html"
get-date | out-file aprio-pciaudit.txt
ipconfig /all | out-file -append aprio-pciaudit.txt
get-windowsfeature | out-file -append aprio-pciaudit.txt ####
get-service | where {$_.Status -eq "Running"} | out-file -append aprio-pciaudit.txt
Get-WmiObject -Class Win32_UserAccount -Filter  "LocalAccount='True'" | out-file -append aprio-pciaudit.txt
get-hotfix | sort installedon -desc | out-file -append aprio-pciaudit.txt
get-eventlog -list | out-file -append aprio-pciaudit.txt ####
Get-ChildItem Registry::HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\W32Time | out-file -append aprio-pciaudit.txt
# End items from aprio script

# Get the current Windows version. 
$winver = (Get-ItemProperty -Path Registry::"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion" CurrentVersion).CurrentVersion
$winverext =  (Get-CimInstance Win32_OperatingSystem).Version
$OSname = (Get-WmiObject -ComputerName $env:COMPUTERNAME -Class Win32_OperatingSystem).Caption

# Initialize document that contains the outputs of every command.  All commands will output to this file as well as an individual file per requirement.  
Write-Output "This document contains all of the outputs of this script." | Out-File 00_AllOutputs.txt -Encoding ascii
Add-Content 00_AllOutputs.txt -Value "*** Ran on $env:COMPUTERNAME on $date ***"
Add-Content 00_AllOutputs.txt -Value " " 

# Output of systeminfo command
Write-Output "Getting systeminfo..."
Write-Output "*** Applicable PCI DSS Requirements: Executive Summary ***"
Write-Output " " | Out-File 01_systeminfo.txt -Encoding ascii
Add-Content 00_AllOutputs.txt, 01_systeminfo.txt -Value "*** Output of the command: systeminfo ***"
Add-Content 00_AllOutputs.txt, 01_systeminfo.txt -Value "*** Applicable PCI DSS Requirements: Executive Summary ***"
Add-Content 00_AllOutputs.txt, 01_systeminfo.txt -Value ("*** Ran on $env:COMPUTERNAME on $date ***")
Add-Content 00_AllOutputs.txt, 01_systeminfo.txt -Value (systeminfo)
Add-Content 00_AllOutputs.txt, 01_systeminfo.txt -Value " "

# Output IP address information
Write-Output "Getting IP address information..."
Write-Output " " | Out-File 02_IPinfo.txt -Encoding ascii
Add-Content 00_AllOutputs.txt, 02_IPinfo.txt -Value "Getting IP address information..."
Add-Content 00_AllOutputs.txt, 02_IPinfo.txt -Value $( "*** Output of command: ipconfig ***")
Add-Content 00_AllOutputs.txt, 02_IPinfo.txt -Value $("*** Ran on $env:COMPUTERNAME on $date ***")
Add-Content 00_AllOutputs.txt, 02_IPinfo.txt -Value $(ipconfig)
Add-Content 00_AllOutputs.txt, 02_IPinfo.txt -Value $(" ")

# Output local users
Write-Output "Getting local users..."
Write-Output "*** Applicable PCI DSS Requirements: 2.2.3, 7.2.2, 7.2.3, 8.1, 10.4.2.a ***"
Write-Output " " | Out-File 03_LocalUsers.txt -Encoding ascii
Add-Content 00_AllOutputs.txt, 03_LocalUsers.txt -Value "Getting local users..."
Add-Content 00_AllOutputs.txt, 03_LocalUsers.txt -Value "*** Applicable PCI DSS Requirements: 2.2.3, 7.2.2, 7.2.3, 8.1, 10.4.2.a ***"
Add-Content 00_AllOutputs.txt, 03_LocalUsers.txt -Value "*** Output of command: Get-WmiObject -Class Win32_UserAccount -Filter LocalAccount='True'***"
Add-Content 00_AllOutputs.txt, 03_LocalUsers.txt -Value "*** Ran on $env:COMPUTERNAME on $date ***"
Add-Content 00_AllOutputs.txt, 03_LocalUsers.txt -Value "*** Full output is in csv (comma separated value) format in 03_LocalUsers.csv"
Add-Content 00_AllOutputs.txt, 03_LocalUsers.txt -Value (Get-WmiObject -Class Win32_UserAccount -Filter  "LocalAccount='True'")
Get-WmiObject -Class Win32_UserAccount -Filter  "LocalAccount='True'"  | ConvertTo-Csv | Out-File 03_LocalUsers.csv -Encoding ascii

# Output SNMP community strings (if exists)
Write-Output "Getting SNMP community strings (if exists)..."
Write-Output "*** Applicable PCI DSS Requirements: 2.1 ***"
Write-Output " " | Out-File 04_SNMPStrings.txt -Encoding ascii
Add-Content 00_AllOutputs.txt, 04_SNMPStrings.txt -Value "Getting SNMP community strings (if exists)..."
Add-Content 00_AllOutputs.txt, 04_SNMPStrings.txt -Value "*** Applicable PCI DSS Requirements: 2.1 ***"
Add-Content 00_AllOutputs.txt, 04_SNMPStrings.txt -Value "***Output of command: get-item -Path Registry::HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\SNMP\Parameters\ValidCommunities -ErrorAction Ignore ***"
Add-Content 00_AllOutputs.txt, 04_SNMPStrings.txt -Value "*** Ran on $env:COMPUTERNAME on $date ***" 
Add-Content 00_AllOutputs.txt, 04_SNMPStrings.txt -Value $(get-item -Path Registry::HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\SNMP\Parameters\ValidCommunities -ErrorAction Ignore)
Add-Content 00_AllOutputs.txt, 04_SNMPStrings.txt -Value $(" ")

# Output security policies (local)..."
Write-Output "Getting security policies (local)..."
Write-Output "*** Applicable PCI DSS Requirements: 2.2.3, 8.1.1 - 8.1.7, 10.1, 10.2.1 - 10.2.7, 10,4.2.b, 10.4.3 ***"
Write-Output " " | Out-File 05_SecurityPolicies-local.txt -Encoding ascii
Add-Content 00_AllOutputs.txt, 05_SecurityPolicies-local.txt -Value "Getting security policies (local)..."
Add-Content 00_AllOutputs.txt, 05_SecurityPolicies-local.txt -Value "*** Applicable PCI DSS Requirements: 2.2.3, 8.1.1 - 8.1.7, 10.1, 10.2.1 - 10.2.7, 10,4.2.b, 10.4.3 ***"
Add-Content 00_AllOutputs.txt, 05_SecurityPolicies-local.txt -Value "*** Output of command: secedit /export /cfg tmp_securitypolicies-local.txt /areas SECURITYPOLICY USER_RIGHTS ***"
Add-Content 00_AllOutputs.txt, 05_SecurityPolicies-local.txt -Value "*** Ran on $env:COMPUTERNAME on $date ***" 
(secedit /export /cfg tmp_securitypolicies-local.txt /areas SECURITYPOLICY USER_RIGHTS) >> tempfile.txt
Add-Content 00_AllOutputs.txt, 05_SecurityPolicies-local.txt -Value (type tmp_securitypolicies-local.txt)
#del tempfile.txt
del tmp_securitypolicies-local.txt
Add-Content 00_AllOutputs.txt, 05_SecurityPolicies-local.txt -Value $(" ")

# Output security policies (domain)
Write-Output "Getting security policies (domain)..."
Write-Output "*** Applicable PCI DSS Requirements: 2.2.3, 8.1.1 - 8.1.7, 10.1, 10.2.1 - 10.2.7, 10,4.2.b, 10.4.3 ***"
Write-Output " " | Out-File 05_SecurityPolicies-domain.txt -Encoding ascii
Add-Content 00_AllOutputs.txt, 05_SecurityPolicies-domain.txt -Value "Getting security policies (domain)..."
Add-Content 00_AllOutputs.txt, 05_SecurityPolicies-domain.txt -Value "*** Applicable PCI DSS Requirements: 2.2.3, 8.1.1 - 8.1.7, 10.1, 10.2.1 - 10.2.7, 10,4.2.b, 10.4.3 ***"
Add-Content 00_AllOutputs.txt, 05_SecurityPolicies-domain.txt -Value  "*** Output of the command: secedit /export /mergedpolicy /cfg tmp_securitypolicies-domain.txt /areas SECURITYPOLICY USER_RIGHTS ***"
Add-Content 00_AllOutputs.txt, 05_SecurityPolicies-domain.txt  "*** Ran on $env:COMPUTERNAME on $date ***"  
(secedit /export /mergedpolicy /cfg tmp_securitypolicies-domain.txt /areas SECURITYPOLICY USER_RIGHTS) >> tempfile.txt
Add-Content 00_AllOutputs.txt, 05_SecurityPolicies-local.txt -Value (type tmp_securitypolicies-domain.txt)
del tmp_securitypolicies-domain.txt
#del tempfile.txt
Add-Content 00_AllOutputs.txt, 05_SecurityPolicies-domain.txt -Value $(" ")

# Output group policy results
write-output "Getting group policy results..."
Write-Output "*** Applicable PCI DSS Requirements: 2.2.3, 8.1.1 - 8.1.7, 10.1, 10.2.1 - 10.2.7, 10,4.2.b, 10.4.3 ***"
Write-Output " " | Out-File 05_GroupPolicy.txt -Encoding ascii
Write-Output " " | Out-File 05_GroupPolicy.htm -Encoding ascii
Add-Content 00_AllOutputs.txt, 05_GroupPolicy.txt -Value "Getting group policy results..."
Add-Content 00_AllOutputs.txt, 05_GroupPolicy.txt -Value "*** Applicable PCI DSS Requirements: 2.2.3, 8.1.1 - 8.1.7, 10.1, 10.2.1 - 10.2.7, 10,4.2.b, 10.4.3 ***"
Add-Content 00_AllOutputs.txt, 05_GroupPolicy.txt -Value "*** Output of the command: gpresult /SCOPE COMPUTER /v ***"
Add-Content 00_AllOutputs.txt, 05_GroupPolicy.txt -Value "*** Ran on $env:COMPUTERNAME on $date ***" 
Add-Content 00_AllOutputs.txt, 05_GroupPolicy.txt -Value $(gpresult /SCOPE COMPUTER /v )
Add-Content 05_GroupPolicy.html -Value $(gpresult /SCOPE COMPUTER /v )
Add-Content 00_AllOutputs.txt, 05_GroupPolicy.txt -Value $(" ")

# Output audit policy 
Write-Output "Getting audit policy if it exists..."
Write-Output " " | Out-File 05b_AuditPolicy.txt -Encoding ascii
Add-Content 00_AllOutputs.txt, 05b_AuditPolicy.txt -Value "Getting audit policy results..."
Add-Content 00_AllOutputs.txt, 05b_AuditPolicy.txt -Value "*** Output of the commands:Auditpol /list /user /v, Auditpol /get /category:'Detailed Tracking' /r ***"
Add-Content 00_AllOutputs.txt, 05b_AuditPolicy.txt -Value "*** Ran on $env:COMPUTERNAME on $date ***" 
Add-Content 00_AllOutputs.txt, 05b_AuditPolicy.txt -Value $(Auditpol /list /user /v)
Add-Content 00_AllOutputs.txt, 05b_AuditPolicy.txt -Value $(Auditpol /get /category:"Detailed Tracking" /r)
Add-Content 00_AllOutputs.txt, 05b_AuditPolicy.txt -Value $(Auditpol /get /category:*)

# Windows XP specific queries
function windowsXP
{
    Write-Output "This is a $OSname machine."
}

# Windows 2003 specific queries
function windows2003
{
    Write-Output "This is a $OSname machine."
    Write-Output "Getting installed Windows components..."
    Write-Output "*** Applicable PCI DSS Requirements: 2.2.1, 2.2.2, 2.2.3 ***"
    Write-Output " " | Out-File 06_WindowsComponents32bit.txt -Encoding ascii
    Add-Content 00_AllOutputs.txt, 06_WindowsComponents32bit.txt -Value "Getting installed Windows components..."
    Add-Content 00_AllOutputs.txt, 06_WindowsComponents32bit.txt -Value "*** Applicable PCI DSS Requirements: 2.2.1, 2.2.2, 2.2.3 ***"
    Add-Content 00_AllOutputs.txt, 06_WindowsComponents32bit.txt -Value "*** Output of the command:  reg query 'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Setup\Oc Manager\Subcomponents' ***"
    Add-Content 00_AllOutputs.txt, 06_WindowsComponents32bit.txt -Value  "*** Ran on $env:COMPUTERNAME on $date ***"
    Add-Content 00_AllOutputs.txt, 06_WindowsComponents32bit.txt -Value $(reg query "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Setup\Oc Manager\Subcomponents")
    Add-Content 00_AllOutputs.txt, 06_WindowsComponents32bit.txt -Value $(" ")
    Add-Content 00_AllOutputs.txt, 06_WindowsComponents32bit.txt -Value "*** Output of the command:  reg query 'HKLM\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Setup\Oc Manager\Subcomponents' ***"
    Add-Content 00_AllOutputs.txt, 06_WindowsComponents32bit.txt -Value "*** Ran on $env:COMPUTERNAME on $date ***"
    Add-Content 00_AllOutputs.txt, 06_WindowsComponents32bit.txt -Value $(reg query "HKLM\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Setup\Oc Manager\Subcomponents")
    Add-Content 00_AllOutputs.txt, 06_WindowsComponents32bit.txt -Value $(" ")
    Write-output "Getting time sync status..."
    Write-Output " " | Out-File 17_TimeState_Status.txt
    Add-Content 00_AllOutputs.txt, 17_TimeState_Status.txt -Value "Getting time sync status..."
    Add-Content 00_AllOutputs.txt, 17_TimeState_Status.txt -Value "*** Output of the command: w32tm /monitor ***"

    Add-Content 00_AllOutputs.txt, 17_TimeState_Status.txt -Value $((w32tm /monitor 2>&1))

}



# Windows Vista or 2008 specific queries

function windowsVistaOr2008

{

    Write-Output "This is a $OSname machine."

    Write-Output "Getting installed programs with wmic (this will take between 2 and 5 minutes, only for Win2K8 or WinVista)..."

    Write-Output "*** Applicable PCI DSS Requirements: 2.2.1, 2.2.2, 2.2.3, 2.2.4, 5.1 ***"

    Write-Output " " | Out-File 07_InstalledPrograms_wmic.txt -Encoding ascii

    Add-Content 00_AllOutputs.txt, 07_InstalledPrograms_wmic.txt -Value "Getting installed programs with wmic"

    Add-Content 00_AllOutputs.txt, 07_InstalledPrograms_wmic.txt -Value "*** Applicable PCI DSS Requirements: 2.2.1, 2.2.2, 2.2.3, 2.2.4, 5.1 ***"

    Add-Content 00_AllOutputs.txt, 07_InstalledPrograms_wmic.txt -Value "*** Output of the command: wmic product get 'name,version,vendor,InstallDate,InstallLocation' ***"

    Add-Content 00_AllOutputs.txt, 07_InstalledPrograms_wmic.txt -Value "*** Ran on $env:COMPUTERNAME on $date ***"

    Add-Content 00_AllOutputs.txt, 07_InstalledPrograms_wmic.txt -Value $(wmic product get "name,version,vendor,InstallDate,InstallLocation")

    Add-Content 00_AllOutputs.txt, 07_InstalledPrograms_wmic.txt -Value $(" ")



    write-output "Getting time sync status.."  

    Write-Output " " | Out-File 17_TimeState_Status.txt -Encoding ascii

    Add-Content 00_AllOutputs.txt, 17_TimeState_Status.txt -Value "Getting time sync status.." 

    Add-Content 00_AllOutputs.txt, 17_TimeState_Status.txt -Value "*** Output of command: w32tm /query /status /verbose 2>&1 ***" 

    Add-Content 00_AllOutputs.txt, 17_TimeState_Status.txt -Value "*** Ran on $env:COMPUTERNAME on $date ***" 

    Add-Content 00_AllOutputs.txt, 17_TimeState_Status.txt -Value $((w32tm /query /status /verbose 2>&1))

    Add-Content 00_AllOutputs.txt, 17_TimeState_Status.txt -Value $(" ")

}



# Windows 7 and 2008R2 specific queries

function windows7or2008R2 

{

    Write-Output "This is a $OSname machine."

    write-output "Getting installed Windows Components..."

    Write-Output "*** Applicable PCI DSS Requirements: 2.2.1, 2.2.2, 2.2.3 ***"

    Write-Output " " | Out-File 06_WindowsComponents.txt -Encoding ascii

    Add-Content 00_AllOutputs.txt, 06_WindowsComponents.txt -Value "Getting installed Windows Components..."

    Add-Content 00_AllOutputs.txt, 06_WindowsComponents.txt -Value "*** Applicable PCI DSS Requirements: 2.2.1, 2.2.2, 2.2.3 ***"

    Add-Content 00_AllOutputs.txt, 06_WindowsComponents.txt -Value "*** Output of command: dism /online /get-features ***"

    Add-Content 00_AllOutputs.txt, 06_WindowsComponents.txt -Value "*** Ran on $env:COMPUTERNAME on $date ***" 

    Add-Content 00_AllOutputs.txt, 06_WindowsComponents.txt -Value $(dism /online /get-features)

    Add-Content 00_AllOutputs.txt, 06_WindowsComponents.txt -Value $(" ")



    Write-output "Getting installed Server Features..." 

    Write-Output " " | Out-File 06_ServerFeatures.txt -Encoding ascii

    Add-Content 00_AllOutputs.txt, 06_ServerFeatures.txt -Value "Getting installed Server Features..."

    Add-Content 00_AllOutputs.txt, 06_ServerFeatures.txt -Value "*** Output of command: wmic path Win32_ServerFeature ***" 

    Add-Content 00_AllOutputs.txt, 06_ServerFeatures.txt -Value "*** Ran on $env:COMPUTERNAME on $date ***" 

    Add-Content 00_AllOutputs.txt, 06_ServerFeatures.txt -Value $(" ")



    Write-Output "Getting installed programs with wmic (this will take between 2 and 5 minutes, only for Win2K8 or Win7)..."

    Write-Output "*** Applicable PCI DSS Requirements: 5.1 ***"

    Add-Content 00_AllOutputs.txt, 06_ServerFeatures.txt -Value "Getting installed programs with wmic"

    Add-Content 00_AllOutputs.txt, 06_ServerFeatures.txt -Value "*** Applicable PCI DSS Requirements: 5.1 ***"

    Add-Content 00_AllOutputs.txt, 06_ServerFeatures.txt -Value "*** Output of the command: wmic product get 'name,version,vendor,InstallDate,InstallLocation' ***" 

    Add-Content 00_AllOutputs.txt, 06_ServerFeatures.txt -Value "*** Ran on $env:COMPUTERNAME on $date ***"

    Add-Content 00_AllOutputs.txt, 06_ServerFeatures.txt -Value $(wmic product get "name,version,vendor,InstallDate,InstallLocation")

    Add-Content 00_AllOutputs.txt, 06_ServerFeatures.txt -Value $(" ")



    write-output "Getting time sync status.."  

    Write-Output " " | Out-File 17_TimeState_Status.txt -Encoding ascii

    Add-Content 00_AllOutputs.txt, 17_TimeState_Status.txt -Value "Getting time sync status.."

    Add-Content 00_AllOutputs.txt, 17_TimeState_Status.txt -Value "*** Output of command: w32tm /query /status /verbose 2>&1 ***" 

    Add-Content 00_AllOutputs.txt, 17_TimeState_Status.txt -Value "*** Ran on $env:COMPUTERNAME on $date ***"

    Add-Content 00_AllOutputs.txt, 17_TimeState_Status.txt -Value $((w32tm /query /status /verbose 2>&1))

    Add-Content 00_AllOutputs.txt, 17_TimeState_Status.txt -Value $(" ")



}



# Windows 8 or 2012 specific queries

function windows8or2012

{

    Write-Output "This is a $OSname machine."

}



# Windows 8 or 2012R2 specific queries

function windows8or2012r2        

{         

    Write-Output "This is a $OSname machine."

}



# Windows 10 or 2016 specific queries

function windows10or2016

{

    Write-Output "This is a $OSname machine."

}



if ($winver -eq 5.1) {windowsXP}

if ($winver -eq 5.2) {windows2003}

if ($winver -eq 6.0) {windowsVistaOr2008}

if ($winver -eq 6.1) {windows7or2008R2}

if ($winver -eq 6.2) {windows8or2012}

if ($winver -eq 6.3) {windows8or2012r2} 

if ($winver -eq 10.0) {windows10or2016}



# Output installed programs with wmi

Write-Output "Getting installed programs with wmi..."

Write-Output "*** Applicable PCI DSS Requirements: 2.2.1, 2.2.2, 2.2.3, 2.2.4, 5.1 ***"

Write-Output " " | Out-File 07_InstalledPrograms_wmioutput.txt -Encoding ascii

Add-Content 00_AllOutputs.txt, 07_InstalledPrograms_wmioutput.txt -Value "Getting installed programs with wmi..."

Add-Content 00_AllOutputs.txt, 07_InstalledPrograms_wmioutput.txt -Value "*** Applicable PCI DSS Requirements: 2.2.1, 2.2.2, 2.2.3, 2.2.4 5.1 ***"

Add-Content 00_AllOutputs.txt, 07_InstalledPrograms_wmioutput.txt -Value "*** Output of the command: Get-WmiObject -Class win32_product ***"

Add-Content 00_AllOutputs.txt, 07_InstalledPrograms_wmioutput.txt -Value "*** Full details of the command output are in 07_InstalledPrograms_wmioutput.csv ***"

Add-Content 00_AllOutputs.txt, 07_InstalledPrograms_wmioutput.txt -Value "*** Ran on $env:COMPUTERNAME on $date ***" 

Add-Content 00_AllOutputs.txt, 07_InstalledPrograms_wmioutput.txt -Value (Get-WmiObject -Class win32_product)

Get-WmiObject -Class win32_product| ConvertTo-Csv | out-file 07_InstalledPrograms_wmioutput.csv -Encoding ascii

Add-Content 00_AllOutputs.txt, 07_InstalledPrograms_wmioutput.txt -Value " "



# Output installed programs from the registry

Write-Output "Getting installed programs from the registry..."

Write-Output "*** Applicable PCI DSS Requirements: 2.2.1, 2.2.2, 2.2.3, 2.2.4, 5.1 ***"

Write-Output " " | Out-File 07_InstalledPrograms_regoutput.txt -Encoding ascii

Add-Content 00_AllOutputs.txt, 07_InstalledPrograms_regoutput.txt -Value "Getting installed programs from the registry..."

Add-Content 00_AllOutputs.txt, 07_InstalledPrograms_regoutput.txt -Value "*** Applicable PCI DSS Requirements: 2.2.1, 2.2.2, 2.2.3, 2.2.4, 5.1 ***"

Add-Content 00_AllOutputs.txt, 07_InstalledPrograms_regoutput.txt -Value "*** Output of the command: Get-ChildItem -path Registry::'HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall' -Recurse *** "

Add-Content 00_AllOutputs.txt, 07_InstalledPrograms_regoutput.txt -Value "*** Full details of the command output are in 07_InstalledPrograms_regoutput.csv ***"

Add-Content 00_AllOutputs.txt, 07_InstalledPrograms_regoutput.txt -Value "*** Ran on $env:COMPUTERNAME on $date ***"

Add-Content 00_AllOutputs.txt, 07_InstalledPrograms_regoutput.txt -Value (Get-ChildItem -path Registry::"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall" -Recurse) 

(Get-ChildItem -path Registry::"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall" -Recurse) | ConvertTo-Csv | out-file 07_InstalledPrograms_regoutput.csv -Encoding ascii

Add-Content 00_AllOutputs.txt, 07_InstalledPrograms_regoutput.txt -Value " " 





# Output running processes

Write-Output "Getting running processes..."

Write-Output "*** Applicable PCI DSS Requirements: 2.2.1, 2.2.2, 2.2.3, 2.2.4, 2.3.b, 2.3.c, 5.1 ***"

Write-Output " " | Out-File 08_RunningProcess_Overview.txt -Encoding ascii

Add-Content 00_AllOutputs.txt, 08_RunningProcess_Overview.txt -Value "Getting running processes..."

Add-Content 00_AllOutputs.txt, 08_RunningProcess_Overview.txt -Value "*** Applicable PCI DSS Requirements: 2.2.1, 2.2.2, 2.2.3, 2.2.4, 2.3.b, 2.3.c, 5.1 ***"

Add-Content 00_AllOutputs.txt, 08_RunningProcess_Overview.txt -Value "*** Output of the command: get-process | format-table -property Name, Path, CPU, FileVersion, ProductVersion, Description, Product, Id, SessionId ***"

Add-Content 00_AllOutputs.txt, 08_RunningProcess_Overview.txt -Value "*** Detialed output of the command 'get-process' is in 08_RunningProcess_AllDetails.csv ***"

Add-Content 00_AllOutputs.txt, 08_RunningProcess_Overview.txt -Value "*** Ran on $env:COMPUTERNAME on $date ***"

get-process | ConvertTo-Csv | Out-File 08_RunningProcess_AllDetails.csv -Encoding ascii

get-process | format-table -property Name, Path, CPU, FileVersion, ProductVersion, Description, Product, Id, SessionId >> tempprocess.txt

Add-Content 00_AllOutputs.txt, 08_RunningProcess_Overview.txt -Value (type tempprocess.txt) 

#del tempprocess.txt

Add-Content 00_AllOutputs.txt, 08_RunningProcess_Overview.txt -Value " " 



# Output services

Write-Output "Getting services..."

Write-Output "*** Applicable PCI DSS Requirements: 2.2.1, 2.2.2, 2.2.3, 2.3.c, 11.5.a ***"

Write-Output " " | Out-File 09_Services_Overview.txt -Encoding ascii

Add-Content 00_AllOutputs.txt, 09_Services_Overview.txt -Value "Getting services..."

Add-Content 00_AllOutputs.txt, 09_Services_Overview.txt -Value "*** Applicable PCI DSS Requirements: 2.2.1, 2.2.2, 2.2.3, 2.3.c, 11.5.a ***"

Add-Content 00_AllOutputs.txt, 09_Services_Overview.txt -Value "*** Output of the command: get-service | format-table -property Name, DisplayName, ServiceName, ServicesDependedOn, Status, ServiceType ***" 

Add-Content 00_AllOutputs.txt, 09_Services_Overview.txt -Value "*** Detailed output is in 09_Services_Details.csv ***"

get-process | ConvertTo-Csv | Out-File 09_Services_Details.csv -Encoding ascii

get-service | format-table -property Name, DisplayName, ServiceName, ServicesDependedOn, Status, ServiceType >> tempservices.txt

Add-Content 00_AllOutputs.txt, 09_Services_Overview.txt -Value (type tempservices.txt) 

Add-Content 00_AllOutputs.txt, 09_Services_Overview.txt -Value " " 





# Output open ports

Write-Output "Getting open ports..."

Write-Output "*** Applicable PCI DSS Requirements: 2.2.3 ***"

Write-Output " " | Out-File 10_ListeningPorts.txt -Encoding ascii

Add-Content 00_AllOutputs.txt, 10_ListeningPorts.txt -Value "Getting open ports..."

Add-Content 00_AllOutputs.txt, 10_ListeningPorts.txt -Value "*** Applicable PCI DSS Requirements: 2.2.3 ***"

Add-Content 00_AllOutputs.txt, 10_ListeningPorts.txt -Value "*** Output of the command: netstat -ano | findstr 'LISTENING' ***"

Add-Content 00_AllOutputs.txt, 10_ListeningPorts.txt -Value "*** Ran on $env:COMPUTERNAME on $date ***"

Add-Content 00_AllOutputs.txt, 10_ListeningPorts.txt -Value $(netstat -ano | findstr "LISTENING")

Add-Content 00_AllOutputs.txt, 10_ListeningPorts.txt -Value $(" ")



# Output patches

Write-Output "Getting installed patches..."

Write-Output "*** Applicable PCI DSS Requirements: 2.2.3, 6.2 ***"

Write-Output " " | Out-File 11_InstalledPatches.txt -Encoding ascii

Add-Content 00_AllOutputs.txt, 11_InstalledPatches.txt -Value "Getting patches..."

Add-Content 00_AllOutputs.txt, 11_InstalledPatches.txt -Value "*** Applicable PCI DSS Requirements: 2.2.3, 6.2 ***"

Add-Content 00_AllOutputs.txt, 11_InstalledPatches.txt -Value "*** Output of the command: Get-Hotfix ***"

Add-Content 00_AllOutputs.txt, 11_InstalledPatches.txt -Value "*** Ran on $env:COMPUTERNAME on $date ***"

Add-Content 00_AllOutputs.txt, 11_InstalledPatches.txt -Value "*** Detailed output is in 11_InstalledPatches.csv ***"

Add-Content 00_AllOutputs.txt, 11_InstalledPatches.txt -Value $(Get-HotFix)

Get-HotFix | ConvertTo-Csv | Out-File 11_InstalledPatches.csv -Encoding ascii

Add-Content 00_AllOutputs.txt, 11_InstalledPatches.txt -Value $(" ")



# Output Local Admin Group membership

write-output "Getting Local Admin Group Membership..."

write-output "*** Applicable PCI DSS Requirements: 2.2.3, 7.2.2, 7.2.3, 8.1, 10.4.2.a ***"

Write-Output " " | Out-File 12_LocalAdmins.txt -Encoding ascii

Add-Content 00_AllOutputs.txt, 12_LocalAdmins.txt -Value "Getting Local Admin Group Membership..."

Add-Content 00_AllOutputs.txt, 12_LocalAdmins.txt -Value "*** Applicable PCI DSS Requirements: 2.2.3, 7.2.2, 7.2.3, 8.1, 10.4.2.a ***"

Add-Content 00_AllOutputs.txt, 12_LocalAdmins.txt -Value "*** Output of the command: net localgroup Administrators ***"

Add-Content 00_AllOutputs.txt, 12_LocalAdmins.txt -Value "*** Ran on $env:COMPUTERNAME on $date ***"

Add-Content 00_AllOutputs.txt, 12_LocalAdmins.txt -Value $(net localgroup Administrators)



# Check to see if storing LanMan hashes is enabled

Write-Output "Checking to see if storing LanMan hashes is enabled..."

write-output "*** Applicable PCI DSS Requirements: 8.4 ***"

Write-Output " " | Out-File 13_LanmanHash.txt -Encoding ascii

Add-Content 00_AllOutputs.txt, 13_LanmanHash.txt -Value "Checking to see if storing LanMan hashes is enabled..."

Add-Content 00_AllOutputs.txt, 13_LanmanHash.txt -Value "*** Applicable PCI DSS Requirements: 8.4 ***"

Add-Content 00_AllOutputs.txt, 13_LanmanHash.txt -Value "*** Output of the command: Get-ItemProperty -Path 'Registry::HKLM\SYSTEM\CurrentControlSet\Control\Lsa' NoLmHash ***"

Add-Content 00_AllOutputs.txt, 13_LanmanHash.txt -Value "*** Ran on $env:COMPUTERNAME on $date ***" 

Get-ItemProperty -Path "Registry::HKLM\SYSTEM\CurrentControlSet\Control\Lsa" >> templanman.txt

Add-Content 00_AllOutputs.txt, 13_LanmanHash.txt -Value (type templanman.txt)

Add-Content 00_AllOutputs.txt, 13_LanmanHash.txt -Value " " 

#del templanman.txt



# Output Local RDP settings 

write-output "Getting Local RDP settings (encryption level, timeout, etc)..."

Write-Output "*** Applicable PCI DSS Requirements: 2.2.3, 2.3.b, 8.4 ***"

Write-Output " " | Out-File 14_RDPSettings_Local.txt -Encoding ascii

Add-Content 00_AllOutputs.txt, 14_RDPSettings_Local.txt -Value "Getting Local RDP settings (encryption level, timeout, etc)..."

Add-Content 00_AllOutputs.txt, 14_RDPSettings_Local.txt -Value "*** Applicable PCI DSS Requirements: 2.2.3, 2.3.b, 8.4 ***"

Add-Content 00_AllOutputs.txt, 14_RDPSettings_Local.txt -Value "*** Output of the command:   get-item Registry::'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp' ***"

Add-Content 00_AllOutputs.txt, 14_RDPSettings_Local.txt -Value "*** Ran on $env:COMPUTERNAME on $date ***"

get-item Registry::"HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp" >> tempRDPSettings_Local.txt

Add-Content 00_AllOutputs.txt, 14_RDPSettings_Local.txt -Value (type tempRDPSettings_Local.txt)

Add-Content 00_AllOutputs.txt, 14_RDPSettings_Local.txt -Value " "

#del tempRDPSettings_Local.txt



# Output Domain Enforced RDP settings 

write-output "Getting Domain Enforced RDP settings (encryption level, timeout, etc)..."

Write-Output "*** Applicable PCI DSS Requirements: 2.2.3, 2.3.b ***"

Write-Output " " | Out-File 14_RDPSettings_Domain.txt -Encoding ascii

Add-Content 00_AllOutputs.txt, 14_RDPSettings_Domain.txt -Value "Getting Domain Enforced RDP settings (encryption level, timeout, etc)..."

Add-Content 00_AllOutputs.txt, 14_RDPSettings_Domain.txt -Value "*** Applicable PCI DSS Requirements: 2.2.3, 2.3.b ***"

Add-Content 00_AllOutputs.txt, 14_RDPSettings_Domain.txt -Value "*** Output of the command: get-item Registry::'HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services'***" 

Add-Content 00_AllOutputs.txt, 14_RDPSettings_Domain.txt -Value "*** Ran on $env:COMPUTERNAME on $date ***"

get-item Registry::"HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services" >> tempRDPSettings_Domain.txt

Add-Content 00_AllOutputs.txt, 14_RDPSettings_Domain.txt -Value (type tempRDPSettings_Domain.txt)

Add-Content 00_AllOutputs.txt, 14_RDPSettings_Domain.txt -Value " " 

#del tempRDPSettings_Domain.txt



# Output RDP Master Settings

Write-output "Getting RDP Master Settings..."

Write-Output "*** Applicable PCI DSS Requirements: 2.2.3 ***"

Write-Output " " | Out-File 14_RDPSettings_Master.txt -Encoding ascii

Add-Content 00_AllOutputs.txt, 14_RDPSettings_Master.txt -Value "Getting RDP Master Settings..."

Add-Content 00_AllOutputs.txt, 14_RDPSettings_Master.txt -Value "*** Applicable PCI DSS Requirements: 2.2.3 ***"

Add-Content 00_AllOutputs.txt, 14_RDPSettings_Master.txt -Value "*** Output of the command:  Get-WmiObject -Class Win32_TerminalServiceSetting -Namespace root\CIMV2\TerminalServices -ComputerName $env:COMPUTERNAME***"

Add-Content 00_AllOutputs.txt, 14_RDPSettings_Master.txt -Value "*** Ran on $env:COMPUTERNAME on $date ***"

Get-WmiObject -Class Win32_TerminalServiceSetting -Namespace root\CIMV2\TerminalServices -ComputerName $env:COMPUTERNAME >> tempRDPSettings_Master.txt

Add-Content 00_AllOutputs.txt, 14_RDPSettings_Master.txt -Value (type tempRDPSettings_Master.txt)

Add-Content 00_AllOutputs.txt, 14_RDPSettings_Master.txt -Value " " 

#del tempRDPSettings_Master.txt



# Output screensaver settings

write-output "Getting screensaver settings..."

Write-Output "*** Applicable PCI DSS Requirements: 2.2.3, 8.1.8 ***"

Write-Output " " | Out-File 15_ScreenTimeout.txt -Encoding ascii

Add-Content 00_AllOutputs.txt, 15_ScreenTimeout.txt -Value "Getting screensaver settings..."

Add-Content 00_AllOutputs.txt, 15_ScreenTimeout.txt -Value "*** Applicable PCI DSS Requirements: 2.2.3, 8.1.8 ***"

Add-Content 00_AllOutputs.txt, 15_ScreenTimeout.txt -Value "*** Output of the command: Get-WmiObject -ComputerName $env:COMPUTERNAME win32_Desktop ***"

Add-Content 00_AllOutputs.txt, 15_ScreenTimeout.txt -Value "*** Ran on $env:COMPUTERNAME on $date ***"

Get-WmiObject -ComputerName $env:COMPUTERNAME win32_Desktop >> tempScreenTimeout.txt

Add-Content 00_AllOutputs.txt, 15_ScreenTimeout.txt -Value (type tempScreenTimeout.txt)

Add-Content 00_AllOutputs.txt, 15_ScreenTimeout.txt -Value " " 

#del tempScreenTimeout.txt



# Output time settings

Write-Output "Getting time settings..."

Write-Output "*** Applicable PCI DSS Requirements: 2.2.3, 10.4, 10.4.1.a ***" 

Write-Output " " | Out-File 16_TimeSettings.txt -Encoding ascii

Add-Content 00_AllOutputs.txt, 16_TimeSettings.txt -Value "Getting time settings..."

Add-Content 00_AllOutputs.txt, 16_TimeSettings.txt -Value "*** Applicable PCI DSS Requirements: 2.2.3, 10.4 ***"

Add-Content 00_AllOutputs.txt, 16_TimeSettings.txt -Value "*** Output of command: Get-ChildItem Registry::HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\W32Time -Recurse ***"

Add-Content 00_AllOutputs.txt, 16_TimeSettings.txt -Value "*** Ran on $env:COMPUTERNAME on $date ***"

Get-ChildItem Registry::HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\W32Time -Recurse >> tempTimeSettings.txt

Add-Content 00_AllOutputs.txt, 16_TimeSettings.txt -Value (type tempTimeSettings.txt)

Add-Content 00_AllOutputs.txt, 16_TimeSettings.txt -Value " " 

#del tempTimeSettings.txt



# Output Snare settings

write-output "Getting Snare settings..."

Write-Output " " | Out-File 18_SnareSettings.txt -Encoding ascii

Add-Content 00_AllOutputs.txt, 18_SnareSettings.txt -Value "Getting Snare settings..."

Add-Content 00_AllOutputs.txt, 18_SnareSettings.txt -Value "***Output of command:  Get-Item -Path 'Registry::HKLM\SOFTWARE\InterSect Alliance\AuditService\Network' -ErrorAction Ignore ***"

Add-Content 00_AllOutputs.txt, 18_SnareSettings.txt -Value "*** Ran on $env:COMPUTERNAME on $date ***" 

Get-Item -Path "Registry::HKLM\SOFTWARE\InterSect Alliance\AuditService\Network" -ErrorAction Ignore >> tempSnareSettings.txt

Add-Content 00_AllOutputs.txt, 18_SnareSettings.txt -Value (type tempSnareSettings.txt)

Add-Content 00_AllOutputs.txt, 18_SnareSettings.txt -Value " "

#del tempSnareSettings.txt



# Output Local RDP Group Membership

Write-Output "Getting Local RDP Group Membership..." 

Write-Output "*** Applicable PCI DSS Requirements: 2.2.3 ***"

Write-Output " " | Out-File 19_LocalRDPUsers.txt -Encoding ascii

Add-Content 00_AllOutputs.txt, 19_LocalRDPUsers.txt -Value "Getting Local RDP Group Membership..." 

Add-Content 00_AllOutputs.txt, 19_LocalRDPUsers.txt -Value "*** Applicable PCI DSS Requirements: 2.2.3 ***"

Add-Content 00_AllOutputs.txt, 19_LocalRDPUsers.txt -Value "*** Output of command: net localgroup 'Remote Desktop Users' ***"

Add-Content 00_AllOutputs.txt, 19_LocalRDPUsers.txt -Value "*** Ran on $env:COMPUTERNAME on $date ***" 

Add-Content 00_AllOutputs.txt, 19_LocalRDPUsers.txt -Value $(net localgroup "Remote Desktop Users")

Add-Content 00_AllOutputs.txt, 19_LocalRDPUsers.txt -Value " " 



# Output Local Power Users Group Membership

Write-Output "Getting Local Power Users Group Membership..."

Write-Output "*** Applicable PCI DSS Requirements: 2.2.3, 7.2.2, 7.2.3, 8.1, 10.4.2.a ***"

Write-Output " " | Out-File 20_LocalPowerUsers.txt -Encoding ascii

Add-Content 00_AllOutputs.txt, 20_LocalPowerUsers.txt -Value "Getting Local Power Users Group Membership..." 

Add-Content 00_AllOutputs.txt, 20_LocalPowerUsers.txt -Value "*** Applicable PCI DSS Requirements: 2.2.3, 7.2.2, 7.2.3, 8.1, 10.4.2.a ***"

Add-Content 00_AllOutputs.txt, 20_LocalPowerUsers.txt -Value "*** Output of command: net localgroup Power Users' ***"

Add-Content 00_AllOutputs.txt, 20_LocalPowerUsers.txt -Value "*** Ran on $env:COMPUTERNAME on $date ***"

Add-Content 00_AllOutputs.txt, 20_LocalPowerUsers.txt -Value $(net localgroup "Power Users")



# Output Server Operators Group Membership

Write-Output "Getting Server Operators Group Membership..."

Write-Output "*** Applicable PCI DSS Requirements: 2.2.3, 7.2.2, 7.2.3, 8.1, 10.4.2.a ***"

Write-Output " " | Out-File 20_LocalServerOperators.txt -Encoding ascii

Add-Content 00_AllOutputs.txt, 20_LocalServerOperators.txt -Value "Getting Server Operators Group Membership..."

Add-Content 00_AllOutputs.txt, 20_LocalServerOperators.txt -Value "*** Applicable PCI DSS Requirements: 2.2.3, 7.2.2, 7.2.3, 8.1, 10.4.2.a ***"

Add-Content 00_AllOutputs.txt, 20_LocalServerOperators.txt -Value "*** Output of command: net localgroup 'Server Operators' ***"

Add-Content 00_AllOutputs.txt, 20_LocalServerOperators.txt -Value "*** NOTE: This command may result in an error if the group does not exist. ***"

Write-Output "*** NOTE: This command may result in an error if the group does not exist. ***"

Add-Content 00_AllOutputs.txt, 20_LocalServerOperators.txt -Value "*** Ran on $env:COMPUTERNAME on $date ***"

Add-Content 00_AllOutputs.txt, 20_LocalServerOperators.txt -Value $(net localgroup "Server Operators")

Add-Content 00_AllOutputs.txt, 20_LocalServerOperators.txt -Value $(" ")



# Output startup programs

Write-Output "Getting startup programs..."

Write-Output " " | Out-File 21_StartupPrograms.txt -Encoding ascii

Add-Content 00_AllOutputs.txt, 21_StartupPrograms.txt -Value "Getting startup programs..."

Add-Content 00_AllOutputs.txt, 21_StartupPrograms.txt -Value "*** Output of command: Get-CimInstance win32_startupcommand | Select-Object Name, command, Location, User | Format-List ***"

Add-Content 00_AllOutputs.txt, 21_StartupPrograms.txt -Value "*** Ran on $env:COMPUTERNAME on $date ***" 

Get-CimInstance win32_startupcommand | Select-Object Name, command, Location, User | Format-List >> tempStartupPrograms.txt

Add-Content 00_AllOutputs.txt, 21_StartupPrograms.txt (type tempStartupPrograms.txt)

Add-Content 00_AllOutputs.txt, 21_StartupPrograms.txt -Value $(" ")

#del tempStartupPrograms.txt



# Output user logon history

Write-Output "Getting user logon history..."

Write-Output " " | Out-File 22_UserLogonHistory.txt -Encoding ascii

Add-Content 00_AllOutputs.txt, 22_UserLogonHistory.txt -Value "Getting user logon history..."

Add-Content 00_AllOutputs.txt, 22_UserLogonHistory.txt -Value "*** Output of command:  wmic netlogin get 'name,Comment,LastLogon,PasswordAge,BadPasswordCount,NumberOfLogons' ***"

Add-Content 00_AllOutputs.txt, 22_UserLogonHistory.txt -Value "*** Ran on $env:COMPUTERNAME on $date ***"

Add-Content 00_AllOutputs.txt, 22_UserLogonHistory.txt -Value $(wmic netlogin get "name,Comment,LastLogon,PasswordAge,BadPasswordCount,NumberOfLogons")

         

# Output known routes

Write-Output "Getting known routes..."    

Write-Output " " | Out-File 23_Routes.txt -Encoding ascii

Add-Content 00_AllOutputs.txt, 23_Routes.txt -Value "Getting known routes..."

Add-Content 00_AllOutputs.txt, 23_Routes.txt -Value "*** Output of command: Get-WmiObject win32_ip4routetable | Select-Object PScomputername, Destination, Mask, NextHop *** "

Add-Content 00_AllOutputs.txt, 23_Routes.txt -Value "*** Ran on $env:COMPUTERNAME on $date ***"     

Get-WmiObject win32_ip4routetable | Select-Object PScomputername, Destination, Mask, NextHop >> tempRoutes.txt

Add-Content 00_AllOutputs.txt, 23_Routes.txt -Value (type tempRoutes.txt)

Add-Content 00_AllOutputs.txt, 23_Routes.txt -Value " " 

#del tempRoutes.txt





# Output Firewall rules

Write-Output "Getting firewall rules..."

Write-Output "*** Applicable PCI DSS Requirements: 1.4 ***"

Write-Output " " | Out-File 24_FirewallRules.txt -Encoding ascii

Add-Content 00_AllOutputs.txt, 24_FirewallRules.txt -Value "Getting firewall rules..."

Add-Content 00_AllOutputs.txt, 24_FirewallRules.txt -Value "*** Applicable PCI DSS Requirements: 1.4 ***"

Add-Content 00_AllOutputs.txt, 24_FirewallRules.txt -Value "*** Output of command: netsh advfirewall show allprofiles ***"

Add-Content 00_AllOutputs.txt, 24_FirewallRules.txt -Value "*** Ran on $env:COMPUTERNAME on $date ***" 

# The 2 PS commands  below don't always work, so they are currently commented out. I've included the DOS commands below them, which usually work.

# Get-NetFirewallRule >> 00_AllOutputs.txt

# Get-NetFirewallRule >> 24_FirewallRules.txt

Add-Content 00_AllOutputs.txt, 24_FirewallRules.txt -Value (netsh advfirewall show allprofiles )

Add-Content 00_AllOutputs.txt, 24_FirewallRules.txt -Value " " 





# Output Password Policies

Write-Output "Getting password policies..."

Write-Output "*** Applicable PCI DSS Requirements: 8.1.4, 8.1.6, 8.1.7, 8.2.3, 8.2.4, 8.2.5  ***"

Write-Output " " | Out-File 25_PasswordPolicies.txt -Encoding ascii

Add-Content 00_AllOutputs.txt, 25_PasswordPolicies.txt -Value "Getting password policies..."

Add-Content 00_AllOutputs.txt, 25_PasswordPolicies.txt -Value "*** Applicable PCI DSS Requirements: 8.1.4, 8.1.6, 8.1.7, 8.2.3, 8.2.4, 8.2.5  ***"

Add-Content 00_AllOutputs.txt, 25_PasswordPolicies.txt -Value "*** Output of command: Get-ADDefaultDomainPasswordPolicy ***"

Add-Content 00_AllOutputs.txt, 25_PasswordPolicies.txt -Value "*** Ran on $env:COMPUTERNAME on $date ***"

# The 2 PS commands  below don't always work, so they are currently commented out. I've included the DOS commands below them, which usually work.

# Get-ADDefaultDomainPasswordPolicy >> 00_AllOutputs.txt

# Get-ADDefaultDomainPasswordPolicy >> 25_PasswordPolicies.txt

net accounts | Format-List >> tempPasswordPolicies.txt

Add-Content 00_AllOutputs.txt, 25_PasswordPolicies.txt -Value (type tempPasswordPolicies.txt)

Add-Content 00_AllOutputs.txt, 25_PasswordPolicies.txt -Value " "

#del tempPasswordPolicies.txt



Import-module ActiveDirectory



# Output all File Shares for Server.

Write-Output "Getting all files shares for server..."

Write-Output " " | Out-File 26_FileShares.txt -Encoding ascii

Add-Content 00_AllOutputs.txt, 26_FileShares.txt -Value "Getting file shares..."

Add-Content 00_AllOutputs.txt, 26_FileShares.txt -Value "*** Output of command: net share ***" 

Add-Content 00_AllOutputs.txt, 26_FileShares.txt -Value "*** Ran on $env:COMPUTERNAME on $date ***"

Add-Content 00_AllOutputs.txt, 26_FileShares.txt -Value (net share)

Add-Content 00_AllOutputs.txt, 26_FileShares.txt -Value " " 





# Output all domain controllers

Write-Output "Getting all domain controllers..."

Write-Output " " | Out-File 27_DomainControllers.txt -Encoding ascii

Add-Content 00_AllOutputs.txt, 27_DomainControllers.txt -Value "Getting domain controllers..."

Add-Content 00_AllOutputs.txt, 27_DomainControllers.txt -Value "*** Output of  the command: (Get-ADForest).Domains | %{ Get-ADDomainController -Filter * -Server $_ } ***" 

Add-Content 00_AllOutputs.txt, 27_DomainControllers.txt -Value "*** Ran on $env:COMPUTERNAME on $date ***"



(Get-ADForest).Domains | %{ Get-ADDomainController -Filter * -Server $_ } >> tempADdcs.txt



Add-Content 00_AllOutputs.txt, 27_DomainControllers.txt -Value (type tempADdcs.txt)

Add-Content 00_AllOutputs.txt, 27_DomainControllers.txt -Value " "

#del tempADdcs.txt





(Get-ADForest).Domains | %{ Get-ADDomainController -Filter * -Server $_ } >> 27_DomainControllers.txt



# Output all FSMO Servers

Write-Output "Getting all FSMO Servers..."

Write-Output " " | Out-File 28_FSMOservers.txt -Encoding ascii

Add-Content 00_AllOutputs.txt, 28_FSMOservers.txt -Value "Getting all FSMO Servers..."

Add-Content 00_AllOutputs.txt, 28_FSMOservers.txt -Value "*** Output of the command: netdom query fsmo ***" 

Add-Content 00_AllOutputs.txt, 28_FSMOservers.txt -Value "*** Ran on $env:COMPUTERNAME on $date ***"

netdom query fsmo >> tempFSMOservers.txt

Add-Content 00_AllOutputs.txt, 28_FSMOservers.txt -Value (type tempFSMOservers.txt)

Add-Content 00_AllOutputs.txt, 28_FSMOservers.txt -Value " " 

#del tempFSMOservers.txt



# Output Global Catalog Servers

Write-Output "Getting Global Catalog Servers..."

Write-Output " " | Out-File 29_GlobalCatalogServers.txt -Encoding ascii

Add-Content 00_AllOutputs.txt, 29_GlobalCatalogServers.txt -Value "Getting Global Catalog Servers..."

Add-Content 00_AllOutputs.txt, 29_GlobalCatalogServers.txt -Value "*** Output of the command: Get-ADDomainController -Filter {IsGlobalCatalog -eq $true} ***"

Add-Content 00_AllOutputs.txt, 29_GlobalCatalogServers.txt -Value "*** Ran on $env:COMPUTERNAME on $date ***"

Get-ADDomainController -Filter {IsGlobalCatalog -eq $true} >> tempGlobalCatalogServers.txt

Add-Content 00_AllOutputs.txt, 29_GlobalCatalogServers.txt -Value (type tempGlobalCatalogServers.txt)

Add-Content 00_AllOutputs.txt, 29_GlobalCatalogServers.txt -Value " "

#del tempGlobalCatalogServers.txt


 

if (test-path c:\windows\system32\dcdiag.exe){


    # Getting Groups and Members of Groups

    Write-Output  "Getting groups and members of groups..."

    Write-Output " " | Out-File 30_ADGroupsAndMembers.txt -Encoding ascii

    Add-Content 00_AllOutputs.txt, 30_ADGroupsAndMembers.txt -Value "Getting groups and members of groups..."

    Add-Content 00_AllOutputs.txt, 30_ADGroupsAndMembers.txt -Value "*** Output of the command: Get-ADGroup -Filter * ***"

    Add-Content 00_AllOutputs.txt, 30_ADGroupsAndMembers.txt -Value "*** Ran on $env:COMPUTERNAME on $date ***"

    Get-ADGroup -Filter 'GroupCategory -eq "Security"' >> tempADSecurityGroupsAndMembers.txt

    Add-Content 00_AllOutputs.txt, 30_ADSecurityGroupsAndMembers.txt -Value (type tempADSecurityGroupsAndMembers.txt)

    Add-Content 00_AllOutputs.txt, 30_ADSecurityGroupsAndMembers.txt -Value "See 30_ADSecurityGroupsAndMembers.csv for full output of AD groups and their members."

    #del tempADSecurityGroupsAndMembers.txt



    #// Set CSV file name 

    $CSVFile = "30_ADSecurityGroupsAndMembers.csv" 

 

    #// Create emy array for CSV data 

    $CSVOutput = @() 

 

    #// Get all AD groups in the domain 

    $ADGroups = Get-ADGroup -Filter GroupCategory -eq "Security" 

 

    #// Set progress bar variables 

     $i=0 

     $tot = $ADGroups.count 

 

     foreach ($ADGroup in $ADGroups) { 

        #// Set up progress bar 

 

        $i++ 

        $status = "{0:N0}" -f ($i / $tot * 100) 

       Write-Progress -Activity "Exporting AD Groups" -status "Processing Group $i of $tot : $status% Completed" -PercentComplete ($i / $tot * 100) 

 

        #// Ensure Members variable is empty 

        $Members = "" 

 

        #// Get group members which are also groups and add to string 

        $MembersArr = Get-ADGroup -filter {Name -eq $ADGroup.Name} | Get-ADGroupMember |  select Name 

        if ($MembersArr) { 

            foreach ($Member in $MembersArr) { 

                $Members = $Members + "," + $Member.Name 

            } 

            $Members = $Members.Substring(1,($Members.Length) -1) 

        } 

 

        #// Set up hash table and add values 

        $HashTab = $NULL 

        $HashTab = [ordered]@{ 

            "Name" = $ADGroup.Name 

            "Category" = $ADGroup.GroupCategory 

            "Scope" = $ADGroup.GroupScope 

            "Members" = $Members 

        } 

 

        #// Add hash table to CSV data array 

        $CSVOutput += New-Object PSObject -Property $HashTab 

    } 


    #// Export to CSV files 

    $CSVOutput | Sort-Object Name | Export-Csv 30_ADSecurityGroupsAndMembers.csv -NoTypeInformation 



    # Diagnosing Domain Controller for Health Issues...

    Write-Output "Getting Diagnosing Domain Controller for Health Issues..."

    Write-Output " " | Out-File 31_DiagDC.txt -Encoding ascii

    Add-Content 00_AllOutputs.txt, 31_DiagDC.txt -Value "Diagnosing Domain Controller for Health Issues..."

    Add-Content 00_AllOutputs.txt, 31_DiagDC.txt -Value "*** Output of command: DCDIAG ***"

    Add-Content 00_AllOutputs.txt, 31_DiagDC.txt -Value "*** Ran on $env:COMPUTERNAME on $date ***"

    Add-Content 00_AllOutputs.txt, 31_DiagDC.txt -Value (DCDIAG)

    Add-Content 00_AllOutputs.txt, 31_DiagDC.txt -Value " " 





    # Getting Replication Summary...

    Write-Output "Getting Replication Summary..."

    Write-Output " " | Out-File 32_ReplicationSummary.txt -Encoding ascii

    Add-Content 00_AllOutputs.txt, 32_ReplicationSummary.txt -Value "Getting Replication Summary..."

    Add-Content 00_AllOutputs.txt, 32_ReplicationSummary.txt -Value "*** Output of command: Get-ADAccountAuthorizationGroup �Identity 'Windows Authorization Access Group' ***"

    Add-Content 00_AllOutputs.txt, 32_ReplicationSummary.txt -Value "*** Ran on $env:COMPUTERNAME on $date ***"



    Get-ADAccountAuthorizationGroup -Identity "Windows Authorization Access Group" >> tempReplicationSummary.txt

    Add-Content 00_AllOutputs.txt, 32_ReplicationSummary.txt -Value (type tempReplicationSummary.txt)

    Add-Content 00_AllOutputs.txt, 32_ReplicationSummary.txt -Value ""

    #del tempReplicationSummary.txt



    Add-Content 00_AllOutputs.txt, 32_ReplicationSummary.txt -Value "*** Output of command: Get-ADReplicationPartnerMetadata -Target * -Partition * | Select-Object Server,Partition,Partner,ConsecutiveReplicationFailures,LastReplicationSuccess,LastRepicationResult | Out-GridView ***"

    Get-ADReplicationPartnerMetadata -Target * -Partition * | Select-Object Server,Partition,Partner,ConsecutiveReplicationFailures,LastReplicationSuccess,LastRepicationResult >> tempReplicationSummary.txt

    Add-Content 00_AllOutputs.txt, 32_ReplicationSummary.txt -Value (type tempReplicationSummary.txt)

    Add-Content 00_AllOutputs.txt, 32_ReplicationSummary.txt -Value " " 

    #del tempReplicationSummary.txt



    # Getting All OUs in Domain...

    Write-Output "Getting all OUs in Domain..."

    Write-Output " " | Out-File 33_OUs_Domain.txt -Encoding ascii

    Add-Content 00_AllOutputs.txt, 33_OUs_Domain.txt -Value "Getting all OUs in Domain..."

    Add-Content 00_AllOutputs.txt, 33_OUs_Domain.txt -Value "*** Output of command: Get-ADOrganizationalUnit -Filter 'Name -like '*'' | Format-Table Name, DistinguishedName -A ***"

    Add-Content 00_AllOutputs.txt, 33_OUs_Domain.txt -Value "*** Ran on $env:COMPUTERNAME on $date ***"

    Get-ADOrganizationalUnit -Filter 'Name -like "*"' | Format-Table Name, DistinguishedName -A >> tempOUs_Domain.txt

    Add-Content 00_AllOutputs.txt, 33_OUs_Domain.txt -Value (type tempOUs_Domain.txt)

    Add-Content 00_AllOutputs.txt, 33_OUs_Domain.txt -Value " " 

    #del tempOUs_Domain.txt
    
}





# Anaylysis function.  Search the output files for obvious issues to alert the QSA to investigate. 

Write-Output "Analyzing output files..."

Write-Output "*** Ran on $env:COMPUTERNAME on $date. Files in the $env:COMPUTERNAME folder were analyzed. ***" | Out-File 00_Analysis.txt -Encoding ascii

Select-String .\10_ListeningPorts.txt -pattern " 445", " 161", " 162", " 20", " 21", " 23", " 107", " 102", " 103", " 220", " 69", " 80", " 8080", " 513", " 514", " 111", " 2049" >> tempAnalysis.txt

Add-Content 00_Analysis.txt -value (type tempAnalysis.txt)

#del tempAnalysis.txt



Select-String .\00_AllOutputs.txt -Pattern "MinimumPasswordLength = 6", "MinimumPasswordLength = 5", "MinimumPasswordLength = 4", "MinimumPasswordLength = 3", "MinimumPasswordLength = 2", "MinimumPasswordLength = 1", "MinimumPasswordLength = 0", "MinimumPasswordLength = 6" >> tempAnalysis.txt

Add-Content 00_Analysis.txt -value (type tempAnalysis.txt)

#del tempAnalysis.txt

Select-String .\00_AllOutputs.txt -Pattern "PasswordComplexity = 0" >> tempAnalysis.txt

Add-Content 00_Analysis.txt -value (type tempAnalysis.txt)

#del tempAnalysis.txt

Add-Content 00_Analysis.txt -value " " 



Select-String .\00_AllOutputs.txt -Pattern "MinimumPasswordAge = 0" >> tempAnalysis.txt

Add-Content 00_Analysis.txt -value (type tempAnalysis.txt)

#del tempAnalysis.txt

Add-Content 00_Analysis.txt -value " " 



Select-String .\00_AllOutputs.txt -Pattern "PasswordHistorySize = 0", "PasswordHistorySize = 1", "PasswordHistorySize = 2", "PasswordHistorySize = 3", "PasswordHistorySize = 4" >> tempAnalysis.txt

Add-Content 00_Analysis.txt -value (type tempAnalysis.txt)

#del tempAnalysis.txt

Add-Content 00_Analysis.txt -value " " 



Add-Content 00_Analysis.txt -Value "Any issues were outputted above."



# Check if another zip file is here and then remove  

#Write-Output "Removing old zip (if any)..."d

#Write-Output "*** NOTE: This may give an error or generate a prompt if the file already exists.  Just click 'Yes' to delete the old file. ***"

#if ($env:COMPUTERNAME.zip){del "$env:COMPUTERNAME.zip" -Recurse -ErrorAction Ignore}



# zip up output files

Write-Output "Zipping up files..."

$SourceDirectory = Get-Location

cd ..

$DestDirectory = Get-Location 

Add-Type -Assembly "System.IO.Compression.FileSystem" 



[System.IO.Compression.ZipFile]::CreateFromDirectory("$SourceDirectory", "$DestDirectory/$env:COMPUTERNAME.zip") 

#del "$env:COMPUTERNAME" -Recurse -ErrorAction Ignore



Write-Output "Script has completed.  Check@above for errors and send any issues, bugs, or recommendations to Scott Ritchie (scott.ritchie@aprio.com)"



$finaltime = $Stopwatch.Elapsed.TotalSeconds

Write-Output "This script took '$finaltime' seconds to run."


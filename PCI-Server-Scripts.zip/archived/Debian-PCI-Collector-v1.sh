#!/bin/bash

if [ "$(id -u)" -ne 0 ]; then
	echo 'ERROR: You need to be root to run this script. (exiting)'
	exit
fi

outdir=$(hostname)

if [ -d $outdir ]; then
	rm -rf $outdir
fi

mkdir $outdir

p1=''
p2=''

{

echo '1/21 Performing Internet Connection Tests'
traceroute www.google.com  >	$outdir/1.2.1.a.google_trace.txt &
p1=$!
traceroute www.yahoo.com >	$outdir/1.2.1.a.yahoo_trace.txt &
p2=$!

echo '2/21 Getting System Info'
cat /etc/issue	>	$outdir/6.1.a.systeminfo.txt
echo "Host Name: $(hostname)" >> $outdir/6.1.a.systeminfo.txt
echo "Date Executed: $(date)" >> $outdir/6.1.a.systeminfo.txt
echo "OS Version: $(uname -a)"	>>	$outdir/6.1.a.systeminfo.txt
lspci	>>	$outdir/6.1.a.systeminfo.txt

echo '3/21 Getting Network Adapter Config'
ifconfig -a	>	$outdir/1.2.1.a.ifconfig.txt

echo '4/21 Querying Local User Information'
cat /etc/passwd	>	$outdir/7.1.localusers.txt
cat /etc/shadow	>>	$outdir/7.1.localusers.txt
lastlog	>	$outdir/7.2.2.localuserlastlogin.txt

echo '5/21 Querying SNMP Config'
egrep -v -e '#|^$' /etc/cups/snmpd.conf	>	$outdir/2.2.2.snmp_strings.txt
ulimit -c	>	$outdir/7.1.core_dump.txt

echo '6/21 Getting Kernel Configuration'
sysctl -A	>	$outdir/1.2.1.a.systemconfig.txt

echo '7/21 Getting Package Information'
dpkg --list	>	$outdir/6.1.a.installed_packages.txt

echo '8/21 Listing Running Processes'
ps -ef	>	$outdir/2.2.1.running_processes.txt

echo '9/21 Listing Running Services'
initctl list | egrep running | awk -F" " '{print $1}' | sort	>	$outdir/2.2.2.running_services.txt

echo '10/21 Listing Startup Commands'
for f in /etc/rc$CURRUNLEVEL.d/*; do echo $f; done | egrep -v "README" | cut -b 11- | sort	>	$outdir/2.2.2.startup_list.txt

echo '11/21 Listing Remote Connection Configuration'
egrep -v -e '#' -e '^$' /etc/rc.local	>	$outdir/7.1.rc_config.txt

echo '12/21 Listing User Crontabs'
for user in $(cut -f 1 -d ':' /etc/passwd); do crontab -u $user -l; done	>	$outdir/2.2.1.user_cron.txt

echo '13/21 Listing Active Ports'
netstat -a | egrep -e 'LISTEN'	>	$outdir/2.2.2.netstat.txt

echo '14/21 Listing Installed Patches'
tail /var/log/dpkg.log -n 2000	>	$outdir/6.1.a.patches.txt

echo '15/21 Listing Package Repositories'
egrep -v -e '#|^$' /etc/apt/sources.list	>	$outdir/6.1.a.repositories.txt

echo '16/21 Listing Sudoers'
egrep -v -e '#|^$' /etc/sudoers	>	$outdir/7.2.2.local_admins.txt

echo '17/21 Getting SSH Configuration'
egrep -v -e '#|^$' /etc/ssh/sshd_config	>	$outdir/2.2.2.ssh_settings.txt

echo '18/21 Getting User Security Settings'
egrep -v -e '#|^$' /etc/pam.d/common-password	>	$outdir/8.5.9.user_sec.txt

echo '19/21 Querying Console Timeout'
echo $TMOUT	>	$outdir/2.2.2.console_timeout.txt

echo '20/21 Querying NTP Settings'
egrep -v -e '#|^$' /etc/ntp.conf	>	$outdir/10.4.1.a.ntp_settings.txt
ntpq -p localhost	>	$outdir/10.4.1.a.ntp_server.txt
service ntpd status	>>	$outdir/10.4.1.a.ntp_server.txt
egrep -v -e '#' -e '^$' /etc/cron.daily/ntp	>>	$outdir/10.4.1.a.ntp_settings.txt

echo '21/21 Getting System Log Settings'
egrep -v -e '#|^$' /etc/rsyslog.conf	>	$outdir/10.2.1.syslog_settings.txt

} 2>/dev/null

echo 'Please wait a moment for all commands to finish.'

wait

echo "Collection Complete. Output files located in $outdir"
exit

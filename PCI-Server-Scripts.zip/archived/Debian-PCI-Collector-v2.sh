#!/bin/bash
#
# Copyright (c) 2025. All rights reserved.
# 
# This script is intended for collecting system information for PCI audits on Debian Linux.
# 
# Version: 1.0
# 
# This script is provided "as-is" without any warranties, express or implied, including
# but not limited to the warranties of merchantability or fitness for a particular purpose.
#
# Usage is subject to the terms and conditions set forth by Aprio.
#
# UPDATES:
# ~~~~~~~~
# 1) Added the following functions that are important for reuirements 10 and 11:
#        - collect_system_logs
#        - collect_audit_logs
#        - collect_iptables_rules
# 2) Added distribution detection for Debian, RedHat, and CentOS.
# 3) Added log functionality to output messages to $output_dir/00_Console_Output.txt with timestamps.
#

# Default values
verbose=false
output_dir="./$(hostname)"

# Function to display usage
usage() {
    echo "Usage: $0 [-d <output_dir>] [-v] [-h]"
    echo "  -d <output_dir>    Specify the output directory (default: $output_dir"
    echo "  -v                 Enable verbose mode"
    echo "  -h                 Show this help message"
    exit 1
}

# Check if no arguments are passed
if [ $# -eq 0 ]; then
    usage
fi

# Parse command line arguments
while getopts ":d:vh" opt; do
    case $opt in
        d)
            output_dir=$OPTARG
            ;;
        v)
            verbose=true
            ;;
        h)
            usage
            ;;
        \?)
            echo "Invalid option: -$OPTARG" >&2
            usage
            ;;
        :)
            echo "Option -$OPTARG requires an argument." >&2
            usage
            ;;
    esac
done

# Check if the script is being run as root
if [ "$(id -u)" -ne 0 ]; then
    echo 'ERROR: You need to be root to run this script. (exiting)'
    exit 1
fi

# Create the output directory, removing it if it already exists
if [ -d "$output_dir" ]; then
    echo "Directory $output_dir already exists. Removing it."
    rm -rf "$output_dir"
fi

echo "Creating Directory $output_dir ..."
mkdir -p "$output_dir"

# Log function for verbosity
log() {
    if [ "$verbose" = true ]; then
        echo "$1"
    fi
}

# Function to check if a command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Perform internet connection tests (traceroutes)
perform_traceroutes() {
    log '1/24: Performing Internet Connection Tests'

	if command_exists "traceroute"; then
		traceroute www.google.com > "$output_dir/1.2.1.a.google_trace.txt" &
		p1=$!
		traceroute www.yahoo.com > "$output_dir/1.2.1.a.yahoo_trace.txt" &
		p2=$!

		wait $p1 $p2
	else
        echo "    *** ERROR: traceroute command not found. Skipping Internet Connection Tests."
    fi
}

# Collect system information
collect_system_info() {
    log '2/24: Getting System Info'

	if command_exists "lspci"; then
		{
			cat /etc/issue
			echo "Host Name: $(hostname)"
			echo "Date Executed: $(date)"
			echo "OS Version: $(uname -a)"
			lspci
		} > "$output_dir/6.1.a.systeminfo.txt"
	else
	    echo "    *** ERROR: lspci command not found. Skipping PCI devices list."
    fi
}

# Collect network adapter information
collect_network_info() {
    log '3/24: Getting Network Adapter Config'

    if command_exists "ifconfig"; then
        ifconfig -a > "$output_dir/1.2.1.a.ifconfig.txt"
    else
        echo "    *** ERROR: ifconfig command not found. Skipping Network Adapter Info."
    fi
}

# Collect local user information
collect_local_users() {
    log '4/24: Querying Local User Information'

    if command_exists "lastlog"; then
        {
            cat /etc/passwd
            cat /etc/shadow
            lastlog
        } > "$output_dir/7.1.localusers.txt"
    else
        echo "    *** ERROR: lastlog command not found. Skipping Local User Info."
    fi
}

# Collect SNMP configuration
collect_snmp_config() {
    log '5/24: Querying SNMP Config'

    if command_exists "egrep"; then
        egrep -v -e '#|^$' /etc/cups/snmpd.conf > "$output_dir/2.2.2.snmp_strings.txt"
        ulimit -c > "$output_dir/7.1.core_dump.txt"
    else
        echo "    *** ERROR: egrep command not found. Skipping SNMP Config."
    fi
}

# Collect kernel configuration
collect_kernel_config() {
    log '6/24: Getting Kernel Configuration'

    if command_exists "sysctl"; then
        sysctl -A > "$output_dir/1.2.1.a.systemconfig.txt"
    else
        echo "    *** ERROR: sysctl command not found. Skipping Kernel Config."
    fi
}

# Collect package information
collect_package_info() {
    log '7/24: Getting Package Information'

    if command_exists "dpkg"; then
        dpkg --list > "$output_dir/6.1.a.installed_packages.txt"
    else
        echo "    *** ERROR: dpkg command not found. Skipping Installed Packages Info."
    fi
}

# Collect running processes
collect_running_processes() {
    log '8/24: Listing Running Processes'

    if command_exists "ps"; then
        ps -ef > "$output_dir/2.2.1.running_processes.txt"
    else
        echo "    *** ERROR: ps command not found. Skipping Running Processes."
    fi
}

# Collect running services
collect_running_services() {
    log '9/24: Listing Running Services'

    if command_exists "initctl"; then
        initctl list | egrep running | awk -F" " '{print $1}' | sort > "$output_dir/2.2.2.running_services.txt"
    else
        echo "    *** ERROR: initctl command not found. Skipping Running Services."
    fi
}

# Collect startup commands
collect_startup_commands() {
    log '10/24: Listing Startup Commands'

    if command_exists "egrep"; then
        for f in /etc/rc$CURRUNLEVEL.d/*; do
            echo "$f"
        done | egrep -v "README" | cut -b 11- | sort > "$output_dir/2.2.2.startup_list.txt"
    else
        echo "    *** ERROR: egrep command not found. Skipping Startup Commands."
    fi
}

# Collect remote connection configuration
collect_remote_connection_config() {
    log '11/24: Listing Remote Connection Configuration'

    if command_exists "egrep"; then
        egrep -v -e '#' -e '^$' /etc/rc.local > "$output_dir/7.1.rc_config.txt"
    else
        echo "    *** ERROR: egrep command not found. Skipping Remote Connection Config."
    fi
}

# Collect user crontab info
collect_user_crontabs() {
    log '12/24: Listing User Crontabs'

    if command_exists "crontab"; then
        for user in $(cut -f 1 -d ':' /etc/passwd); do
            crontab -u "$user" -l
        done > "$output_dir/2.2.1.user_cron.txt"
    else
        echo "    *** ERROR: crontab command not found. Skipping User Crontabs."
    fi
}

# Collect active ports
collect_active_ports() {
    log '13/24: Listing Active Ports'

    if command_exists "netstat"; then
        netstat -a | egrep -e 'LISTEN' > "$output_dir/2.2.2.netstat.txt"
    else
        echo "    *** ERROR: netstat command not found. Skipping Active Ports."
    fi
}

# Collect installed patches
collect_installed_patches() {
    log '14/24: Listing Installed Patches'

    if command_exists "tail"; then
        tail /var/log/dpkg.log -n 2000 > "$output_dir/6.1.a.patches.txt"
    else
        echo "    *** ERROR: tail command not found. Skipping Installed Patches."
    fi
}

# Collect package repositories
collect_package_repositories() {
    log '15/24: Listing Package Repositories'

    if command_exists "egrep"; then
        egrep -v -e '#|^$' /etc/apt/sources.list > "$output_dir/6.1.a.repositories.txt"
    else
        echo "    *** ERROR: egrep command not found. Skipping Package Repositories."
    fi
}

# Collect sudoers information
collect_sudoers() {
    log '16/24: Listing Sudoers'

    if command_exists "egrep"; then
        egrep -v -e '#|^$' /etc/sudoers > "$output_dir/7.2.2.local_admins.txt"
    else
        echo "    *** ERROR: egrep command not found. Skipping Sudoers Info."
    fi
}

# Collect SSH settings
collect_ssh_settings() {
    log '17/24: Getting SSH Configuration'

    if command_exists "egrep"; then
        egrep -v -e '#|^$' /etc/ssh/sshd_config > "$output_dir/2.2.2.ssh_settings.txt"
    else
        echo "    *** ERROR: egrep command not found. Skipping SSH Settings."
    fi
}

# Collect user security settings
collect_user_security() {
    log '18/24: Getting User Security Settings'

    if command_exists "egrep"; then
        egrep -v -e '#|^$' /etc/pam.d/common-password > "$output_dir/8.5.9.user_sec.txt"
    else
        echo "    *** ERROR: egrep command not found. Skipping User Security Settings."
    fi
}

# Collect console timeout setting
collect_console_timeout() {
    log '19/24: Querying Console Timeout'

    echo "$TMOUT" > "$output_dir/2.2.2.console_timeout.txt"
}

# Collect NTP settings
collect_ntp_settings() {
    log '20/24: Querying NTP Settings'

    if command_exists "egrep"; then
        {
            egrep -v -e '#|^$' /etc/ntp.conf
            ntpq -p localhost
            service ntpd status
            egrep -v -e '#' -e '^$' /etc/cron.daily/ntp
        } > "$output_dir/10.4.1.a.ntp_settings.txt"
    else
        echo "    *** ERROR: egrep command not found. Skipping NTP Settings."
    fi
}

# Collect system log settings
collect_syslog_settings() {
    log '21/24: Getting System Log Settings'

    if command_exists "egrep"; then
        egrep -v -e '#|^$' /etc/rsyslog.conf > "$output_dir/10.2.1.syslog_settings.txt"
    else
        echo "    *** ERROR: egrep command not found. Skipping System Log Settings."
    fi
}

# NEW: Collect system logs
collect_system_logs() {
    log '22/24: Collecting System Logs'

    if command_exists "cp"; then
        cp /var/log/auth.log "$output_dir/10.2.1.auth_log.txt"   # Authentication logs
        cp /var/log/syslog "$output_dir/10.2.2.syslog.txt"       # General system logs
        dmesg > "$output_dir/10.2.3.dmesg_log.txt"               # Kernel logs for hardware and system initialization
    else
        echo "    *** ERROR: cp command not found. Skipping System Logs."
    fi
}

# NEW: Collect audit logs
collect_audit_logs() {
    log '23/24: Collecting Audit Logs'

    if command_exists "ausearch"; then
        # Collect audit logs related to file access control and user commands
        ausearch -m avc -ts recent > "$output_dir/10.2.4.audit_avc.txt"
        ausearch -m user_cmd -ts recent > "$output_dir/10.2.5.audit_user_cmd.txt"
    else
        echo "Audit logs not available. (auditd not installed)" > "$output_dir/10.2.4.audit_log.txt"
    fi
}

# NEW: Collect iptables rules
collect_iptables_rules() {
    log '24/24: Collecting iptables rules'

    if command_exists "iptables"; then
        iptables -L -v -n > "$output_dir/10.2.6.iptables_rules.txt"  # Collect firewall rules for review and compliance
    else
        echo "    *** ERROR: iptables command not found. Skipping iptables rules."
    fi
}

# Main collection
{
    perform_traceroutes
    collect_system_info
    collect_network_info
    collect_local_users
    collect_snmp_config
    collect_kernel_config
    collect_package_info
    collect_running_processes
    collect_running_services
    collect_startup_commands
    collect_remote_connection_config
    collect_user_crontabs
    collect_active_ports
    collect_installed_patches
    collect_package_repositories
    collect_sudoers
    collect_ssh_settings
    collect_user_security
    collect_console_timeout
    collect_ntp_settings
    collect_syslog_settings
    collect_system_logs
    collect_audit_logs
    collect_iptables_rules
} 2>/dev/null

echo -e "\nPlease wait a moment for all commands to finish.\n"

wait

echo ""
echo "Collection Complete. Output files located in $output_dir"
echo ""

exit 0

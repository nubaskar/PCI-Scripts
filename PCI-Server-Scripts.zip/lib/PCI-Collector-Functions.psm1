# Function to log information to output and file
function Write-OutputToFile {
    param (
        [Parameter(Mandatory=$true)]
        [string]$message,

        [string]$outputFile = "",

        [string]$CombinedOutputFile = "",

        [bool]$addToConsole = $false,

        [bool]$addToFile = $false,

        [bool]$startWithNewLine = $false
    )

    # If startWithNewLine is true, prepend a newline before the message
    if ($startWithNewLine) {
        $message = "`n" + $message
    }

    
    # If addToConsole is true, display the message on the console
    if ($addToConsole) {
        Write-Output $message
    }

    # If addToFile is true, append the message to the specified output file
    if ($addToFile) {
        if (-not (Test-Path $outputFile)) {
            Write-Warning "Output file '$outputFile' does not exist. It will be created."
        }
        try {
            Add-Content $outputFile -Value $message
        }
        catch {
            Write-Error "Error writing to file '$outputFile': $_"
        }
    }

    # Optionally combine output with CombinedOutputFile if specified
    if ($CombinedOutputFile) {
        try {
            Add-Content $CombinedOutputFile -Value $message
        }
        catch {
            Write-Error "Error writing to combined output file '$CombinedOutputFile': $_"
        }
    }
}

# Get Windows Version
function Get-WindowsVersion {
    # Retrieve the Windows version from the registry
    $versionKey = "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion"

    try {
        # Get the version information from the registry
        $version = (Get-ItemProperty -Path $versionKey -Name CurrentVersion).CurrentVersion
        return $version
    }
    catch {
        Write-Error "Unable to retrieve Windows version. Ensure you have proper permissions."
        return $null
    }    
}

# Initialize Combined Output File: 00_AllOutputs.txt
function InitializeCombinedOutputFile {
    param (
        [string]$CombinedOutputFile
    )

    # Get date
    $date = Get-Date

    $message = @"
This document contains all of the outputs of this script.
*** Ran on $env:COMPUTERNAME on $date ***

"@
        
    Write-OutputToFile -message $message `
                        -CombinedOutputFile $CombinedOutputFile
        
}

# Get System Information
function Get-SystemInfo {
    param (
        [string]$outputFile,  # Parameter for the output file name
        [string]$CombinedOutputFile # Parameter for the combined output file
    )

    # Get date
    $date = Get-Date

    # Display and write to outputFile
    $message = @"
Getting systeminfo...
*** Applicable PCI DSS Requirements: Executive Summary ***

"@

    # Output $message
    Write-Output $message

    # Output $message
    $message += @"

*** Output of the command: systeminfo ***
*** Ran on $env:COMPUTERNAME on $date ***
$(systeminfo)

"@

    Write-OutputToFile -message $message `
                        -outputFile $outputFile `
                        -addToFile $true `
                        -startWithNewLine $true `
                        -CombinedOutputFile $CombinedOutputFile

}

# Get IP address information
function Get-IPAddressInfo {
    param (
        [string]$outputFile,  # Parameter for the output file name
        [string]$CombinedOutputFile # Parameter for the combined output file
    )

    # Get date
    $date = Get-Date

    # Display and write to outputFile
    $message = @"
Getting IP address information...

"@

    # Output $message
    Write-Output $message

    # Write output to the outputFile
    $message += @"

*** Output of command: ipconfig ***
*** Ran on $env:COMPUTERNAME on $date ***
$(ipconfig)

"@

    Write-OutputToFile -message $message `
                        -outputFile $outputFile `
                        -addToFile $true `
                        -startWithNewLine $true `
                        -CombinedOutputFile $CombinedOutputFile

}

# Get Local User information
function Get-LocalUserInfo {
    param (
        [string]$outputFile,  # Parameter for the output file name
        [string]$CombinedOutputFile = ""  # Parameter for the combined output file
    )

    # CSV File
    # Check if the $outputFile has a .txt extension, replace it with .csv
    if ($outputFile.EndsWith(".txt")) {
        $csvFile = $outputFile.Replace('.txt', '.csv')
    } else {
        # Append .csv if the file does not end with .txt
        $csvFile = $outputFile + ".csv"
    }

    # Get date
    $date = Get-Date

    # Display and write to outputFile
    $message = @"
Getting local users...
*** Applicable PCI DSS Requirements: 2.2.3, 7.2.2, 7.2.3, 8.1, 10.4.2.a ***

"@

    # Output $message
    Write-Output $message

    # Check the version of PowerShell and choose the appropriate method
    if ($PSVersionTable.PSVersion.Major -lt 6) {
        # PowerShell 5.x (Windows PowerShell), use Get-WmiObject
        $localUsers = Get-WmiObject -Class Win32_UserAccount -Filter "LocalAccount='True'"
    } else {
        # PowerShell 6+ (PowerShell Core), use Get-CimInstance
        $localUsers = Get-CimInstance -ClassName Win32_UserAccount -Filter "LocalAccount='True'"
    }

    # Create local users CSV file
    $localUsers | ConvertTo-Csv | Out-File $csvFile -Encoding ascii

    # Write output to the outputFile
    $message += @"

*** Output of command: Get-WmiObject -Class Win32_UserAccount -Filter LocalAccount='True'***
*** Ran on $env:COMPUTERNAME on $date ***
$localUsers

*** Full output is in csv (comma separated value) format in $csvFile

"@

    Write-OutputToFile -message $message `
                        -outputFile $outputFile `
                        -addToFile $true `
                        -startWithNewLine $true `
                        -CombinedOutputFile $CombinedOutputFile

}

# Get SNMP Community String
function Get-SNMPCommunityString {
    param (
        [string]$outputFile,  # Parameter for the output file name
        [string]$CombinedOutputFile = ""  # Parameter for the combined output file
    )

    # Get date
    $date = Get-Date

    # Display and write to outputFile
    $message = @"
Getting SNMP community strings (if exists)...
*** Applicable PCI DSS Requirements: 2.1 ***

"@

    # Output $message
    Write-Output $message

    # Write output to the outputFile
    $message += @"

***Output of command: Get-Item -Path Registry::HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\SNMP\Parameters\ValidCommunities -ErrorAction Ignore ***
*** Ran on $env:COMPUTERNAME on $date ***
$(Get-Item -Path Registry::HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\SNMP\Parameters\ValidCommunities -ErrorAction Ignore)

"@

    Write-OutputToFile -message $message `
                        -outputFile $outputFile `
                        -addToFile $true `
                        -startWithNewLine $true `
                        -CombinedOutputFile $CombinedOutputFile

}

# Get Security Policies (Local)
function Get-SecurityPolicies-Local {
    param (
        [string]$outputFile,  # Parameter for the output file name
        [string]$CombinedOutputFile  # Parameter for the combined output file
    )

    # Get date
    $date = Get-Date

    # Export security policies and user rights configuration to a temporary file
    $tmpFilePath = "$env:TEMP\tmp_securitypolicies-local.txt"
    secedit /export /cfg $tmpFilePath /areas SECURITYPOLICY, USER_RIGHTS

    # Check if the temporary file exists before trying to remove it
    if (Test-Path -Path $tmpFilePath) {
        # Read the exported content directly into a variable
        $securityPolicies = Get-Content $tmpFilePath

        # Clean up the temporary file
        Remove-Item -Path $tmpFilePath -Force
    }
    else {
        Write-Warning "Temporary security policies file not found: $tmpFilePath"
        $securityPolicies = "Failed to retrieve security policies. File not found."
    }

    # Display and write to outputFile
    $message = @"
Getting security policies (local)...
*** Applicable PCI DSS Requirements: 2.2.3, 8.1.1 - 8.1.7, 10.1, 10.2.1 - 10.2.7, 10,4.2.b, 10.4.3 ***

"@

    # Output $message
    Write-Output $message

    # Write output to the outputFile
    $message += @"

*** Output of command: secedit /export /cfg "$env:TEMP\tmp_securitypolicies-local.txt" /areas SECURITYPOLICY, USER_RIGHTS ***
*** Ran on $env:COMPUTERNAME on $date ***
$securityPolicies

"@

    Write-OutputToFile -message $message `
                        -outputFile $outputFile `
                        -addToFile $true `
                        -startWithNewLine $true `
                        -CombinedOutputFile $CombinedOutputFile

}

# Get Security Policies (Domain)
function Get-SecurityPolicies-Domain {
    param (
        [string]$outputFile,  # Parameter for the output file name
        [string]$CombinedOutputFile  # Parameter for the combined output file
    )

    # Get date
    $date = Get-Date

    # Export security policies and user rights configuration to a temporary file
    $tmpFilePath = "$env:TEMP\tmp_securitypolicies-domain.txt"
    secedit /export /mergedpolicy /cfg $tmpFilePath /areas SECURITYPOLICY, USER_RIGHTS

    # Check if the temporary file exists before trying to remove it
    if (Test-Path -Path $tmpFilePath) {
        # Read the exported content directly into a variable
        $securityPolicies = Get-Content $tmpFilePath

        # Clean up the temporary file
        Remove-Item -Path $tmpFilePath -Force
    }
    else {
        Write-Warning "Temporary security policies file not found: $tmpFilePath"
        $securityPolicies = "Failed to retrieve security policies. File not found."
    }
    
    # Display and write to outputFile
    $message = @"
Getting security policies (domain)...
*** Applicable PCI DSS Requirements: 2.2.3, 8.1.1 - 8.1.7, 10.1, 10.2.1 - 10.2.7, 10,4.2.b, 10.4.3 ***

"@

    # Output $message
    Write-Output $message

    # Write output to the outputFile
    $message += @"

*** Output of command: secedit /export /mergedpolicy /cfg "$env:TEMP\tmp_securitypolicies-domain.txt" /areas SECURITYPOLICY, USER_RIGHTS ***
*** Ran on $env:COMPUTERNAME on $date ***
$securityPolicies

"@

    Write-OutputToFile -message $message `
                        -outputFile $outputFile `
                        -addToFile $true `
                        -startWithNewLine $true `
                        -CombinedOutputFile $CombinedOutputFile

}

# Get Group Policy Result
function Get-GroupPolicyResult {
    param (
        [string]$outputFile,  # Parameter for the output file name
        [string]$CombinedOutputFile  # Parameter for the combined output file
    )

    # Get date
    $date = Get-Date

    # Check if gpresult is available on the system
    if (Get-Command gpresult -ErrorAction SilentlyContinue) {

        # Group Policy result
        $groupPolicyResult = gpresult /SCOPE COMPUTER /v | Out-String

        # Check if the $outputFile has a .txt extension, replace it with .html
        if ($outputFile.EndsWith(".txt")) {
            $htmlFile = $outputFile.Replace('.txt', '.html')
        } else {
            # Append .html if the file does not end with .txt
            $htmlFile = $outputFile + ".html"
        }

        $groupPolicyResult | ConvertTo-Html | Out-File $htmlFile

        # Display and write to outputFile
        $message = @"
Getting group policy results...
*** Applicable PCI DSS Requirements: 2.2.3, 8.1.1 - 8.1.7, 10.1, 10.2.1 - 10.2.7, 10,4.2.b, 10.4.3 ***

"@

        # Output $message
        Write-Output $message

        # Write output to the outputFile
        $message += @"

*** Output of the command: gpresult /SCOPE COMPUTER /v ***
*** Ran on $env:COMPUTERNAME on $date ***
$groupPolicyResult

*** Full output is in html format in $htmlFile

"@

        Write-OutputToFile -message $message `
                            -outputFile $outputFile `
                            -addToFile $true `
                            -startWithNewLine $true `
                            -CombinedOutputFile $CombinedOutputFile
    }
    else {
        Write-Warning "gpresult command is not available on this system."
    }

}

# Get Audit Policy
function Get-AuditPolicy {
    param (
        [string]$outputFile,  # Parameter for the output file name
        [string]$CombinedOutputFile = ""  # Parameter for the combined output file
    )

    # Get date
    $date = Get-Date

    # Check if Auditpol command is available
    if (Get-Command Auditpol -ErrorAction SilentlyContinue) {
        try {
            # Run the Auditpol commands
            $AuditpolListUser = (Auditpol /list /user /v) | Out-String
            $AuditpolGetCategoryDetailedTracking = (Auditpol /get /category:"Detailed Tracking" /r) | Out-String
            $AuditpolGetCategoryAll = (Auditpol /get /category:*) | Out-String

            # Display and write to outputFile
            $message = @"
Getting audit policy if it exists...

"@

            # Output message to console
            Write-Output $message

            # Write output to the outputFile
            $message += @"

*** Output of the commands: Auditpol /list /user /v, Auditpol /get /category:'Detailed Tracking' /r ***
*** Ran on $env:COMPUTERNAME on $date ***
$AuditpolListUser
$AuditpolGetCategoryDetailedTracking
$AuditpolGetCategoryAll

"@

            Write-OutputToFile -message $message `
                                -outputFile $outputFile `
                                -addToFile $true `
                                -startWithNewLine $true `
                                -CombinedOutputFile $CombinedOutputFile

        }
        catch {
            Write-Error "Failed to retrieve audit policy: $_"
        }
    } 
    else {
        Write-Warning "Auditpol command is not available on this system."
    }
}

#-----------------------------------------------------------------------------------------------
# Specific OS handling functions
#-----------------------------------------------------------------------------------------------
# Helper Function to Get OS Name
function Get-OSName {
    # Check the version of PowerShell and choose the appropriate method
    if ($PSVersionTable.PSVersion.Major -lt 6) {
        # PowerShell 5.x (Windows PowerShell), use Get-WmiObject
        $os = (Get-WmiObject -Class Win32_OperatingSystem).Caption
    } else {
        # PowerShell 6+ (PowerShell Core), use Get-CimInstance
        $os = (Get-CimInstance -ClassName Win32_OperatingSystem).Caption
    }

    return $os
}

# Get OS Type
function Get-OSType {
    $osName = Get-OSName
    if ($osName -match "Server") {
        return "Server"
    } elseif ($osName -match "Windows") {
        return "Client"
    } else {
        return "Unknown"
    }
}

# Display OS Name Function
function Get-OSNameInfo {
    $OSname = Get-OSName
    Write-Output "This is a $OSname machine."
}

# Getting Windows Features: 31_WindowsFeatures.txt
function Get-WindowsFeature {
    param (
        [string]$outputFile,  # Parameter for the output file name
        [string]$CombinedOutputFile # Parameter for the combined output file
    )

    # Get OS type: Server or Client
    $osType = Get-OSType

    # Get date
    $date = Get-Date

    # Initialize message variable for the output
    $message = @"
Collecting PCI compliance evidence...

"@

    # Display and write to outputFile
    Write-Output $message

    # Conditionally import the ServerManager module for Windows Server
    if ($osType -eq "Server") {
        # Import ServerManager module for Windows Server versions
        Import-Module ServerManager -ErrorAction SilentlyContinue

        # Add information about server module
        $message += @"
This is a Windows Server machine.
Attempting to collect installed roles and features...

"@

        # Output $message and write to the outputFile
        Write-Output $message

        # Check if the ServerManager module is available
        $message += @"
*** Installed Server Features ***
*** Ran on $env:COMPUTERNAME on $date ***

"@
        
        if (Get-Module -Name ServerManager) {
            # Get installed features for Server editions
            $features = Get-WindowsFeature

            $message += @"

$($features | Select-Object -ExpandProperty Name)

"@
        } else {
            Write-Error "ServerManager module is not available. Cannot get server features."

            $message += @"

ERROR: ServerManager module is not available. Cannot get server features.

"@
            
        }

        Write-OutputToFile -message $message `
                    -outputFile $outputFile `
                    -addToFile $true `
                    -startWithNewLine $true `
                    -CombinedOutputFile $CombinedOutputFile

    } else {
        # For Client editions, collect other types of evidence
        $message += @"
*** Ran on $env:COMPUTERNAME on $date ***
This is a Windows Client edition. Skipping server-specific feature collection.

"@
        
        Write-Output $message

        # Write to the outputFile for Client editions
        Write-OutputToFile -message $message `
                            -outputFile $outputFile `
                            -addToFile $true `
                            -startWithNewLine $true `
                            -CombinedOutputFile $CombinedOutputFile
    }
}

# Function to check if the ActiveDirectory module is available and load it
function Import-ADModule {
    # Get the OS type: Server or Client
    $osType = Get-OSType

    # Check if the ActiveDirectory module is available
    $adModuleLoaded = Get-Module -ListAvailable -Name ActiveDirectory

    if ($osType -eq "Server") {
        # Windows Server: Active Directory module is expected to be available
        if (-not $adModuleLoaded) {
            Write-Warning "Active Directory module is not installed on the server."
            return $false
        }

        Import-Module ActiveDirectory
        Write-Output "Active Directory module loaded from the server."
        return $true
    }
    elseif ($osType -eq "Client") {
        # Windows Client: Check if RSAT is installed
        
        try {
            $rsatFeature = Get-WindowsOptionalFeature -Online | Where-Object {$_.FeatureName -eq "RSAT-AD-PowerShell"}

            if ($rsatFeature.State -eq "Disabled") {
                Write-Warning "RSAT (Active Directory module) is not installed or is disabled on this desktop machine."
                return $false
            }

            Import-Module ActiveDirectory
            Write-Output "Active Directory module loaded from RSAT."
            return $true
        }
        catch {
            Write-Warning "An error occurred while checking for RSAT installation: $_"
            return $false
        }
    }
    else {
        Write-Error "Unsupported operating system version."
        return $false
    }
}

function WindowsXP {
    # Display OS Name
    Get-OSNameInfo
}

function Windows2003 {
    param (
        [string]$outputFile,  # Parameter for the output file name
        [string]$timeStateStatusFile,  # Parameter for Time Sync
        [string]$CombinedOutputFile = ""    # Parameter for the combined output file
    )

    # Get date
    $date = Get-Date

    # Display OS Name
    Get-OSNameInfo
    
    # Header
    $message = @"
Getting installed Windows components...
*** Applicable PCI DSS Requirements: 2.2.1, 2.2.2, 2.2.3 ***

"@
    Write-OutputToFile -message $message `
                        -outputFile $outputFile `
                        -addToConsole $true `
                        -addToFile $true `
                        -startWithNewLine $true `
                        -CombinedOutputFile $CombinedOutputFile

    # Execute registry queries with try-catch for error handling
    try {
        $runQuery1 = reg query "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Setup\Oc Manager\Subcomponents" 2>&1

        if ($?) {
            Write-Output "Registry query 1 executed successfully."
        } else {
            throw "Registry query 1 failed."
        }

        $runQuery2 = reg query "HKLM\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Setup\Oc Manager\Subcomponents" 2>&1
        if ($?) {
            Write-Output "Registry query 2 executed successfully."
        } else {
            throw "Registry query 2 failed."
        }
    }
    catch {
        Write-Error "An error occurred during registry queries: $_"
    }

    # reg query
    $message = @"
*** Output of the command:  reg query 'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Setup\Oc Manager\Subcomponents' ***
*** Ran on $env:COMPUTERNAME on $date ***
$runQuery1

*** Output of the command:  reg query 'HKLM\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Setup\Oc Manager\Subcomponents' ***
*** Ran on $env:COMPUTERNAME on $date ***"
$runQuery2

"@
                            
        Write-OutputToFile -message $message `
                            -outputFile $outputFile `
                            -addToFile $true `
                            -CombinedOutputFile $CombinedOutputFile
    
    # w32tm /monitor 2>&1
    Write-Output "Getting time sync status..."

    try {
        # Execute the w32tm monitor command
        $w32tmMonitor = w32tm /monitor 2>&1

        # Check if the command was successful by using the $? automatic variable
        if (-not $?) {
            throw "w32tm command failed. Error: $w32tmMonitor"
        }

        # If the command succeeds, you can optionally output the result
        Write-Output "w32tm monitor command executed successfully."
    }
    catch {
        # Catch any errors that occur and display them
        Write-Error "An error occurred while executing the w32tm monitor command: $_"
    }

    $message = @"
Getting time sync status...
*** Output of the command: w32tm /monitor ***
$w32tmMonitor

"@
    Write-OutputToFile -message $message `
                        -outputFile $timeStateStatusFile `
                        -addToFile $true `
                        -CombinedOutputFile $CombinedOutputFile
}

function WindowsVistaOr2008 {
    param (
        [string]$outputFile,  # Parameter for the output file name
        [string]$timeStateStatusFile,  # Parameter for Time Sync
        [string]$CombinedOutputFile = ""  # Parameter for the combined output file
    )

    # Get date
    $date = Get-Date

    # Display OS Name
    Get-OSNameInfo

    # Header
    $message = @"
Getting installed programs with wmic (this will take between 2 and 5 minutes, only for Win2K8 or WinVista)...
*** Applicable PCI DSS Requirements: 2.2.1, 2.2.2, 2.2.3, 2.2.4, 5.1 ***

"@

    Write-OutputToFile -message $message `
                        -outputFile $outputFile `
                        -addToConsole $true `
                        -addToFile $true `
                        -startWithNewLine $true `
                        -CombinedOutputFile $CombinedOutputFile

    # Handle deprecation of WMIC
    Write-Warning "The 'wmic' command is deprecated and will be removed in future Windows versions, so using Get-WmiObject or Get-CimInstance cmdlets."

    try {
        # Use Get-WmiObject for older versions of PowerShell or Get-CimInstance for newer versions
        if ($PSVersionTable.PSVersion.Major -lt 6) {
            # PowerShell 5.x (Windows PowerShell), use Get-WmiObject
            $installedPrograms = Get-WmiObject -Class Win32_Product | Select-Object Name, Version, Vendor, InstallDate, InstallLocation
        } else {
            # PowerShell 6+ (PowerShell Core), use Get-CimInstance
            $installedPrograms = Get-CimInstance -ClassName Win32_Product | Select-Object Name, Version, Vendor, InstallDate, InstallLocation
        }
    
        # Check if the command was successful
        if ($null -eq $installedPrograms) {
            throw "Failed to retrieve installed programs."
        }
    
        # If the command succeeds, prepare the message
        $message = @"
*** Output of the command: Get-CimInstance/ Get-WmiObject product details ***
*** Ran on $env:COMPUTERNAME on $date ***

$installedPrograms

"@
        
    Write-OutputToFile -message $message `
                        -outputFile $outputFile `
                        -addToFile $true `
                        -startWithNewLine $true `
                        -CombinedOutputFile $CombinedOutputFile
    }
    catch {
        # Catch any errors that occur and display them
        Write-Error "An error occurred while retrieving installed programs: $_"
    }                    

    try {
        # Output message indicating that time sync status is being retrieved
        Write-Output "Getting time sync status.."  
    
        # Execute the w32tm query command and capture the output
        $w32tmMonitor = w32tm /query /status /verbose 2>&1
    
        # Check if the command was successful
        if ($null -eq $w32tmMonitor) {
            throw "w32tm command failed. No output received."
        }
    
        # Prepare the message with the output
        $message = @"
Getting time sync status..
*** Output of command: w32tm /query /status /verbose 2>&1 ***
*** Ran on $env:COMPUTERNAME on $date ***
$w32tmMonitor

"@
    
        # Write the output to the file
        Write-OutputToFile -message $message `
                            -outputFile $timeStateStatusFile `
                            -addToFile $true `
                            -startWithNewLine $true `
                            -CombinedOutputFile $CombinedOutputFile
    }
    catch {
        # Catch any errors that occur and output them
        Write-Error "An error occurred while retrieving the time sync status: $_"
    }
}

function Windows7Or2008R2 {
    param (
        [string]$outputFile,  # Parameter for the output file name
        [string]$timeStateStatusFile,  # Parameter for Time Sync
        [string]$CombinedOutputFile = ""  # Parameter for the combined output file
    )

    # Get date
    $date = Get-Date

    # Display OS Name
    Get-OSNameInfo

    # Header
    $message = @"
Getting installed Windows Components...
*** Applicable PCI DSS Requirements: 2.2.1, 2.2.2, 2.2.3 ***

"@
    
    Write-OutputToFile -message $message `
                        -outputFile $outputFile `
                        -addToConsole $true `
                        -addToFile $true `
                        -startWithNewLine $true `
                        -CombinedOutputFile $CombinedOutputFile
    
    # Execute the dism command to get features
    try {
        $dismOnline = dism /online /get-features 2>&1
    
        # Check if the command was successful by checking for errors in the output
        if ($dismOnline -match "error" -or $null -eq $dismOnline) {
            throw "dism command failed. Error: $dismOnline"
        } else {
            # If the command succeeded, output the result
            Write-Output $dismOnline
        }
    
        # Prepare the message with the output
        $message = @"
*** Output of command: dism /online /get-features ***
*** Ran on $env:COMPUTERNAME on $date ***
$dismOnline

"@
    
        # Write the output to the file
        Write-OutputToFile -message $message `
                            -outputFile $outputFile `
                            -addToFile $true `
                            -startWithNewLine $true `
                            -CombinedOutputFile $CombinedOutputFile
    }
    catch {
        # Catch any errors that occur and output them
        Write-Error "An error occurred while executing the dism command: $_"
    }

    # Getting installed Server Features using Get-CimInstance (or Get-WmiObject for older systems)
    try {
        # Getting installed Server Features using Get-CimInstance (or Get-WmiObject for older systems)
        Write-Output "Getting installed Server Features..."
    
        # Handle deprecation of WMIC
        Write-Warning "The 'wmic' command is deprecated and will be removed in future Windows versions, so using Get-WmiObject or Get-CimInstance cmdlets."

        # Using Get-CimInstance to retrieve the Server Features (this works for newer versions of PowerShell)
        $serverFeatures = Get-CimInstance -ClassName Win32_ServerFeature
    
        # Check if any server features were retrieved
        if ($null -eq $serverFeatures) {
            throw "No server features found or there was an issue retrieving the server features."
        }
    
        # Prepare the message with the output of server features
        $message = @"
Getting installed Server Features...
*** Output of Get-CimInstance for Win32_ServerFeature ***
*** Ran on $env:COMPUTERNAME on $date ***
$($serverFeatures | Out-String)

"@
    
        # Write the output to the file
        Write-OutputToFile -message $message `
                            -outputFile $outputFile `
                            -addToFile $true `
                            -CombinedOutputFile $CombinedOutputFile
    }
    catch {
        # Catch any errors that occur while retrieving server features
        Write-Error "An error occurred while retrieving installed server features: $_"
    }
    
    # Get installed programs using Get-WmiObject or Get-CimInstance, depending on PowerShell version
    try {
        write-output "Getting installed programs (this will take between 2 and 5 minutes, only for Win2K8 or Win7)..."
        Write-Output "*** Applicable PCI DSS Requirements: 5.1 ***"
    
        # Handle deprecation of WMIC
        Write-Warning "The 'wmic' command is deprecated and will be removed in future Windows versions, so using Get-WmiObject or Get-CimInstance cmdlets."

        # Use Get-WmiObject for older versions of PowerShell (Windows PowerShell 5.x)
        # Use Get-CimInstance for PowerShell 6 or newer (PowerShell Core)
        if ($PSVersionTable.PSVersion.Major -ge 6) {
            # PowerShell 6+ (Core), use Get-CimInstance
            $installedPrograms = Get-CimInstance -ClassName Win32_Product
        } else {
            # PowerShell 5.x (Windows PowerShell), use Get-WmiObject
            $installedPrograms = Get-WmiObject -Class Win32_Product
        }
    
        # Check if the installed programs list is empty or null
        if ($null -eq $installedPrograms -or $installedPrograms.Count -eq 0) {
            throw "No installed programs found or there was an issue retrieving installed programs."
        }
    
        # Prepare the message with the output of installed programs
        $message = @"
Getting installed programs...
*** Applicable PCI DSS Requirements: 5.1 ***
*** Output of Get-WmiObject/Get-CimInstance for Win32_Product ***
*** Ran on $env:COMPUTERNAME on $date ***
$($installedPrograms | Out-String)

"@
    
        # Write the output to the file
        Write-OutputToFile -message $message `
                            -outputFile $outputFile `
                            -addToFile $true `
                            -CombinedOutputFile $CombinedOutputFile
    }
    catch {
        # Catch any errors that occur while retrieving installed programs
        Write-Error "An error occurred while retrieving installed programs: $_"
    }
    
    # Execute the w32tm query command and capture the output
    try {
        # Write output message
        write-output "Getting time sync status.."  
    
        # Execute the w32tm query command and capture the output
        $w32tmMonitor = w32tm /query /status /verbose 2>&1
    
        # Check if the w32tm command failed by evaluating the $? automatic variable
        if ($?) {
            # If successful, proceed with creating the message
            $message = @"
Getting time sync status..
*** Output of command: w32tm /query /status /verbose 2>&1 ***
*** Ran on $env:COMPUTERNAME on $date ***
$w32tmMonitor

"@
        } else {
            # If the command failed, create an error message
            throw "w32tm command failed. Error: $w32tmMonitor"
        }
    
        # Write the output message to the file
        Write-OutputToFile -message $message `
                            -outputFile $timeStateStatusFile `
                            -addToFile $true `
                            -startWithNewLine $true `
                            -CombinedOutputFile $CombinedOutputFile
    }
    catch {
        # Catch any errors that occur during the w32tm command execution or file writing
        Write-Error "An error occurred while getting the time sync status: $_"
    }    
}

function Windows8Or2012 {
    # Display OS Name
    Get-OSNameInfo
}

function Windows8Or2012R2 {
    # Display OS Name
    Get-OSNameInfo
}

function Windows10Or2016 {
    # Display OS Name
    Get-OSNameInfo
}
#-----------------------------------------------------------------------------------------------

# Get Installed Programs with wmi
function Get-InstalledProgramsWithWMI {
    param (
        [string]$outputFile,  # Parameter for the output file name
        [string]$CombinedOutputFile = ""  # Parameter for the combined output file
    )

    # CSV File
    $csvFile = $outputFile.Replace('.txt', '.csv')

    # Get date
    $date = Get-Date

    # Display and write to outputFile
    $message = @"
Getting installed programs with wmi...
*** Applicable PCI DSS Requirements: 2.2.1, 2.2.2, 2.2.3, 2.2.4, 5.1 ***

"@

    # Output $message
    Write-Output $message

    # Use Get-CimInstance for newer versions of PowerShell
    $InstalledPrograms = if ($PSVersionTable.PSVersion -ge [Version]"7.0") {
        Get-CimInstance -ClassName Win32_Product
    } else {
        Get-WmiObject -Class win32_product
    }

    # Check if $InstalledPrograms is empty
    if (-not $InstalledPrograms) {
        Write-Error "No installed programs found."
        return
    }

    # Create installed programs CSV file
    $InstalledPrograms | ConvertTo-Csv | Out-File $csvFile -Encoding ascii

    # Write output to the outputFile
    $message += @"

*** Output of the command: Get-WmiObject -Class win32_product ***
*** Ran on $env:COMPUTERNAME on $date ***
$InstalledPrograms

*** Full output is in csv (comma separated value) format in $csvFile

"@

    Write-OutputToFile -message $message `
                        -outputFile $outputFile `
                        -addToFile $true `
                        -startWithNewLine $true `
                        -CombinedOutputFile $CombinedOutputFile

}

# Get Installed Programs from the registry
function Get-InstalledProgramsFromRegistry {
    param (
        [string]$outputFile,  # Parameter for the output file name
        [string]$CombinedOutputFile = ""  # Parameter for the combined output file
    )

    # CSV File
    $csvFile = $outputFile.Replace('.txt', '.csv')

    # Get date
    $date = Get-Date

    # Display and write to outputFile
    $message = @"
Getting installed programs from the registry...
*** Applicable PCI DSS Requirements: 2.2.1, 2.2.2, 2.2.3, 2.2.4, 5.1 ***

"@

    # Output $message
    Write-Output $message

    # Get installed programs
    # Check if the system is 64-bit or 32-bit
    if ([System.Environment]::Is64BitOperatingSystem) {
        # If the system is 64-bit, get both 64-bit and 32-bit applications
        $InstalledPrograms = Get-ChildItem -Path "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall" -Recurse | Where-Object { $_.PSChildName -match "DisplayName" }
        $InstalledPrograms += Get-ChildItem -Path "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall" -Recurse | Where-Object { $_.PSChildName -match "DisplayName" }
    } else {
        # If the system is 32-bit, get only 32-bit applications (same key as 64-bit for 32-bit OS)
        $InstalledPrograms = Get-ChildItem -Path "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall" -Recurse | Where-Object { $_.PSChildName -match "DisplayName" }
    }

    # Create installed programs CSV file
    $InstalledPrograms | ConvertTo-Csv | Out-File $csvFile -Encoding ascii

    # Write output to the outputFile
    $message += @"

*** Output of the command: Get-ChildItem -path Registry::'HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall' -Recurse ***
*** Ran on $env:COMPUTERNAME on $date ***
$InstalledPrograms

*** Full output is in csv (comma separated value) format in $csvFile

"@

    Write-OutputToFile -message $message `
                        -outputFile $outputFile `
                        -addToFile $true `
                        -startWithNewLine $true `
                        -CombinedOutputFile $CombinedOutputFile

}

# Get Running Processes 
function Get-RunningProcesses {
    param (
        [string]$outputFile,  # Parameter for the output file name
        [string]$CombinedOutputFile = ""  # Parameter for the combined output file
    )

    # CSV File
    $csvFile = $outputFile.Replace('.txt', '_AllDetails.csv')

    # Get date
    $date = Get-Date

    # Display and write to outputFile
    $message = @"
Getting running processes ...
*** Applicable PCI DSS Requirements: 2.2.1, 2.2.2, 2.2.3, 2.2.4, 2.3.b, 2.3.c, 5.1 ***

"@

    # Output $message
    Write-Output $message

    # Get installed programs
    $runningProcesses = Get-Process

    if (-not $runningProcesses) {
        Write-Error "No running processes found."
        return
    }

    $runningProcessesSelectedColumns = $runningProcesses | Select-Object Name, Path, CPU, FileVersion, ProductVersion, Description, Product, Id, SessionId | Format-Table | Out-String

    # Create installed programs CSV file
    $runningProcesses | ConvertTo-Csv | Out-File $csvFile -Encoding ascii

    # Write output to the outputFile
    $message += @"

*** Output of the command: Get-ChildItem -path Registry::'HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall' -Recurse ***
*** Ran on $env:COMPUTERNAME on $date ***
$runningProcessesSelectedColumns

*** Full output is in csv (comma separated value) format in $csvFile

"@

    Write-OutputToFile -message $message `
                        -outputFile $outputFile `
                        -addToFile $true `
                        -startWithNewLine $true `
                        -CombinedOutputFile $CombinedOutputFile

}

# Get All services 
function Get-AllServices {
    param (
        [string]$outputFile,  # Parameter for the output file name
        [string]$CombinedOutputFile = ""  # Parameter for the combined output file
    )

    # CSV File
    $csvFile = $outputFile.Replace('.txt', '_AllDetails.csv')

    # Get date
    $date = Get-Date

    # Display and write to outputFile
    $message = @"
Getting services ...
*** Applicable PCI DSS Requirements: 2.2.1, 2.2.2, 2.2.3, 2.3.c, 11.5.a ***

"@

    # Output $message
    Write-Output $message

    # Get installed programs
    $allServices = Get-Service

    if (-not $allServices) {
        Write-Error "No services found."
        return
    }

    $allServicesSelectedColumns = $allServices | Select-Object Name, DisplayName, ServiceName, ServicesDependedOn, Status, ServiceType | Format-Table | Out-String

    # Create installed programs CSV file
    $allServices | ConvertTo-Csv | Out-File $csvFile -Encoding ascii

    # Write output to the outputFile
    $message += @"

*** Output of the command: get-service | format-table -property Name, DisplayName, ServiceName, ServicesDependedOn, Status, ServiceType ***
*** Ran on $env:COMPUTERNAME on $date ***
$allServicesSelectedColumns

*** Full output is in csv (comma separated value) format in $csvFile

"@

    Write-OutputToFile -message $message `
                        -outputFile $outputFile `
                        -addToFile $true `
                        -startWithNewLine $true `
                        -CombinedOutputFile $CombinedOutputFile

}

# Get open ports
function Get-OpenPorts {
    param (
        [string]$outputFile,  # Parameter for the output file name
        [string]$CombinedOutputFile = ""  # Parameter for the combined output file
    )

    # Get date
    $date = Get-Date

    # Display and write to outputFile
    $message = @"
Getting open ports...
*** Applicable PCI DSS Requirements: 2.2.3 ***

"@

    # Output $message
    Write-Output $message

    # Get open ports using netstat
    $openPorts = netstat -ano | findstr "LISTENING"

    if (-not $openPorts) {
        Write-Error "No open ports found."
        return
    }
    
    # Output $message
    $message += @"

*** Output of the command: netstat -ano | findstr 'LISTENING' ***
*** Ran on $env:COMPUTERNAME on $date ***
$openPorts

"@

    Write-OutputToFile -message $message `
                        -outputFile $outputFile `
                        -addToFile $true `
                        -startWithNewLine $true `
                        -CombinedOutputFile $CombinedOutputFile

}

# Get patches
function Get-Patches {
    param (
        [string]$outputFile,  # Parameter for the output file name
        [string]$CombinedOutputFile = ""  # Parameter for the combined output file
    )

    # CSV File
    $csvFile = $outputFile.Replace('.txt', '.csv')

    # Get date
    $date = Get-Date

    # Display and write to outputFile
    $message = @"
Getting installed patches...
*** Applicable PCI DSS Requirements: 2.2.3, 6.2 ***

"@

    # Output $message
    Write-Output $message

    # Get installed programs
    $allPatches = Get-HotFix


    # Create installed programs CSV file
    $allPatches | ConvertTo-Csv | Out-File $csvFile -Encoding ascii

    # Write output to the outputFile
    $message += @"

*** Output of the command: Get-HotFix ***
*** Ran on $env:COMPUTERNAME on $date ***
$allPatches

*** Full output is in csv (comma separated value) format in $csvFile

"@

    Write-OutputToFile -message $message `
                        -outputFile $outputFile `
                        -addToFile $true `
                        -startWithNewLine $true `
                        -CombinedOutputFile $CombinedOutputFile

}

# Get Local Admin Group membership
function Get-LocalAdminGroupMembership {
    param (
        [string]$outputFile,  # Parameter for the output file name
        [string]$CombinedOutputFile = ""  # Parameter for the combined output file
    )

    # Get date
    $date = Get-Date

    # Display and write to outputFile
    $message = @"
Getting Local Admin Group Membership...
*** Applicable PCI DSS Requirements: 2.2.3, 7.2.2, 7.2.3, 8.1, 10.4.2.a ***

"@

    # Output $message
    Write-Output $message

    # Output $message
    $message += @"

*** Output of the command: netstat -ano | findstr 'LISTENING' ***
*** Ran on $env:COMPUTERNAME on $date ***
$(net localgroup Administrators)

"@

    Write-OutputToFile -message $message `
                        -outputFile $outputFile `
                        -addToFile $true `
                        -startWithNewLine $true `
                        -CombinedOutputFile $CombinedOutputFile

}

# Check to see if storing LanMan hashes is enabled
function CheckLanManHashStatus {
    param (
        [string]$outputFile,  # Parameter for the output file name
        [string]$CombinedOutputFile = ""  # Parameter for the combined output file
    )

    # Get date
    $date = Get-Date

    # Display and write to outputFile
    $message = @"
Checking to see if storing LanMan hashes is enabled...
*** Applicable PCI DSS Requirements: 8.4 ***

"@

    # Output of registry check for LanMan hashes
    Write-Output $message

    # Output of the registry key check for LanMan hashes
    $lanmanHashStatus = Get-ItemProperty -Path "Registry::HKLM\SYSTEM\CurrentControlSet\Control\Lsa"
    $message += @"

*** Output of the registry key: HKLM\SYSTEM\CurrentControlSet\Control\Lsa ***
*** Ran on $env:COMPUTERNAME on $date ***
$($lanmanHashStatus)

"@

    Write-OutputToFile -message $message `
                        -outputFile $outputFile `
                        -addToFile $true `
                        -startWithNewLine $true `
                        -CombinedOutputFile $CombinedOutputFile
}

# Get Local RDP Settings
function Get-LocalRDPSettings {
    param (
        [string]$outputFile,  # Parameter for the output file name
        [string]$CombinedOutputFile = ""  # Parameter for the combined output file
    )

    # Get date
    $date = Get-Date

    # Display and write to outputFile
    $message = @"
Getting Local RDP settings (encryption level, timeout, etc)...
*** Applicable PCI DSS Requirements: 2.2.3, 2.3.b, 8.4 ***

"@

    # Output $message
    Write-Output $message

    # Output of local RDP registry settings
    $rdpSettings = Get-Item Registry::"HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp"
    $message += @"

*** Output of the registry key: Get-Item Registry::"HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp" ***
*** Ran on $env:COMPUTERNAME on $date ***
$($rdpSettings)

"@

    Write-OutputToFile -message $message `
                        -outputFile $outputFile `
                        -addToFile $true `
                        -startWithNewLine $true `
                        -CombinedOutputFile $CombinedOutputFile
}

# Get Domain Enforced RDP Settings
function Get-DomainEnforcedRDPSettings {
    param (
        [string]$outputFile,  # Parameter for the output file name
        [string]$CombinedOutputFile = ""  # Parameter for the combined output file
    )

    # Get date
    $date = Get-Date

    # Display and write to outputFile
    $message = @"
Getting Domain Enforced RDP settings (encryption level, timeout, etc)...
*** Applicable PCI DSS Requirements: 2.2.3, 2.3.b ***

"@

    # Output $message
    Write-Output $message

    # Output of domain enforced RDP registry settings
    $domainRDPSettings = Get-Item Registry::"HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services"
    $message += @"

*** Output of the registry key: Get-Item Registry::"HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services" ***
*** Ran on $env:COMPUTERNAME on $date ***
$($domainRDPSettings)

"@

    Write-OutputToFile -message $message `
                        -outputFile $outputFile `
                        -addToFile $true `
                        -startWithNewLine $true `
                        -CombinedOutputFile $CombinedOutputFile
}

# Get RDP Master Settings
function Get-RDPMasterSettings {
    param (
        [string]$outputFile,  # Parameter for the output file name
        [string]$CombinedOutputFile = ""  # Parameter for the combined output file
    )

    # Get date
    $date = Get-Date

    # Display and write to outputFile
    $message = @"
Getting RDP Master Settings...
*** Applicable PCI DSS Requirements: 2.2.3 ***

"@

    # Output $message
    Write-Output $message

    # Output of RDP master settings
    $rdpMasterSettings = Get-WmiObject -Class Win32_TerminalServiceSetting -Namespace root\CIMV2\TerminalServices -ComputerName $env:COMPUTERNAME
    $message += @"

*** Output of RDP master settings: Get-WmiObject -Class Win32_TerminalServiceSetting -Namespace root\CIMV2\TerminalServices -ComputerName $env:COMPUTERNAME ***
*** Ran on $env:COMPUTERNAME on $date ***
$($rdpMasterSettings)

"@

    Write-OutputToFile -message $message `
                        -outputFile $outputFile `
                        -addToFile $true `
                        -startWithNewLine $true `
                        -CombinedOutputFile $CombinedOutputFile
}

# Get Screensaver Settings
function Get-ScreensaverSettings {
    param (
        [string]$outputFile,  # Parameter for the output file name
        [string]$CombinedOutputFile = ""  # Parameter for the combined output file
    )

    # Get date
    $date = Get-Date

    # Display and write to outputFile
    $message = @"
Getting screensaver settings...
*** Applicable PCI DSS Requirements: 2.2.3, 8.1.8 ***

"@

     # Output $message
     Write-Output $message

     # Output of screensaver settings
    $screensaverSettings = Get-WmiObject -ComputerName $env:COMPUTERNAME win32_Desktop
    $message += @"

*** Output of screensaver settings: Get-WmiObject -ComputerName $env:COMPUTERNAME win32_Desktop ***
*** Ran on $env:COMPUTERNAME on $date ***
$($screensaverSettings)

"@

    Write-OutputToFile -message $message `
                        -outputFile $outputFile `
                        -addToFile $true `
                        -startWithNewLine $true `
                        -CombinedOutputFile $CombinedOutputFile
}

# Get Time Settings
function Get-TimeSettings {
    param (
        [string]$outputFile,  # Parameter for the output file name
        [string]$CombinedOutputFile = ""  # Parameter for the combined output file
    )

    # Get date
    $date = Get-Date

    # Display and write to outputFile
    $message = @"
Getting time settings...
*** Applicable PCI DSS Requirements: 2.2.3, 10.4, 10.4.1.a ***

"@

    # Output $message
    Write-Output $message

    # Output of time settings
    $timeSettings = Get-ChildItem Registry::HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\W32Time -Recurse
    $message += @"

*** Output of time settings registry: Get-ChildItem Registry::HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\W32Time -Recurse ***
*** Ran on $env:COMPUTERNAME on $date ***
$($timeSettings)

"@

    Write-OutputToFile -message $message `
                        -outputFile $outputFile `
                        -addToFile $true `
                        -startWithNewLine $true `
                        -CombinedOutputFile $CombinedOutputFile
}

# Get Snare Settings
function Get-SnareSettings {
    param (
        [string]$outputFile,  # Parameter for the output file name
        [string]$CombinedOutputFile = ""  # Parameter for the combined output file
    )

    # Get date
    $date = Get-Date

    # Display and write to outputFile
    $message = @"
Getting Snare settings...
"@

    # Output $message
    Write-Output $message

    # Output of Snare settings
    $snareSettings = Get-Item -Path "Registry::HKLM\SOFTWARE\InterSect Alliance\AuditService\Network" -ErrorAction Ignore
    $message += @"

*** Output of Snare settings registry: Get-Item -Path "Registry::HKLM\SOFTWARE\InterSect Alliance\AuditService\Network" -ErrorAction Ignore ***
*** Ran on $env:COMPUTERNAME on $date ***
$($snareSettings)

"@

    Write-OutputToFile -message $message `
                        -outputFile $outputFile `
                        -addToFile $true `
                        -startWithNewLine $true `
                        -CombinedOutputFile $CombinedOutputFile
}

# Get Local RDP Group Membership
function Get-LocalRDPGroupMembership {
    param (
        [string]$outputFile,  # Parameter for the output file name
        [string]$CombinedOutputFile = ""  # Parameter for the combined output file
    )

    # Get date
    $date = Get-Date

    # Display and write to outputFile
    $message = @"
Getting Local RDP Group Membership...
"@

    # Output $message
    Write-Output $message

    # Output of Local RDP Group membership
    $rdpGroupMembership = net localgroup 'Remote Desktop Users'
    $message += @"

*** Output of local RDP group membership: net localgroup 'Remote Desktop Users' ***
*** Ran on $env:COMPUTERNAME on $date ***
$($rdpGroupMembership)

"@

    Write-OutputToFile -message $message `
                        -outputFile $outputFile `
                        -addToFile $true `
                        -startWithNewLine $true `
                        -CombinedOutputFile $CombinedOutputFile
}

# Get Local Power Users Group Membership
function Get-LocalPowerUsersGroupMembership {
    param (
        [string]$outputFile,  # Parameter for the output file name
        [string]$CombinedOutputFile = ""  # Parameter for the combined output file
    )

    # Get date
    $date = Get-Date

    # Display and write to outputFile
    $message = @"
Getting Local Power Users Group Membership...
"@

    # Output $message
    Write-Output $message

    # Output of Local Power Users Group membership
    $powerUsersGroupMembership = net localgroup "Power Users"
    $message += @"

*** Output of local Power Users group membership: net localgroup "Power Users" ***
*** Ran on $env:COMPUTERNAME on $date ***
$($powerUsersGroupMembership)

"@

    Write-OutputToFile -message $message `
                        -outputFile $outputFile `
                        -addToFile $true `
                        -startWithNewLine $true `
                        -CombinedOutputFile $CombinedOutputFile
}

# Get Server Operators Group Membership
function Get-ServerOperatorsGroupMembership {
    param (
        [string]$outputFile,  # Parameter for the output file name
        [string]$CombinedOutputFile = ""  # Parameter for the combined output file
    )

    # Get date
    $date = Get-Date

    # Display and write to outputFile
    $message = @"
Getting Server Operators Group Membership...
"@

    # Output $message
    Write-Output $message

    # Output of Server Operators Group membership
    $serverOperatorsGroupMembership = net localgroup 'Server Operators'
    $message += @"

*** Output of Server Operators group membership: net localgroup 'Server Operators' ***
*** Ran on $env:COMPUTERNAME on $date ***
$($serverOperatorsGroupMembership)

"@

    Write-OutputToFile -message $message `
                        -outputFile $outputFile `
                        -addToFile $true `
                        -startWithNewLine $true `
                        -CombinedOutputFile $CombinedOutputFile
}

# Output startup programs
function Get-StartupPrograms {
    param (
        [string]$outputFile,  # Parameter for the output file name
        [string]$CombinedOutputFile = ""  # Parameter for the combined output file
    )

    # Get date
    $date = Get-Date

    # Display and write to outputFile
    $message = @"
Getting startup programs...
"@

    # Output $message
    Write-Output $message

    # Output startup programs
    $message += @"
*** Output of the command: Get-CimInstance win32_startupcommand ***
*** Ran on $env:COMPUTERNAME on $date ***
$(Get-CimInstance win32_startupcommand | Select-Object Name, command, Location, User | Format-List)

"@

    Write-OutputToFile -message $message `
                        -outputFile $outputFile `
                        -addToFile $true `
                        -startWithNewLine $true `
                        -CombinedOutputFile $CombinedOutputFile
}

# Output user logon history
function Get-UserLogonHistory {
    param (
        [string]$outputFile,  # Parameter for the output file name
        [string]$CombinedOutputFile = ""  # Parameter for the combined output file
    )

    # Get date
    $date = Get-Date

    # Display and write to outputFile
    $message = @"
Getting user logon history...
"@

    # Output $message
    Write-Output $message

   # Output user logon history
    try {
        $message += @"
*** Output of the command: Get-CimInstance or Get-WmiObject netlogin ***
*** Ran on $env:COMPUTERNAME on $date ***

"@

        # Handle deprecation of WMIC
        Write-Warning "The 'wmic' command is deprecated and will be removed in future Windows versions, so using Get-WmiObject or Get-CimInstance cmdlets."

        # Get user logon history using Get-WmiObject for PowerShell 5.x (Windows PowerShell)
        # Get-CimInstance for PowerShell 6+ (PowerShell Core)
        if ($PSVersionTable.PSVersion.Major -lt 6) {
            # PowerShell 5.x (Windows PowerShell), use Get-WmiObject
            $netLoginData = Get-WmiObject -Class Win32_NetworkLoginProfile | Select-Object Name, Comment, LastLogon, PasswordAge, BadPasswordCount, NumberOfLogons
        } else {
            # PowerShell 6+ (PowerShell Core), use Get-CimInstance
            $netLoginData = Get-CimInstance -ClassName Win32_NetworkLoginProfile | Select-Object Name, Comment, LastLogon, PasswordAge, BadPasswordCount, NumberOfLogons
        }

        # Append logon history data to the message
        if ($null -eq $netLoginData) {
            throw "Failed to retrieve net login data. No data returned."
        }

        $message += $netLoginData | Out-String
    }
    catch {
        # Handle any errors that occur during the retrieval
        Write-Error "An error occurred while retrieving the user logon history: $_"
        $message += "Error: $_"
    }

    # Write the message to the output file
    Write-OutputToFile -message $message `
                        -outputFile $outputFile `
                        -addToFile $true `
                        -startWithNewLine $true `
                        -CombinedOutputFile $CombinedOutputFile

}

# Output known routes
function Get-KnownRoutes {
    param (
        [string]$outputFile,  # Parameter for the output file name
        [string]$CombinedOutputFile = ""  # Parameter for the combined output file
    )

    # Get date
    $date = Get-Date

    # Display and write to outputFile
    $message = @"
Getting known routes...
"@

    # Output $message
    Write-Output $message

    # Output known routes
    $message += @"
*** Output of the command: Get-WmiObject win32_ip4routetable ***
*** Ran on $env:COMPUTERNAME on $date ***
$(Get-WmiObject win32_ip4routetable | Select-Object PScomputername, Destination, Mask, NextHop)

"@

    Write-OutputToFile -message $message `
                        -outputFile $outputFile `
                        -addToFile $true `
                        -startWithNewLine $true `
                        -CombinedOutputFile $CombinedOutputFile
}

# Output Firewall rules
function Get-FirewallRules {
    param (
        [string]$outputFile,  # Parameter for the output file name
        [string]$CombinedOutputFile = ""  # Parameter for the combined output file
    )

    # Get date
    $date = Get-Date

    # Display and write to outputFile
    $message = @"
Getting firewall rules...
"@

    # Output $message
    Write-Output $message

    # Output firewall rules
    $message += @"
*** Output of the command: netsh advfirewall show allprofiles ***
*** Ran on $env:COMPUTERNAME on $date ***
$(netsh advfirewall show allprofiles)

"@

    Write-OutputToFile -message $message `
                        -outputFile $outputFile `
                        -addToFile $true `
                        -startWithNewLine $true `
                        -CombinedOutputFile $CombinedOutputFile
}

# Output Password Policies
function Get-PasswordPolicies {
    param (
        [string]$outputFile,  # Parameter for the output file name
        [string]$CombinedOutputFile = ""  # Parameter for the combined output file
    )

    # Get date
    $date = Get-Date

    # Display and write to outputFile
    $message = @"
Getting password policies...
"@

    # Output $message
    Write-Output $message

    # Output password policies
    $message += @"
*** Output of the command: net accounts | Format-List ***
*** Ran on $env:COMPUTERNAME on $date ***
$(net accounts | Format-List)
"@

    Write-OutputToFile -message $message `
                        -outputFile $outputFile `
                        -addToFile $true `
                        -startWithNewLine $true `
                        -CombinedOutputFile $CombinedOutputFile
}

# Output all File Shares for Server
function Get-FileShares {
    param (
        [string]$outputFile,  # Parameter for the output file name
        [string]$CombinedOutputFile = ""  # Parameter for the combined output file
    )

    # Get date
    $date = Get-Date

    # Display and write to outputFile
    $message = @"
Getting all file shares for server...
"@

    # Output $message
    Write-Output $message

    # Output file shares
    $message += @"
*** Output of the command: net share ***
*** Ran on $env:COMPUTERNAME on $date ***
$(net share)

"@

    Write-OutputToFile -message $message `
                        -outputFile $outputFile `
                        -addToFile $true `
                        -startWithNewLine $true `
                        -CombinedOutputFile $CombinedOutputFile
}

# Output all domain controllers
function Get-DomainControllers {
    param (
        [string]$outputFile,  # Parameter for the output file name
        [string]$CombinedOutputFile = ""  # Parameter for the combined output file
    )

    # Get date
    $date = Get-Date

    # Display and write to outputFile
    $message = @"
Getting all domain controllers...
"@

    # Output $message
    Write-Output $message

    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # Import ActiveDirectory
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    if ($env:IsImportADModule -ne "True") {
        Write-Output "Failed to load Active Directory module, so cannot run: (Get-ADForest).Domains"
        # Output domain controllers
        $message += @"
*** Output of the command: (Get-ADForest).Domains ***
*** Ran on $env:COMPUTERNAME on $date ***
ERROR: Failed to load Active Directory module, so cannot run: (Get-ADForest).Domains

"@
        
            Write-OutputToFile -message $message `
                                -outputFile $outputFile `
                                -addToFile $true `
                                -startWithNewLine $true `
                                -CombinedOutputFile $CombinedOutputFile
    
        return
    }

    # Output domain controllers
    $message += @"
*** Output of the command: (Get-ADForest).Domains ***
*** Ran on $env:COMPUTERNAME on $date ***
$(Get-ADForest).Domains | %{ Get-ADDomainController -Filter * -Server $_ }

"@

    Write-OutputToFile -message $message `
                        -outputFile $outputFile `
                        -addToFile $true `
                        -startWithNewLine $true `
                        -CombinedOutputFile $CombinedOutputFile
}

# Output all FSMO Servers
function Get-FSMOServers {
    param (
        [string]$outputFile,  # Parameter for the output file name
        [string]$CombinedOutputFile = ""  # Parameter for the combined output file
    )

    # Get date
    $date = Get-Date

    # Display and write to outputFile
    $message = @"
Getting all FSMO Servers...
"@

    # Output $message
    Write-Output $message

    # Output FSMO servers
    $message += @"
*** Output of the command: netdom query fsmo ***
*** Ran on $env:COMPUTERNAME on $date ***
$(netdom query fsmo)

"@

    Write-OutputToFile -message $message `
                        -outputFile $outputFile `
                        -addToFile $true `
                        -startWithNewLine $true `
                        -CombinedOutputFile $CombinedOutputFile
}

# Output Global Catalog Servers
function Get-GlobalCatalogServers {
    param (
        [string]$outputFile,  # Parameter for the output file name
        [string]$CombinedOutputFile = ""  # Parameter for the combined output file
    )

    # Get date
    $date = Get-Date

    # Display and write to outputFile
    $message = @"
Getting Global Catalog Servers...
"@

    # Output $message
    Write-Output $message

    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # Import ActiveDirectory
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    if ($env:IsImportADModule -ne "True") {
        Write-Output "Failed to load Active Directory module, so cannot run: Get-ADDomainController -Filter {IsGlobalCatalog -eq $true}"
            
        # Output global catalog servers
        $message += @"
*** Output of the command: Get-ADDomainController -Filter {IsGlobalCatalog -eq $true} ***
*** Ran on $env:COMPUTERNAME on $date ***
ERROR: Failed to load Active Directory module, so cannot run: Get-ADDomainController -Filter {IsGlobalCatalog -eq $true}

"@
        
        Write-OutputToFile -message $message `
                            -outputFile $outputFile `
                            -addToFile $true `
                            -startWithNewLine $true `
                            -CombinedOutputFile $CombinedOutputFile
    
        return
    }

    # Output global catalog servers
    $message += @"
*** Output of the command: Get-ADDomainController -Filter {IsGlobalCatalog -eq $true} ***
*** Ran on $env:COMPUTERNAME on $date ***
$(Get-ADDomainController -Filter {IsGlobalCatalog -eq $true})
"@

    Write-OutputToFile -message $message `
                        -outputFile $outputFile `
                        -addToFile $true `
                        -startWithNewLine $true `
                        -CombinedOutputFile $CombinedOutputFile
}

# Define function to get AD group members
function Get-ADGroupMembers {
    param (
        [string]$GroupName
    )

    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # Import ActiveDirectory
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    if ($env:IsImportADModule -ne "True") {
        return ""
    }

    # Get group members which are also groups and add to string
    $MemebersList = Get-ADGroup -Filter "Name -eq '$GroupName'" | Get-ADGroupMember | Select-Object Name

    if ($MemebersList) { 
        return $MemebersList.Name -join ","
    }

    return ""
}

# Define function to process AD groups and get members
function Get-ADSecurityGroupsData {
    # Create array for CSV data 
    $CSVOutput = @() 

    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # Import ActiveDirectory
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    if ($env:IsImportADModule -ne "True") {
        return $CSVOutput
    }

    # Get all AD groups in the domain
    $ADGroups = Get-ADGroup -Filter GroupCategory -eq "Security" 

    # Set progress bar variables 
    $i = 0 
    $tot = $ADGroups.Count 

    foreach ($ADGroup in $ADGroups) { 
        # Set up progress bar 
        $i++ 
        $status = "{0:N0}" -f ($i / $tot * 100) 
        Write-Progress -Activity "Exporting AD Groups" -Status "Processing Group $i of $tot : $status% Completed" -PercentComplete ($i / $tot * 100) 

        # Get group members using the function
        $Members = Get-ADGroupMembers -GroupName $ADGroup.Name

        # Set up hash table and add values
        $HashTab = [ordered]@{ 
            "Name" = $ADGroup.Name 
            "Category" = $ADGroup.GroupCategory 
            "Scope" = $ADGroup.GroupScope 
            "Members" = $Members 
        } 

        # Add hash table to CSV data array
        $CSVOutput += New-Object PSObject -Property $HashTab 
    } 

    # Return CSV data output
    return $CSVOutput
}

# Diagnosing Domain Controller for Health Issues: 00_AllOutputs.txt
function DiagnosingDomainControllerHealthIssues {
    param (
        [string]$CombinedOutputFile = ""  # Parameter for the combined output file
    )

    # Get date
    $date = Get-Date

    # DcDiag
    $DcDiag = dcdiag

    # DcDiag
    Write-Output "Diagnosing Domain Controller for Health Issues..."

    $message = @"
Diagnosing Domain Controller for Health Issues...
*** Output of command: dcdiag ***
*** Ran on $env:COMPUTERNAME on $date ***
$DcDiag

"@
        
    Write-OutputToFile -message $message `
                        -startWithNewLine $true `
                        -CombinedOutputFile $CombinedOutputFile
}

# Getting Replication Summary: 00_AllOutputs.txt
function Get-ReplicationSummary {
    param (
        [string]$CombinedOutputFile = ""  # Parameter for the combined output file
    )

    # Get date
    $date = Get-Date

    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # Import ActiveDirectory
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    if ($env:IsImportADModule -ne "True") {
        $message = @"
Getting Replication Summary...
*** Output of command: Get-ADAccountAuthorizationGroup -Identity 'Windows Authorization Access Group' ***
*** Ran on $env:COMPUTERNAME on $date ***
ERROR: Failed to load Active Directory module, so cannot run: Get-ADAccountAuthorizationGroup -Identity 'Windows Authorization Access Group'

"@
            
        Write-OutputToFile -message $message `
                            -startWithNewLine $true `
                            -CombinedOutputFile $CombinedOutputFile
        
        return
    }

    # First command: Get-ADAccountAuthorizationGroup
    $adAuthorizationGroup = Get-ADAccountAuthorizationGroup -Identity "Windows Authorization Access Group"
    
    $message = @"
Getting Replication Summary...
*** Output of command: Get-ADAccountAuthorizationGroup -Identity 'Windows Authorization Access Group' ***
*** Ran on $env:COMPUTERNAME on $date ***
$adAuthorizationGroup

"@
    
    Write-OutputToFile -message $message `
                        -startWithNewLine $true `
                        -CombinedOutputFile $CombinedOutputFile

    # Second command: Get-ADReplicationPartnerMetadata
    $replicationSummary = Get-ADReplicationPartnerMetadata -Target * -Partition * | 
                           Select-Object Server, Partition, Partner, ConsecutiveReplicationFailures, LastReplicationSuccess, LastReplicationResult
    
    $message = @"
*** Output of command: Get-ADReplicationPartnerMetadata -Target * -Partition * | Select-Object Server,Partition,Partner,ConsecutiveReplicationFailures,LastReplicationSuccess,LastReplicationResult ***
$replicationSummary

"@

    Write-OutputToFile -message $message2 `
                        -startWithNewLine $true `
                        -CombinedOutputFile $CombinedOutputFile
}

# Getting all OUs in Domain: 00_AllOutputs.txt
function Get-AllOUsInDomain {
    param (
        [string]$CombinedOutputFile = ""  # Parameter for the combined output file
    )

    # Get date
    $date = Get-Date

    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # Import ActiveDirectory
    #~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    if ($env:IsImportADModule -ne "True") {
        $message = @"
Getting Replication Summary...
*** Output of command: Get-ADOrganizationalUnit -Filter 'Name -like "*"' | Format-Table Name, DistinguishedName -A ***
*** Ran on $env:COMPUTERNAME on $date ***
ERROR: Failed to load Active Directory module, so cannot run: Get-ADOrganizationalUnit -Filter 'Name -like "*"' | Format-Table Name, DistinguishedName -A

"@
            
        Write-OutputToFile -message $message `
                            -startWithNewLine $true `
                            -CombinedOutputFile $CombinedOutputFile
        
        return
    }


    # Get all Organizational Units (OUs) in the domain
    $OUs = Get-ADOrganizationalUnit -Filter 'Name -like "*"' | Format-Table Name, DistinguishedName -A

    # Prepare the message to be written to output
    $message = @"
Getting all OUs in Domain...
*** Output of command: Get-ADOrganizationalUnit -Filter 'Name -like "*"' | Format-Table Name, DistinguishedName -A ***
*** Ran on $env:COMPUTERNAME on $date ***
$OUs

"@
    
    Write-OutputToFile -message $message `
                        -startWithNewLine $true `
                        -CombinedOutputFile $CombinedOutputFile
}

# Getting Event Logs: 32_EventLogs.txt
function Get-EventLogs {
    param(
        [Parameter(Mandatory=$true)]
        [string]$OutputFile,  # Parameter for the output file name

        [Parameter(Mandatory=$true)]
        [string]$CombinedOutputFile  # Parameter for the combined output file
    )

    # Get date
    $date = Get-Date

    # Initialize message variable for the output
    $message = @"
Collecting event logs information...

"@

    # Display and write to outputFile
    Write-Output $message

    # Get the list of event logs
    try {
        $eventLogs = Get-EventLog -List

        # Add event log details to the message
        $message += @"
*** Output of 'Get-EventLog -List' ***
*** Ran on $env:COMPUTERNAME on $date ***
$($eventLogs | Format-List | Out-String)

"@
    }
    catch {
        Write-Error "Failed to collect event logs: $_"
        $message += "ERROR: Failed to collect event logs: $_"
    }

    # Write output to the outputFile
    Write-OutputToFile -message $message `
                        -outputFile $OutputFile `
                        -addToFile $true `
                        -startWithNewLine $true `
                        -CombinedOutputFile $CombinedOutputFile
}

# Analyze output files for security issues: 00_Analysis.txt
function AnalyzeOutputFiles {
    param (
        [string]$openPortsFile = "",
        [string]$CombinedOutputFile = ""
    )

    # Get the current date
    $date = Get-Date

    # Search the open ports file for certain vulnerable ports and add them to the analysis file
    $openPortsResults = Select-String $openPortsFile -Pattern @(
        " 445", " 161", " 162", " 20", " 21", " 23", " 107", " 102", " 103", 
        " 220", " 69", " 80", " 8080", " 513", " 514", " 111", " 2049"
    )
    
    # Check for weak password policies (e.g., short password length)
    $weakPasswordLengthResults = Select-String 00_AllOutputs.txt -Pattern @(
        "MinimumPasswordLength = 6",
        "MinimumPasswordLength = 5",
        "MinimumPasswordLength = 4",
        "MinimumPasswordLength = 3",
        "MinimumPasswordLength = 2",
        "MinimumPasswordLength = 1",
        "MinimumPasswordLength = 0"
    )
    
    # Check for disabled password complexity
    $disabledPasswordComplexityResults = Select-String 00_AllOutputs.txt -Pattern "PasswordComplexity = 0"

    # Check for an invalid minimum password age setting
    $invalidPasswordAgeResults = Select-String 00_AllOutputs.txt -Pattern "MinimumPasswordAge = 0"

    # Check for weak password history size
    $weakPasswordHistoryResults = Select-String 00_AllOutputs.txt -Pattern @(
        "PasswordHistorySize = 0", 
        "PasswordHistorySize = 1", 
        "PasswordHistorySize = 2", 
        "PasswordHistorySize = 3", 
        "PasswordHistorySize = 4"
    )
    
    # Final note indicating analysis completion
    Add-Content $CombinedOutputFile -Value "Any issues were outputted above."

    # Prepare the message to be written to output
    $message = @"
Analyzing output files...
*** Ran on $env:COMPUTERNAME on $date. Files in the $env:COMPUTERNAME folder were analyzed. ***

*** Open Ports found in $openPortsFile ***
$openPortsResults

*** Weak Password Lengths found in $CombinedOutputFile ***
$weakPasswordLengthResults

*** Disabled Password Complexity found in $CombinedOutputFile ***
$disabledPasswordComplexityResults

*** Invalida Password Age found in $CombinedOutputFile ***
$invalidPasswordAgeResults

*** Weak Password History Results found in $CombinedOutputFile ***
$weakPasswordHistoryResults

Any issues were outputted above.

"@
    
    Write-OutputToFile -message $message `
                    -startWithNewLine $true `
                    -CombinedOutputFile $CombinedOutputFile
    
        
}

# Compress the evidence files
function Compress-EvidenceFiles {
    param (
        [string]$EvidenceFilesFolder,        # Folder containing evidence files
        [string]$DestDirectory               # Destination directory for the zip file
    )
    
    # Extract the folder name from the path to use as the zip file name
    $folderName = [System.IO.Path]::GetFileName($EvidenceFilesFolder)
    $zipFileName = "$folderName.zip"
    $zipFilePath = Join-Path $DestDirectory $zipFileName

    # Check if an old zip file exists and remove it, if necessary
    if (Test-Path -Path $zipFilePath) {
        Write-Output "Old zip file found: $zipFilePath. Removing it..."
        try {
            Remove-Item -Path $zipFilePath -Recurse -Force -ErrorAction SilentlyContinue
            Write-Output "Old zip file removed successfully."
        }
        catch {
            Write-Warning "Failed to remove old zip file: $_"
        }
    }

    # Compress the evidence files into a zip file
    Write-Output "Compressing evidence files from $EvidenceFilesFolder..."

    try {
        # Add the required .NET assembly for compression
        Add-Type -Assembly "System.IO.Compression.FileSystem"
        
        # Creating the zip file from the evidence files folder
        [System.IO.Compression.ZipFile]::CreateFromDirectory($EvidenceFilesFolder, $zipFilePath)
        
        Write-Output "Evidence files successfully compressed into: $zipFilePath"
    }
    catch {
        Write-Error "Failed to create zip file: $_"
        exit 1
    }
}
